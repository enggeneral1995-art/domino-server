
function CGame(oData, iPlayers, iGoal) {
    var _bStartGame;
    var _bGameReady;
    var _bDisableEvents;
    var _bWin;
    var _bMatchOver;
    var _bResultReported;
    var _bMatchLocked;
    var _bFirstTile;
    var _bDrawnedTile;
    var _bDomino;
    var _bSelectedTile;
    
    var _iPlayers;
    var _iGoal;
    var _iTurn;
    var _iSide1Value;     // THE VALUE OF THE 1ST SIDE OF THE BOARD
    var _iSide2Value;     // THE VALUE OF THE 2ND SIDE OF THE BOARD
    var _iDrawnTilesSide1;
    var _iDrawnTilesSide2;
    var _iMatchTimer;
    var _iWinnerPoints;
    var _iPendingWinnerPoints = 0;
    var _bAuthoritativeScoreApplied = false;
    var _iWinnerPlayer;
    var _iDistributionOffsetX;
    var _iDistributionOffsetY;
    var _iDistributionTurn;
    var _iScale;
    var _iBaseScale;
    var _iOffsetDouble;
    var _iOffsetTiles;
    var _bTileAnimating = false;
    var _aRemoteMoveQueue = [];
    var _bDrainedBurst = false;
    var _iTilesContainerOffsetY;

    var _oInterface;
    var _oBg;
    var _oSideArrowsText;
    var _oFrame;
    var _oEndPanel;
    var _oMatchOverPanel;
    var _bAutoRoundAdvancing = false;
    var _oHelpPanel;  
    var _oTilesContainer;
    var _oSide1Tile;      // THE LAST TILE ON 1ST SIDE OF THE BOARD
    var _oSide2Tile;      // THE LAST TILE ON 2ND SIDE OF THE BOARD
    var _oLockedText;
    var _oDominoText;
    var _oDominoPointsText;
    var _oShake;
    var _oTilesBox;
    var _oMessageBox;
    var _oMessageBoxDomino;
    var _oMsgContainerLocked;
    var _oMsgContainerDomino;
    var _oLockedContinueButton;
    var _oDominoContinueButton;
    var _oBlockInput;
    var _oArrowsContainer;
    var _oLeftSideArrow;
    var _oRightSideArrow;
    var _oSelectedTile;
        
    var _aScore;          // THE SCORES OF EACH PLAYER
    var _aTilesDeck;      // THIS ARRAY CONTAINS ALL THE TILES
    var _aBoneyard;       // REMAINING TILES (offline)
    var _iOnlineBoneyardLeft = 0;
    var _bWaitingOnlineDraw = false;
    var _oInfoContainer;  // counter: boneyard + opponent tiles
    var _oInfoText;
    var _oInfoText2;
    var _aPlayers;
    var _aLockedPlayers;
    var _aCorrectTiles;
    var _aBoardTiles;
    // True only while rebuildFromState is laying the board out again.
    var _bRebuilding = false;
    // True between sending our own move to the server and hearing back.
    // While it is set, the board has NOT been touched and no further taps
    // are accepted -- see moveToBoard.
    var _bAwaitingServerMove = false;
    // When that wait began.
    //
    // THE FREEZE. This flag is only ever cleared inside the send callback,
    // and it had no expiry. If that callback never ran -- a lost request,
    // a lost ack, a socket that died at the wrong moment -- the flag
    // stayed true for the rest of the match. From that instant the player
    // could not place a tile (every tap returns early below) and every
    // authoritative state was refused with "awaiting_our_move". The board
    // sits frozen while the server and the opponent carry on without it.
    //
    // Nothing should be able to wedge the game permanently, so the wait
    // now ends on its own.
    var _iAwaitingSince = 0;
    var AWAITING_MAX_MS = 6000;

    function awaitingServerMove(){
        if (!_bAwaitingServerMove) return false;
        if (_iAwaitingSince && (Date.now() - _iAwaitingSince) > AWAITING_MAX_MS) {
            _bAwaitingServerMove = false;
            _iAwaitingSince = 0;
            try {
                if (window.reportGlitch) {
                    window.reportGlitch("awaiting-move wait expired after " + AWAITING_MAX_MS + "ms -- unblocking the board");
                }
            } catch(e){}
            return false;
        }
        return true;
    }
    
    this._init = function(){
        _aTilesDeck = new Array();
        _aBoneyard = new Array();
        _aPlayers = new Array();
        _aScore = new Array();
        _aLockedPlayers = new Array();
        _aBoardTiles = new Array();
        _bAwaitingServerMove = false;
        _iAwaitingSince = 0;
        
        _iPlayers = iPlayers;
        _iGoal = iGoal;
        window.YD_MATCH_GOAL = Number(iGoal || 100);
        _iTurn = 0;
        _iSide1Value = _iSide2Value = 0;
        _iMatchTimer = 0;
        _iDrawnTilesSide1 = _iDrawnTilesSide2 = 0;
        _iWinnerPoints = 0;
        _iWinnerPlayer = 0;
        _iDistributionTurn = 0;
        _iDistributionOffsetX = _iDistributionOffsetY = 0;
        _iScale = 1; // responsive board scale: readable without chain collisions (raised from 0.68 -- lots of unused felt space at the old size; centerPlayedChain() still shrinks this down automatically once a chain grows long enough to need it)
        _iBaseScale = _iScale; // the un-shrunk value centerPlayedChain() fits down from
        _iOffsetDouble = ((TILE_HEIGHT + TILE_WIDTH) / 2) * TILE_INIT_SCALE * 0.84;
        _iOffsetTiles = TILE_HEIGHT * TILE_INIT_SCALE * 0.84;
        _iTilesContainerOffsetY = 38;

        _oEndPanel = null;
        _oMatchOverPanel = null;
        _oSelectedTile = null;
        
        _bDisableEvents = false;
        _bGameReady = false;
        _bWin = false;
        _bFirstTile = true;
        _bDrawnedTile = false;
        _bMatchOver = false;
        _bResultReported = false;
        _bDomino = false;
        _bMatchLocked = false;
        _bSelectedTile = false;
        _bWaitingOnlineDraw = false;
        _iOnlineBoneyardLeft =
            (window.s_bOnline && window.s_oOnlineDeal && window.s_oOnlineDeal.boneyardCount != null)
                ? Number(window.s_oOnlineDeal.boneyardCount)
                : 0;
        
        switch(_iPlayers) {
            case 2: 
                for (var i = 0; i < s_aPlayersScore2.length; i++) {
                    _aScore[i] = s_aPlayersScore2[i]; };
                break;
            case 3: 
                for (var i = 0; i < s_aPlayersScore3.length; i++) {
                    _aScore[i] = s_aPlayersScore3[i]; };
                break;
            case 4: 
                for (var i = 0; i < s_aPlayersScore4.length; i++) {
                    _aScore[i] = s_aPlayersScore4[i]; };
                break;
        };
        
        var oSpriteBg = s_oSpriteLibrary.getSprite('bg_game');
        _oBg = createBitmap(oSpriteBg);
        _oBg.x = 0;
        _oBg.y = 0;
        _oFrame = createBitmap(s_oSpriteLibrary.getSprite("game_frame"));
        _oFrame.x = 0;
        _oFrame.y = 0;
        s_oStage.addChild(_oBg, _oFrame);
        
        // CREATE A BOX FOR THE TILES, WITH SOME ANIMATIONS
        _oTilesBox = new CBoxAnimation(_iPlayers, _aPlayers);
        
        // INIT THE PLAYERS AND TILES
        this._initPlayersAndTiles();

        // INIT MESSAGE TEXTS
        _oMsgContainerLocked = new createjs.Container();
        s_oStage.addChild(_oMsgContainerLocked);
        this._initLockedText();

        // YALLA DOMINO HUD matching the supplied reference.
        _oInfoContainer = new createjs.Container();
        s_oStage.addChild(_oInfoContainer);

        // SCORE / BONEY / ROUND — dark cards with a muted grey label and a
        // bright green number, matching the reference design.
        var goal = new createjs.Shape();
        goal.graphics.setStrokeStyle(2).beginStroke("#c9a24a")
          .beginFill("#131313").drawRoundRect(46,185,112,98,16);
        _oInfoContainer.addChild(goal);

        var gt = new createjs.Text(TEXT_HUD_DRAWGAMETO,"400 18px Arial","#9a9a9a");
        gt.textAlign="center"; gt.x=102; gt.y=202; _oInfoContainer.addChild(gt);

        var gv = new createjs.Text(String(_iGoal),"500 44px Arial","#5fe07a");
        gv.textAlign="center"; gv.x=102; gv.y=228; _oInfoContainer.addChild(gv);

        var stockBox = new createjs.Shape();
        stockBox.graphics.setStrokeStyle(2).beginStroke("#c9a24a")
          .beginFill("#131313").drawRoundRect(646,164,102,82,16);
        _oInfoContainer.addChild(stockBox);

        var sl = new createjs.Text(TEXT_HUD_STOCK,"400 17px Arial","#9a9a9a");
        sl.textAlign="center"; sl.x=697; sl.y=178; _oInfoContainer.addChild(sl);

        _oInfoText = new CTLText(_oInfoContainer,654,200,86,40,34,"center","#5fe07a",PRIMARY_FONT,1,0,0,"14",true,true,false,false);

        var roundBox = new createjs.Shape();
        roundBox.graphics.setStrokeStyle(2).beginStroke("#c9a24a")
          .beginFill("#131313").drawRoundRect(646,252,102,82,16);
        _oInfoContainer.addChild(roundBox);

        var rl = new createjs.Text(TEXT_HUD_ROUND,"400 17px Arial","#9a9a9a");
        rl.textAlign="center"; rl.x=697; rl.y=266; _oInfoContainer.addChild(rl);

        _oInfoText2 = new CTLText(_oInfoContainer,654,288,86,40,34,"center","#5fe07a",PRIMARY_FONT,1,0,0,"1",true,true,false,false);

        _oMsgContainerDomino = new createjs.Container();
        s_oStage.addChild(_oMsgContainerDomino);
        this._initDominoText();

        _oInterface = new CInterface();
        
        // ADD SOME ARROWS FOR THE SIDE SELECTION
        _oArrowsContainer = new createjs.Container();
        s_oStage.addChild(_oArrowsContainer);
        
        var oSprite = s_oSpriteLibrary.getSprite("side_selection");
        var oContainerBg = createBitmap(oSprite);
        oContainerBg.regX = oSprite.width * 0.5;
        oContainerBg.regY = oSprite.height * 0.5;
        _oArrowsContainer.addChild(oContainerBg);
        
        _oSideArrowsText = new CTLText(_oArrowsContainer, 
                    -75, -18, 150, 40, 
                    20, "center", PRIMARY_FONT_COLOUR, PRIMARY_FONT, 1,
                    0, 0,
                    TEXT_SELECTSIDE,
                    true, true, true,
                    false );
                    
     
        
        var oSprite = s_oSpriteLibrary.getSprite("arrow_left");
        _oLeftSideArrow = new CGfxButton(-90, 0, oSprite, _oArrowsContainer);
        _oLeftSideArrow.addEventListenerWithParams(ON_MOUSE_UP, this._onSelectedSide, this, LEFT_SIDE);        
        var oSprite = s_oSpriteLibrary.getSprite("arrow_right");
        _oRightSideArrow = new CGfxButton(90, 0, oSprite, _oArrowsContainer);
        _oRightSideArrow.addEventListenerWithParams(ON_MOUSE_UP, this._onSelectedSide, this, RIGHT_SIDE);
        
        _oArrowsContainer.x = CANVAS_WIDTH_HALF;
        _oArrowsContainer.y = CANVAS_HEIGHT_HALF;
        _oArrowsContainer.visible = false;
        
        
        
        _oBlockInput = new createjs.Shape();
        _oBlockInput.graphics.beginFill("#ffb200000").drawRect(0, _aPlayers[0].getY() - 50, CANVAS_WIDTH, 100);
        _oBlockInput.alpha = 0.01;
        _oBlockInput.visible = false;
        _oBlockInput.on("mousedown",function(){});
        s_oStage.addChild(_oBlockInput);

        FIRST_GAME = false;
        this._onExitHelp();
    };
    
    this._initLockedText = function(){
        var iX = CANVAS_WIDTH_HALF;
        var iY = CANVAS_HEIGHT_HALF + _iTilesContainerOffsetY;
        
        _oMessageBox = createBitmap(s_oSpriteLibrary.getSprite("msg_box"));
        _oMessageBox.regX = 616/2;
        _oMessageBox.regY = 617/2;
        _oMessageBox.scaleX = _oMessageBox.scaleY = 0.5;
        _oMessageBox.x = iX;
        _oMessageBox.y = iY;
        _oMsgContainerLocked.addChild(_oMessageBox); 
  
        
        _oLockedText = new CTLText(_oMsgContainerLocked, 
                    iX-100, iY - 100, 200, 70, 
                    30, "center", PRIMARY_FONT_COLOUR, PRIMARY_FONT, 1,
                    0, 0,
                    TEXT_PLAYER + " " + _iTurn + " " + TEXT_LOCKED,
                    true, true, true,
                    false );


               

        _oLockedContinueButton = new CGfxButton(CANVAS_WIDTH_HALF, CANVAS_HEIGHT_HALF + 100, s_oSpriteLibrary.getSprite('but_continue'), _oMsgContainerLocked);
        _oLockedContinueButton.addEventListener(ON_MOUSE_UP, this._onLockedContinue, this);
        
        _oMsgContainerLocked.alpha = 0;
    };
    
    this._initDominoText = function(){
        var iX = CANVAS_WIDTH_HALF;
        var iY = CANVAS_HEIGHT_HALF + _iTilesContainerOffsetY;
        
        _oMessageBoxDomino = createBitmap(s_oSpriteLibrary.getSprite("msg_box"));
        _oMessageBoxDomino.regX = 616/2;
        _oMessageBoxDomino.regY = 617/2;
        _oMessageBoxDomino.scaleX = _oMessageBoxDomino.scaleY = 0.5;
        _oMessageBoxDomino.x = iX;
        _oMessageBoxDomino.y = iY;
        _oMsgContainerDomino.addChild(_oMessageBoxDomino);
        
        _oDominoText = new CTLText(_oMsgContainerDomino, 
                    iX-100, iY - 100, 200, 70, 
                    30, "center", PRIMARY_FONT_COLOUR, PRIMARY_FONT, 1,
                    0, 0,
                    TEXT_PLAYER + " " + _iTurn + " " + TEXT_DOMINO,
                    true, true, true,
                    false );

        _oDominoPointsText = new CTLText(_oMsgContainerDomino,
                    iX-150, iY - 40, 300, 60,
                    26, "center", "#ffc96e", PRIMARY_FONT, 1,
                    0, 0,
                    "",
                    true, true, true,
                    false );
        _oDominoPointsText.alpha = 0;

        _oDominoContinueButton = new CGfxButton(iX, iY + 100, s_oSpriteLibrary.getSprite('but_continue'), _oMsgContainerDomino);
        _oDominoContinueButton.addEventListener(ON_MOUSE_UP, this._onDominoContinue, this);

        _oMsgContainerDomino.alpha = 0;
    };

    this._initPlayersAndTiles = function(){
        // CREATE THE PLAYERS
        for (var i = 0; i < _iPlayers; i++) {
            _aPlayers[i] = new CPlayer(i, _aScore[i]);
        };

        // APPLY CUSTOM NAMES (online opponent / Computer)
        if (_aPlayers[0] && window.DOMINO_P0_NAME) { _aPlayers[0].setName(window.DOMINO_P0_NAME); }
        if (_aPlayers[1] && window.DOMINO_P1_NAME) { _aPlayers[1].setName(window.DOMINO_P1_NAME); }
        
        // CREATE THE TILES CONTAINER
        _oTilesContainer = new createjs.Container();
        _oTilesContainer.x = CANVAS_WIDTH_HALF;
        _oTilesContainer.y = CANVAS_HEIGHT_HALF + _iTilesContainerOffsetY;
        s_oStage.addChild(_oTilesContainer);
        
        // CREATE AN ARRAY OF THE TILES VALUES
        for (var i = 0; i < TILES_NUMBER; i++) {
            var oTile = new CTile(_oTilesContainer, i, NO_PLAYER, 0, 0);
            _aTilesDeck.push(oTile);
        };
        if (window.s_bOnline && window.s_oOnlineDeal) {
            // ONLINE: order deck so player0 = my hand, player1 = opponent hand
            var aOrder = window.s_oOnlineDeal.yourHand.concat(window.s_oOnlineDeal.oppHand);
            var aByVal = {};
            for (var z = 0; z < _aTilesDeck.length; z++) { aByVal[_aTilesDeck[z].getValue()] = _aTilesDeck[z]; }
            var aNew = [];
            // interleave so round-robin deal gives player0=yourHand, player1=oppHand
            for (var z = 0; z < window.s_oOnlineDeal.yourHand.length; z++) {
                aNew.push(aByVal[window.s_oOnlineDeal.yourHand[z]]);
                aNew.push(aByVal[window.s_oOnlineDeal.oppHand[z]]);
            }
            // append the rest (unused in block domino)
            for (var z = 0; z < _aTilesDeck.length; z++) {
                if (aNew.indexOf(_aTilesDeck[z]) === -1) aNew.push(_aTilesDeck[z]);
            }
            _aTilesDeck = aNew;
        } else {
            shuffle(_aTilesDeck);   // RANDOMIZE THE TILES ARRAY
        }
        
        // ADD TILES TO THE PLAYERS' DECKS
        var iPlayer = 0;
        for (var i = 0; i < _iPlayers * INITIAL_TILES; i++) {
            _aPlayers[iPlayer].addTile(_aTilesDeck[i]);
            iPlayer++;
            
            if (iPlayer >= _iPlayers) {
                iPlayer = 0;
            }
        };
        
        // SET TILES INVISIBLE
        for (var i = 0; i < _iPlayers; i++) {
            for (var j = 0; j < INITIAL_TILES; j++) {
                _aPlayers[i].setTileVisible(j, false);
            };
        };

        for (var i = 0; i < TILES_NUMBER; i++) {
            _aTilesDeck[i].setVisible(false);
        };

        // KEEP THE LEFTOVER TILES AS THE BONEYARD (for DRAW mode)
        _aBoneyard = [];
        for (var bz = _iPlayers * INITIAL_TILES; bz < TILES_NUMBER; bz++) {
            if (_aTilesDeck[bz]) { _aBoneyard.push(_aTilesDeck[bz].getValue()); }
        }

        _aTilesDeck = null;

        // SET THE DECK IN THE MIDDLE OF THE SCREEN
        _oTilesContainer.x = 192;
        _oTilesContainer.y = 354;
        _oTilesContainer.regX = 0;
        _oTilesContainer.regY = 0;
        _oTilesContainer.scaleX = _oTilesContainer.scaleY = _iScale;
    };
    
    this.unload = function(){
        _oInterface.unload();
        createjs.Tween.removeAllTweens();
        s_oStage.removeAllChildren();
        s_oGame = null;
    };

    this.onExit = function(){
        s_oGame.unload();
        s_oMain.gotoMenu();

        $(s_oMain).trigger("end_session");
        $(s_oMain).trigger("show_interlevel_ad");
    };

    this.restart = function(){
        this.unload();
        s_oMain.gotoGame(_iPlayers, _iGoal);
        $(s_oMain).trigger("restart_level",1);
        
        s_oStage.update();
        
        _bDisableEvents = false;
        _bWin = false;
    };

    this._onExitHelp = function(){
        _bStartGame = true;
        FIRST_GAME = false;
        s_oBox.openTileBox();
    };

    this._gameOver = function(){
        _bStartGame = false;
        if(_oEndPanel === null){
            playSound("game_over",1,0);
            this.showEndPanel();
        }
    }; 

    this._checkWin = function(){
        if(_bWin){
            playSound("game_win",1,0);
            
            // IF THERE'S A NEW HIGH SCORE
            if (_aScore[0] > s_aBestScore) {
                s_aBestScore = _aScore[0];
                setItemJson("classicdomino_best_score", _aScore[0]);
            }
           
            this.showEndPanel();
        }
    };
    
    this.showEndPanel = function() {
        _bDisableEvents = true;

        _oMsgContainerLocked.visible = false;
        _oMsgContainerDomino.visible = false;

        $(s_oMain).trigger("share_event", _aScore[0]);
        $(s_oMain).trigger("save_score", [_aScore[0],_iPlayers]);

        // Show the fancy Win/Lose overlay (HTML) and wait for the player to
        // tap Back or Play Again — no auto-timer, no canvas panel.
        if (window.dominoShowMatchResult) {
            var iPlayersLocal = _iPlayers;
            window.dominoShowMatchResult({
                youWin: (_iWinnerPlayer === 0),
                yourScore: this.getScore(0),
                oppScore: this.getScore(1),
                onExit: function(){
                    s_oGame.resetScore(iPlayersLocal);
                    s_oGame.onExit();
                },
                onPlayAgain: function(){
                    s_oGame.resetScore(iPlayersLocal);
                    s_oGame.restart();
                }
            });
        } else {
            // Fallback if the overlay hook isn't present for some reason.
            _oEndPanel = new CEndPanel(_iPlayers, _iWinnerPlayer, _iWinnerPoints);
        }
    };
    
    this.checkDrawned = function() {
        return _bDrawnedTile;
    };
    
    this.setGlowVisibleFalse = function(){
        if (_iTurn > 0 || !_bGameReady || (typeof s_oBox !== "undefined" && s_oBox !== null)) {
            return;
        }
        
        var aTiles = _aPlayers[0].getTilesArray();

        for (var i = 0; i < aTiles.length; i++) {
            var oTile = aTiles[i];
            oTile.setGlowVisible(false);
        };
    };
    
    this.setGlowVisibleTrue = function(){
        if (_iTurn > 0 || !_bGameReady || (typeof s_oBox !== "undefined" && s_oBox !== null)) {
            return;
        }
        
        var aTiles = _aPlayers[0].getTilesArray();
        
        for (var i = 0; i < aTiles.length; i++) {
            var oTile = aTiles[i];
            // SET EVERY GLOW INVISIBLE
            oTile.setGlowVisible(false);
            
            // IF THE TILE CAN BE DRAWN, SET THE GLOW VISIBLE
            if (oTile.getDotsValue(0) === _iSide1Value ||
                oTile.getDotsValue(0) === _iSide2Value ||
                oTile.getDotsValue(1) === _iSide1Value ||
                oTile.getDotsValue(1) === _iSide2Value) {
                
                if (s_bGlowActive) {
                    oTile.setGlowVisible(true);
                }
                
                _aCorrectTiles.push(oTile);
            }
        };
    };
    
    
    // DRAW MODE: take one tile from the boneyard into the current player's hand.
    // Returns true if a tile was drawn, false if the boneyard is empty.
    this.drawFromBoneyard = function() {
        if (!_aBoneyard || _aBoneyard.length === 0) { return false; }
        var iValue = _aBoneyard.shift();
        var oPlayer = _aPlayers[_iTurn];
        oPlayer.addTile({ getValue: function(){ return iValue; } });
        var aT = oPlayer.getTilesArray();
        var iIdx = aT.length - 1;
        // use the SAME path the deal uses (setVisible + addHitArea) so it's clickable
        oPlayer.setTileVisible(iIdx, true);
        var oNew = aT[iIdx];
        if (oNew && _iTurn === 0 && oNew.isTurned && oNew.isTurned() === false) {
            oNew.turnTile();
        }
        // "Drop bounce" entrance for the newly drawn tile.
        playDrawEntrance(oNew);
        return true;
    };

    this.checkToDrawn = function() {
        // clear any stale "arranging" flags so tiles are always clickable on the human's turn
        for (var k = 0; k < _aPlayers.length; k++) {
            if (_aPlayers[k].setArrangingDone) { _aPlayers[k].setArrangingDone(); }
        }
        // clear a stale side-selection that could block clicks
        _bSelectedTile = false;
        if (_oArrowsContainer) { _oArrowsContainer.visible = false; }

        _bDrawnedTile = true;
        _aCorrectTiles = new Array();
        
        this.setGlowVisibleTrue();

        // OFFLINE DRAW: draw one tile at a time (with a short pause + drop
        // animation between each), stopping as soon as one is playable or
        // the boneyard runs out — instead of instantly dumping a whole
        // batch of tiles into the hand in one synchronous loop.
        if (_aCorrectTiles.length === 0 && !window.s_bOnline) {
            this._continueOfflineDraw();
            return;
        }

        this._afterDrawResolved();
    };

    this._continueOfflineDraw = function(){
        if (_aCorrectTiles.length > 0) { this._afterDrawResolved(); return; }
        if (!this.drawFromBoneyard()) { this._afterDrawResolved(); return; }
        this.setGlowVisibleTrue();
        if (_aCorrectTiles.length > 0) { this._afterDrawResolved(); return; }
        setTimeout(this._continueOfflineDraw.bind(this), 380);
    };

    this._afterDrawResolved = function(){

        // ONLINE DRAW: the SERVER owns the boneyard and chooses the tile.
        if (_aCorrectTiles.length === 0 && window.s_bOnline) {
            _bDrawnedTile = false;

            if (_iOnlineBoneyardLeft > 0 && !_bWaitingOnlineDraw && window.s_oNetDraw) {
                _bWaitingOnlineDraw = true;
                window.s_oNetDraw();
                return;
            }

            // No tiles remain: player is locked and must pass.
            if (_iOnlineBoneyardLeft <= 0) {
                if (_aPlayers[0].getLocked() === false) {
                    _aPlayers[0].setLocked(true);
                }
                this.passTurn();
            }
            return;
        }

        if (_aCorrectTiles.length === 0) {
            _bDrawnedTile = false;
            // NOTHING LEFT TO DRAW: PLAYER IS LOCKED AND HAS TO PASS
            if (_aPlayers[0].getLocked() === false) {
                _aPlayers[0].setLocked(true);
            }
            this.passTurn();
        } else {
            _bDrawnedTile = false;
            if (_aPlayers[0].getLocked() === true) {
                _aPlayers[0].setLocked(false);                
            }
            // make sure no leftover "arranging" flag blocks clicking after a draw
            for (var k = 0; k < _aPlayers.length; k++) {
                if (_aPlayers[k].setArrangingDone) { _aPlayers[k].setArrangingDone(); }
            }
        }
    };
    
    this._cpuPlayable = function() {
        var aTiles = _aPlayers[_iTurn].getTilesArray();
        var aCorrect = new Array();
        for (var i = 0; i < aTiles.length; i++) {
            var oTile = aTiles[i];
            if (oTile.getDotsValue(0) === _iSide1Value ||
                oTile.getDotsValue(0) === _iSide2Value ||
                oTile.getDotsValue(1) === _iSide1Value ||
                oTile.getDotsValue(1) === _iSide2Value) {
                aCorrect.push(oTile);
            }
        };
        return aCorrect;
    };

    this.cpuDrawTile = function() {
        _bDrawnedTile = true;

        var aCorrectTiles = this._cpuPlayable();

        // DRAW MODE (offline): draw one tile at a time (with a short pause
        // + the same drop-bounce animation as the human player) instead of
        // instantly dumping the whole batch into the CPU's hand in one
        // synchronous loop.
        if (aCorrectTiles.length === 0 && !window.s_bOnline) {
            this._continueCpuDraw();
            return;
        }

        this._finishCpuTurn(aCorrectTiles);
    };

    this._continueCpuDraw = function(){
        var aCorrectTiles = this._cpuPlayable();
        if (aCorrectTiles.length > 0) { this._finishCpuTurn(aCorrectTiles); return; }
        if (!this.drawFromBoneyard()) { this._finishCpuTurn(this._cpuPlayable()); return; }
        aCorrectTiles = this._cpuPlayable();
        if (aCorrectTiles.length > 0) { this._finishCpuTurn(aCorrectTiles); return; }
        setTimeout(this._continueCpuDraw.bind(this), 380);
    };

    this._finishCpuTurn = function(aCorrectTiles){
        // IF THE PLAYER HAS NOTHING LEFT, IT'S LOCKED AND HAS TO PASS
        if (aCorrectTiles.length === 0) {
            if (_aPlayers[_iTurn].getLocked() === false) {
                _aPlayers[_iTurn].setLocked(true);
            }
            
            this.passTurn();
        // DRAW THE HIGHEST-VALUED TILE
        } else {
            _aPlayers[_iTurn].setLocked(false);
            for (var k = 0; k < _aPlayers.length; k++) {
                if (_aPlayers[k].setArrangingDone) { _aPlayers[k].setArrangingDone(); }
            }
            var difficulty = String(window.YD_BOT_DIFFICULTY || 'hard').toLowerCase();
            var chosen = aCorrectTiles[0];
            if (difficulty === 'easy') {
                // Easy deliberately makes imperfect choices.
                chosen = aCorrectTiles[Math.floor(Math.random() * aCorrectTiles.length)];
            } else {
                // Hard/Expert: score every legal tile instead of blindly taking the first.
                // Expert additionally values keeping repeated numbers in hand, which makes
                // it harder for the human to block the bot later in the round.
                var hand = _aPlayers[_iTurn].getTilesArray();
                var freq = [0,0,0,0,0,0,0];
                for (var hi=0; hi<hand.length; hi++) {
                    freq[hand[hi].getDotsValue(0)]++;
                    freq[hand[hi].getDotsValue(1)]++;
                }
                var bestScore = -999999;
                for (var ci=0; ci<aCorrectTiles.length; ci++) {
                    var ct=aCorrectTiles[ci], x=ct.getDotsValue(0), y=ct.getDotsValue(1);
                    var pip=x+y;
                    var score=pip*4 + (ct.isDouble && ct.isDouble()?7:0);
                    if (difficulty === 'expert') {
                        score += (freq[x]+freq[y])*3;
                        // Prefer a move that leaves a number the bot still controls.
                        var nextLeft = (x===_iSide1Value?y:(y===_iSide1Value?x:-1));
                        var nextRight = (x===_iSide2Value?y:(y===_iSide2Value?x:-1));
                        if (nextLeft>=0) score += freq[nextLeft]*5;
                        if (nextRight>=0) score += freq[nextRight]*5;
                        // Dump dangerous high doubles earlier.
                        if (x===y && x>=4) score += 8;
                    }
                    if (score>bestScore) { bestScore=score; chosen=ct; }
                }
            }
            this.checkClickedTile(chosen);
            _bDrawnedTile = false;
        }
    };
    
    this.sortTilesByValue = function(aTiles) {
        function compare(a,b) {
            if (a.getDotsValue(0)+a.getDotsValue(1) < b.getDotsValue(0)+b.getDotsValue(1)) {
                return -1; }
            if (a.getDotsValue(0)+a.getDotsValue(1) > b.getDotsValue(0)+b.getDotsValue(1)) {
                return 1; }
            return 0;
        };

        aTiles.sort(compare);
    };
    
    this.passTurn = function() {
        if (this.serverForbidsPlay && this.serverForbidsPlay()) {
            try {
                if (window.reportGlitch) {
                    window.reportGlitch("pass blocked: server says it is not our turn (local _iTurn=" + _iTurn + ")");
                }
            } catch(e){}
            return;
        }
        _bDrawnedTile = false;

        // ONLINE: if this is MY pass (player 0) and not a replay, tell the opponent
        if (window.s_bOnline && _iTurn === 0 && !window.s_bApplyingRemote && window.s_oNetSend) {
            window.s_oNetSend({ type: "pass" });
        }

        var iSpeed = 1000;
        
        var iPlayerN = _iTurn+1;
        _oLockedText.refreshText(TEXT_PLAYER + " " + iPlayerN + " " + TEXT_LOCKED);
        
        // SHOW A "LOCKED" MESSAGE AND CHANGE TURN
        new createjs.Tween.get(_oMsgContainerLocked)
            .to({alpha: 1}, iSpeed/2, createjs.Ease.cubicIn);

        playSound("locked",1,0);

        // Auto-continue shortly after showing "Pass" — safe now that the
        // opponent's locked flag is tracked correctly (see applyRemotePass)
        // and round 2+ is dealt by the server instead of reshuffled locally.
        // The manual tap on the fast-forward button still works too.
        setTimeout(function(){
            if (_oMsgContainerLocked && _oMsgContainerLocked.alpha >= 1) {
                try { s_oGame._onLockedContinue(); } catch(e){}
            }
        }, 900);
    };
    
    // Lets the player tap directly on the highlighted tile at either end of
    // the board chain to choose which side to extend, instead of showing
    // separate arrow buttons in the middle of the screen.
    this._selectTileSideByBoardTap = function(oTile){
        if (awaitingServerMove()) { return; }
        _oSelectedTile = oTile;
        _bSelectedTile = true;
        oTile.setDrawn(); // SET THE TILE AS DRAWN

        var oEnd1 = _oSide1Tile ? _oSide1Tile.getTile() : null;
        var oEnd2 = _oSide2Tile ? _oSide2Tile.getTile() : null;
        var self = this;

        function pulse(oSprite){
            if (!oSprite) return;
            createjs.Tween.get(oSprite, {loop:true})
                .to({scaleX:oSprite.scaleX*1.08, scaleY:oSprite.scaleY*1.08}, 380, createjs.Ease.sineInOut)
                .to({scaleX:oSprite.scaleX, scaleY:oSprite.scaleY}, 380, createjs.Ease.sineInOut);
        }
        function unpulse(oSprite, baseScale){
            if (!oSprite) return;
            createjs.Tween.removeTweens(oSprite);
            oSprite.scaleX = baseScale; oSprite.scaleY = baseScale;
        }

        var baseScale1 = oEnd1 ? oEnd1.scaleX : TILE_INIT_SCALE;
        var baseScale2 = oEnd2 ? oEnd2.scaleX : TILE_INIT_SCALE;
        pulse(oEnd1);
        pulse(oEnd2);

        function cleanup(){
            unpulse(oEnd1, baseScale1);
            unpulse(oEnd2, baseScale2);
            if (oEnd1) oEnd1.cursor = "default";
            if (oEnd2) oEnd2.cursor = "default";
            if (oEnd1) oEnd1.off("mousedown", onTapEnd1);
            if (oEnd2) oEnd2.off("mousedown", onTapEnd2);
        }
        function onTapEnd1(){ cleanup(); self._onSelectedSide(LEFT_SIDE); }
        function onTapEnd2(){ cleanup(); self._onSelectedSide(RIGHT_SIDE); }

        if (oEnd1){ oEnd1.cursor = "pointer"; oEnd1.on("mousedown", onTapEnd1); }
        if (oEnd2){ oEnd2.cursor = "pointer"; oEnd2.on("mousedown", onTapEnd2); }
    };

    this._selectTileSide = function(oTile){
        _oSelectedTile = oTile;
        _bSelectedTile = true;
        _oArrowsContainer.visible = true;
        _oArrowsContainer.alpha = 0;
        createjs.Tween.get(_oArrowsContainer)
            .to({alpha: 1}, 500, createjs.Ease.cubicIn)
            .call(function(){
                createjs.Tween.removeTweens(_oArrowsContainer);
            });
        
        oTile.setDrawn(); // SET THE TILE AS DRAWN
        
    };
    
    this._onSelectedSide = function(iSide) {
        if (!_bSelectedTile) {
            return;
        }
        
        _bDrawnedTile = true;
        createjs.Tween.get(_oArrowsContainer)
            .to({alpha: 0}, 500, createjs.Ease.cubicIn)
            .call(function(){
                _oArrowsContainer.visible = false;
                createjs.Tween.removeTweens(_oArrowsContainer);
            });
        _bSelectedTile = false;
        var _iSide;
        var iRotation;
        var iAngleVar = 90;
        
        if (iSide === LEFT_SIDE) {
            if (_oSelectedTile.isDouble() === false ) {
                iRotation = -1 * iAngleVar;
                if (_oSelectedTile.getDotsValue(0) === _iSide1Value) {
                    iRotation = iAngleVar;
                }
            } else {
                iRotation = 0;  // IF IT'S A DOUBLE, DON'T ROTATE
            }
            _iSide = SIDE_LEFT_ATTACH;
        } else {
            if ( _oSelectedTile.isDouble() === false ) {
                iRotation = iAngleVar;
                if (_oSelectedTile.getDotsValue(0) === _iSide2Value) {
                    iRotation = -1 * iAngleVar;
                }
            } else {
                iRotation = 0;  // IF IT'S A DOUBLE, DON'T ROTATE
            }
            _iSide = SIDE_RIGHT_ATTACH;
        };
        
        this.moveToBoard(_oSelectedTile, iRotation, _iSide);
        _oSelectedTile = null;
    };
    
    this.checkIfBothSidesCanBeAttached = function(oTile){
        if (oTile.getDotsValue(0) === _iSide1Value && oTile.getDotsValue(1) === _iSide2Value && 
            !(oTile.getDotsValue(0) !== _iSide1Value && oTile.getDotsValue(1) !== _iSide2Value )) {            
            return true;
        }
        if (oTile.getDotsValue(1) === _iSide1Value && oTile.getDotsValue(0) === _iSide2Value && 
            !(oTile.getDotsValue(1) !== _iSide1Value && oTile.getDotsValue(0) !== _iSide2Value )) {
            return true;
        }
        if (oTile.getDotsValue(0) !== _iSide1Value && oTile.getDotsValue(1) !== _iSide2Value ) {
            return false;
        }
        if (oTile.getDotsValue(1) !== _iSide1Value && oTile.getDotsValue(0) !== _iSide2Value ) {
            return false;
        }
        return false;
    };
    
    this.checkClickedTile = function(oTile){
        if (_bSelectedTile) {
            return;
        };
        // A move is already out with the server. Accepting a second tap now
        // is what used to put two tiles on the board for one turn.
        if (awaitingServerMove()) {
            return;
        };
        if (this.serverForbidsPlay()) {
            try {
                if (window.reportGlitch) {
                    window.reportGlitch("tap blocked: server says it is not our turn (local _iTurn=" + _iTurn + ")");
                }
            } catch(e){}
            try { this.callShake(oTile.getTile()); } catch(e){}
            return;
        };
        
        var iRotation;
        var iAngleVar = 90;

        // IF IT'S THE FIRST TILE TO BE DRAWN
        if (_bFirstTile === true) {
            if (_iTurn === 0) {
                if (oTile.isPlayerTile() ) {
                    oTile.setDrawn(); // SET THE TILE AS DRAWN
                    _bDrawnedTile = true;

                    // CHECK IF IT'S A DOUBLE
                    iRotation = -iAngleVar;
                    if ( oTile.isDouble() === true ) {
                        iRotation = 0;
                    }
                    this.moveToBoard(oTile, iRotation, CENTER_ATTACH);
                } else {
                    this.callShake( oTile.getTile() );
                }
            } else {
                oTile.setDrawn(); // SET THE TILE AS DRAWN
                _bDrawnedTile = true;

                // CHECK IF IT'S A DOUBLE
                iRotation = iAngleVar;
                if ( oTile.isDouble() === true ) {
                    iRotation = 0;
                }
                this.moveToBoard(oTile, iRotation, CENTER_ATTACH);
            }
        } else if (_bFirstTile === false) {
            if (_iTurn === 0) {
                // IF A TILE CAN BE ATTACHED ON BOTH SIDES, LET THE PLAYER TAP
                // WHICHEVER END TILE ON THE BOARD THEY WANT TO EXTEND
                if (this.checkIfBothSidesCanBeAttached(oTile) === true){
                    this._selectTileSideByBoardTap(oTile);
                    return;
                }
            }

            // ATTACH SIDE SETTING
            if (oTile.getDotsValue(0) === _iSide1Value ||
                oTile.getDotsValue(1) === _iSide1Value ) {
                oTile.setDrawn(); // SET THE TILE AS DRAWN
                _bDrawnedTile = true;
                if ( oTile.isDouble() === false ) {
                    iRotation = -1 * iAngleVar;
                    if (oTile.getDotsValue(0) === _iSide1Value) {
                        iRotation = iAngleVar;
                    }
                } else {
                    iRotation = 0;  // IF IT'S A DOUBLE, DON'T ROTATE
                }
                this.moveToBoard(oTile, iRotation, SIDE_LEFT_ATTACH);
            } else if (oTile.getDotsValue(0) === _iSide2Value ||
                       oTile.getDotsValue(1) === _iSide2Value ) {
                oTile.setDrawn(); // SET THE TILE AS DRAWN
                _bDrawnedTile = true;
                if ( oTile.isDouble() === false ) {
                    iRotation = iAngleVar;
                    if (oTile.getDotsValue(0) === _iSide2Value) {
                        iRotation = -1 * iAngleVar;
                    }
                } else {
                    iRotation = 0;  // IF IT'S A DOUBLE, DON'T ROTATE
                }
                this.moveToBoard(oTile, iRotation, SIDE_RIGHT_ATTACH);
            } else {
                // IF THIS TILE CAN'T BE ATTACHED TO ANYTHING
                this.callShake( oTile.getTile() );
            }
        }
    };

    this.callShake = function(oTile) {
        playSound("wrong",1,0);
        this.stopShake();
        _oShake = new CShake(oTile, 300, 1, 5);
    };
    
    this.stopShake = function(){
        if(_oShake){
            _oShake.stopTremble();
            _oShake = null;
        }
    };
    
    this.getDebugCounts = function(){
        try {
            return {
                boardTiles: _aBoardTiles ? _aBoardTiles.length : null,
                myHand: _aPlayers && _aPlayers[0] ? _aPlayers[0].getTilesArray().length : null,
                oppHand: _aPlayers && _aPlayers[1] ? _aPlayers[1].getTilesArray().length : null,
                hasSide1: !!_oSide1Tile,
                hasSide2: !!_oSide2Tile,
                turn: _iTurn
            };
        } catch(e){ return { error: String(e) }; }
    };

    this.moveToBoard = function(oTile, iRotation, iSide) {
        var _iRotation = iRotation;
        var _iSide = iSide;
        var _oTile = oTile;

        // The very first tile of a round MUST go through CENTER_ATTACH --
        // that is the only branch that initialises _oSide1Tile/_oSide2Tile.
        // A remote or replayed move carries whatever `side` the server
        // logged, which for the opening tile can be LEFT or RIGHT. Taking
        // that at face value put the tile on the board and then bailed out
        // of the LEFT branch because there was no reference tile yet, so the
        // side refs stayed null and EVERY later move on that board failed
        // ("_oSide1Tile missing", "restore count mismatch local=3 server=7").
        // The board is empty exactly when neither side ref exists, so key
        // off that rather than trusting the incoming side.
        if (!_oSide1Tile && !_oSide2Tile) {
            _iSide = CENTER_ATTACH;
        }

        // Bail out BEFORE touching anything if we still can't attach. The
        // old checks lived inside the switch, by which point the tile had
        // already been removed from the player's hand and pushed onto
        // _aBoardTiles -- so a refused move left the board in a worse state
        // than before, with a counted tile that was never positioned or
        // linked (exactly the detached tile seen on screen).
        if (_iSide === SIDE_LEFT_ATTACH && !_oSide1Tile) {
            try { console.error(new Error("moveToBoard: _oSide1Tile missing on SIDE_LEFT_ATTACH (pre-check)")); } catch(e){}
            try { if (window.reportStuckMatch) window.reportStuckMatch("board_desync_side1"); } catch(e){}
            try { if (window.requestBoardSyncDiagnostic) window.requestBoardSyncDiagnostic("side1_missing"); } catch(e){}
            try { if (window.showBoardDesyncNotice) window.showBoardDesyncNotice(); } catch(e){}
            return;
        }
        if (_iSide === SIDE_RIGHT_ATTACH && !_oSide2Tile) {
            try { console.error(new Error("moveToBoard: _oSide2Tile missing on SIDE_RIGHT_ATTACH (pre-check)")); } catch(e){}
            try { if (window.reportStuckMatch) window.reportStuckMatch("board_desync_side2"); } catch(e){}
            try { if (window.requestBoardSyncDiagnostic) window.requestBoardSyncDiagnostic("side2_missing"); } catch(e){}
            try { if (window.showBoardDesyncNotice) window.showBoardDesyncNotice(); } catch(e){}
            return;
        }

        // ONLINE: this is MY move. Ask the server FIRST and do not touch the
        // board until it answers.
        //
        // This used to put the tile down and send the move in the same
        // breath. When the server then refused it -- "not_your_turn",
        // "illegal_placement" -- nothing took the tile back off, so this
        // phone carried an extra tile the server did not know about, and
        // every later move was judged against a board the two sides no
        // longer agreed on. That is the desync the players saw as the
        // board "breaking" halfway through a match.
        //
        // Waiting costs a moment of latency. In exchange, a refused move
        // simply does not happen: there is nothing to roll back, because
        // nothing was done.
        if (window.s_bOnline && _iTurn === 0 && !window.s_bApplyingRemote && window.s_oNetSend) {
            if (awaitingServerMove()) { return; }
            _bAwaitingServerMove = true;
            _iAwaitingSince = Date.now();

            var oSelf = this;
            var oPendingTile = oTile;
            var iPendingRotation = iRotation;
            var iPendingSide = iSide;

            window.s_oNetSend(
                { type: "move", value: oTile.getValue(), side: iSide, rotation: iRotation },
                function(bOk, sError){
                    // A zero here means the wait timed out and the board was
                    // already unblocked -- the authoritative state may have
                    // placed this very tile in the meantime. Playing it again
                    // would put two copies on the board, which is the exact
                    // failure the wait exists to prevent. Ask for the truth
                    // instead of replaying.
                    var bWaitExpired = (_iAwaitingSince === 0);
                    _bAwaitingServerMove = false;
                    _iAwaitingSince = 0;

                    if (bWaitExpired) {
                        try {
                            if (window.reportGlitch) {
                                window.reportGlitch("move answer arrived after the wait expired (" +
                                    (bOk ? "accepted" : ("refused: " + sError)) + ") -- resyncing instead of replaying");
                            }
                        } catch(e){}
                        try { if (window.dominoRequestState) window.dominoRequestState(); } catch(e){}
                        return;
                    }

                    if (!bOk) {
                        // Put the player back exactly where they were. The
                        // tile is still in their hand and still theirs to
                        // play -- it was never anywhere else.
                        try { if (oPendingTile.setUndrawn) oPendingTile.setUndrawn(); } catch(e){}
                        _bDrawnedTile = false;
                        try { oSelf.callShake(oPendingTile.getTile()); } catch(e){}
                        try {
                            if (window.reportGlitch) {
                                window.reportGlitch("move refused (" + sError + ") -- board left untouched");
                            }
                        } catch(e){}
                        return;
                    }

                    // Accepted. Replay it through this same function with the
                    // remote flag set, which skips the branch we are in now
                    // and runs the ordinary placement below.
                    window.s_bApplyingRemote = true;
                    try {
                        oSelf.moveToBoard(oPendingTile, iPendingRotation, iPendingSide);
                    } catch(e){
                        try {
                            if (window.reportGlitch) {
                                window.reportGlitch("confirmed move failed to apply: " + e.message);
                            }
                        } catch(e2){}
                    }
                    window.s_bApplyingRemote = false;
                }
            );
            return;
        }

        this.stopShake();
        _oTile.removeHitArea();
        var iValue = _oTile.getValue();
        
        // GET THE POSITION OF THE TILE FROM WHERE TO START OUR TWEEN
        var oContainer = _aPlayers[_iTurn].getContainer();
        var iPoint = oContainer.localToLocal(_oTile.getX(), _oTile.getY(), _oTilesContainer);
        var oNewTile = new CTile(_oTilesContainer, iValue, _iTurn, iPoint.x, iPoint.y);
        _aBoardTiles.push(oNewTile);
        
        playSound("select",1,0);
        
        // TURN THE TILE IF NEEDED
        if (oNewTile.isTurned() === false) {
            if (_iTurn === 0) {
                oNewTile.turnTileInvisible();
            } else {
                oNewTile.turnTile();
            }
        }
        
        _oTile.unload();
        _aPlayers[_iTurn].removeTile(_oTile);
        
        var iX = CANVAS_WIDTH_HALF/2;
        var iY = CANVAS_HEIGHT_HALF/2 + _iTilesContainerOffsetY*2;
        var iOffset;
        
        var iAngleOffset = TILE_WIDTH/4.5;
        
        // UPDATE THE VALUES TO MOVE
        switch (_iSide) {
            case CENTER_ATTACH: // ONLY FOR THE FIRST TILE OF THE GAME
                _oSide1Tile = _oSide2Tile = oNewTile;
                _iSide1Value = oNewTile.getDotsValue(0);
                _iSide2Value = oNewTile.getDotsValue(1);
                
                this.startTileMovement(oNewTile, iX, iY, _iRotation);
                break;
            case SIDE_LEFT_ATTACH: // LEFT SIDE
                if (!_oSide1Tile) {
                    // Board desync: no reference tile to attach to. This can't
                    // be positioned sensibly, so stop here rather than crash
                    // (which used to hang the whole match with no explanation)
                    // and flag the match so it gets reviewed/refunded.
                    try { console.error(new Error("moveToBoard: _oSide1Tile missing on SIDE_LEFT_ATTACH")); } catch(e){}
                    try { if (window.reportStuckMatch) window.reportStuckMatch("board_desync_side1"); } catch(e){}
                    try { if (window.requestBoardSyncDiagnostic) window.requestBoardSyncDiagnostic("side1_missing"); } catch(e){}
                    try { if (window.showBoardDesyncNotice) window.showBoardDesyncNotice(); } catch(e){}
                    return;
                }
                if ( oTile.isDouble() || _oSide1Tile.isDouble() ) {
                    iOffset = _iOffsetDouble;
                } else {
                    iOffset = _iOffsetTiles;
                }
                
                // SAVE THE NEW VALUE OF THIS SIDE
                if (_iRotation > 0) { 
                    _iSide1Value = oNewTile.getDotsValue(1);
                } else {
                    _iSide1Value = oNewTile.getDotsValue(0);
                }
                
                if (_iDrawnTilesSide1 < DRAWNTILES_LIMIT1) {
                    iX = _oSide1Tile.getX() - iOffset;
                    iY = _oSide1Tile.getY();
                } else if (_iDrawnTilesSide1 === DRAWNTILES_LIMIT1-1) {
                    iX = _oSide1Tile.getX();
                    iY = _oSide1Tile.getY() - iOffset;
                    if (oTile.isDouble() === false) {
                        _iRotation += 90;
                    }
                } else if (_iDrawnTilesSide1 === DRAWNTILES_LIMIT1) {
                    iX = _oSide1Tile.getX();
                    if (oTile.isDouble() || _oSide1Tile.isDouble() ) {
                        if ( oTile.isDouble() && _oSide1Tile.isDouble()) {
                            // BOTH DOUBLE
                            iX -= iAngleOffset;
                            iY = _oSide1Tile.getY() - iOffset*1.25;
                        } else {
                            if (oTile.isDouble()) {
                                // 2ND DOUBLE
                                iX -= iAngleOffset*1.1;
                                iY = _oSide1Tile.getY() - iOffset*0.7;
                            } else {
                                // 1ST DOUBLE
                                iY = _oSide1Tile.getY() - iOffset*1.3;
                            }
                        }
                    } else {
                        // BOTH SINGLE
                        iX -= iAngleOffset;
                        iY = _oSide1Tile.getY() - iOffset*0.8;
                    }
                    _iRotation += 90;
                } else if (_iDrawnTilesSide1 < DRAWNTILES_LIMIT2) {
                    iX = _oSide1Tile.getX();
                    iY = _oSide1Tile.getY() - iOffset;
                    _iRotation += 90;
                } else if (_iDrawnTilesSide1 === DRAWNTILES_LIMIT2-1) {
                    iX = _oSide1Tile.getX() + iOffset;
                    iY = _oSide1Tile.getY();
                    if (oTile.isDouble() === false) {
                        _iRotation += 180;
                    }
                } else if (_iDrawnTilesSide1 === DRAWNTILES_LIMIT2) {
                    iY = _oSide1Tile.getY();
                    if (oTile.isDouble() || _oSide1Tile.isDouble() ) {
                        if ( oTile.isDouble() && _oSide1Tile.isDouble()) {
                            // BOTH DOUBLE
                            iX = _oSide1Tile.getX() + iOffset*1.25;
                            iY -= iAngleOffset;
                        } else {
                            if (oTile.isDouble()) {
                                // 2ND DOUBLE                                   
                                iX = _oSide1Tile.getX() + iOffset*0.7;
                                iY -= iAngleOffset*1.1;
                            } else {
                                // 1ST DOUBLE                                   
                                iX = _oSide1Tile.getX() + iOffset*1.3;
                            }
                        }
                    } else {
                        // BOTH SINGLE
                        iX = _oSide1Tile.getX() + iOffset*0.8;
                        iY -= iAngleOffset;
                    }
                    _iRotation += 180;
                } else if (_iDrawnTilesSide1 >= DRAWNTILES_LIMIT3) {
                    // Long-chain continuation: keep following side 1 with the
                    // normal domino spacing. The old iAngleOffset*3.2 step was
                    // much shorter than a tile and made late-game tiles overlap.
                    iX = _oSide1Tile.getX();
                    iY = _oSide1Tile.getY() + iOffset;
                    _iRotation += 180;
                } else {
                    _iRotation += 180;
                    iX = _oSide1Tile.getX() + iOffset;
                    iY = _oSide1Tile.getY();
                }
                
                _oSide1Tile = oNewTile;
                _iDrawnTilesSide1 += 1;
                this.startTileMovement(oNewTile, iX, iY, _iRotation);
                break;
            case SIDE_RIGHT_ATTACH: // RIGHT SIDE
                if (!_oSide2Tile) {
                    try { console.error(new Error("moveToBoard: _oSide2Tile missing on SIDE_RIGHT_ATTACH")); } catch(e){}
                    try { if (window.reportStuckMatch) window.reportStuckMatch("board_desync_side2"); } catch(e){}
                    try { if (window.requestBoardSyncDiagnostic) window.requestBoardSyncDiagnostic("side2_missing"); } catch(e){}
                    try { if (window.showBoardDesyncNotice) window.showBoardDesyncNotice(); } catch(e){}
                    return;
                }
                if ( oTile.isDouble() || _oSide2Tile.isDouble() ) {
                    iOffset = _iOffsetDouble;
                } else {
                    iOffset = _iOffsetTiles;
                }

                // SAVE THE NEW VALUE OF THIS SIDE
                if (_iRotation > 0) { 
                    _iSide2Value = oNewTile.getDotsValue(0);
                } else {
                    _iSide2Value = oNewTile.getDotsValue(1);
                }
                
                if (_iDrawnTilesSide2 < DRAWNTILES_LIMIT1) {
                    iX = _oSide2Tile.getX() + iOffset;
                    iY = _oSide2Tile.getY();
                } else if (_iDrawnTilesSide2 === DRAWNTILES_LIMIT1-1) {
                    iX = _oSide2Tile.getX();
                    iY = _oSide2Tile.getY() + iOffset;
                    if (oTile.isDouble() === false) {
                        _iRotation += 90;
                    }
                } else if (_iDrawnTilesSide2 === DRAWNTILES_LIMIT1) {
                    iX = _oSide2Tile.getX();
                    if (oTile.isDouble() || _oSide2Tile.isDouble() ) {
                        if ( oTile.isDouble() && _oSide2Tile.isDouble()) {
                            // BOTH DOUBLE
                            iX += iAngleOffset;
                            iY = _oSide2Tile.getY() + iOffset*1.25;
                        } else {
                            if (oTile.isDouble()) {
                                // 2ND DOUBLE
                                iX += iAngleOffset*1.1;
                                iY = _oSide2Tile.getY() + iOffset*0.7;
                            } else {
                                // 1ST DOUBLE
                                iY = _oSide2Tile.getY() + iOffset*1.3;
                            }
                        }
                    } else {
                        // BOTH SINGLE
                        iX += iAngleOffset;
                        iY = _oSide2Tile.getY() + iOffset*0.8;
                    }
                    _iRotation += 90;
                } else if (_iDrawnTilesSide2 < DRAWNTILES_LIMIT2) {
                    iX = _oSide2Tile.getX();
                    iY = _oSide2Tile.getY() + iOffset;
                    _iRotation += 90;
                } else if (_iDrawnTilesSide2 === DRAWNTILES_LIMIT2-1) {
                    iX = _oSide2Tile.getX() - iOffset;
                    iY = _oSide2Tile.getY();
                    if (oTile.isDouble() === false) {
                        _iRotation += 180;
                    }
                } else if (_iDrawnTilesSide2 === DRAWNTILES_LIMIT2) {
                    iY = _oSide2Tile.getY();
                    if (oTile.isDouble() || _oSide2Tile.isDouble() ) {
                        if ( oTile.isDouble() && _oSide2Tile.isDouble()) {
                            // BOTH DOUBLE
                            iX = _oSide2Tile.getX() - iOffset*1.25;
                            iY -= iAngleOffset;
                        } else {
                            if (oTile.isDouble()) {
                                // 2ND DOUBLE
                                iX = _oSide2Tile.getX() - iOffset*0.7;
                                iY += iAngleOffset*1.1;
                            } else {
                                // 1ST DOUBLE
                                iX = _oSide2Tile.getX() - iOffset*1.3;
                            }
                        }
                    } else {
                        // BOTH SINGLE
                        iX = _oSide2Tile.getX() - iOffset*0.8;
                        iY += iAngleOffset;
                    }
                    _iRotation += 180;
                } else if (_iDrawnTilesSide2 >= DRAWNTILES_LIMIT3) {
                    // Long-chain continuation must anchor to SIDE 2 itself.
                    // Using _oSide1Tile here crossed the two chain ends and
                    // caused tiles to stack on top of one another.
                    iX = _oSide2Tile.getX();
                    iY = _oSide2Tile.getY() - iOffset;
                    _iRotation += 180;
                } else {
                    _iRotation += 180;
                    iX = _oSide2Tile.getX() - iOffset;
                    iY = _oSide2Tile.getY();
                }
                 
                _oSide2Tile = oNewTile;
                _iDrawnTilesSide2 += 1;
                this.startTileMovement(oNewTile, iX, iY, _iRotation);
                break;
        };
    };


    this.centerPlayedChain = function(){
        if (!_aBoardTiles || !_aBoardTiles.length) return;

        var minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
        for (var i=0; i<_aBoardTiles.length; i++){
            var t = _aBoardTiles[i];
            if (!t || !t.getTile || !t.getTile()) continue;
            var sp = t.getTile();
            var rad = (Math.abs(sp.rotation % 180) === 90) ? (TILE_HEIGHT*TILE_INIT_SCALE/2) : (TILE_WIDTH*TILE_INIT_SCALE/2);
            var rady = (Math.abs(sp.rotation % 180) === 90) ? (TILE_WIDTH*TILE_INIT_SCALE/2) : (TILE_HEIGHT*TILE_INIT_SCALE/2);
            minX = Math.min(minX, t.getX()-rad);
            maxX = Math.max(maxX, t.getX()+rad);
            minY = Math.min(minY, t.getY()-rady);
            maxY = Math.max(maxY, t.getY()+rady);
        }
        if (!isFinite(minX)) return;

        // Auto-fit: shrink the board so a long chain always stays inside the
        // green felt. Previously _iScale was a fixed 0.68, so once the chain
        // grew past the felt's width the end tiles simply ran off the table.
        // We only ever scale DOWN from the base scale — a short chain keeps
        // the comfortable default size.
        var chainW = (maxX - minX);
        var chainH = (maxY - minY);
        var FIT_W = 600;   // usable felt width  (green area, minus a margin)
        var FIT_H = 700;   // usable felt height (between opponent hand and player card)
        var fit = Math.min(FIT_W / Math.max(chainW, 1), FIT_H / Math.max(chainH, 1));
        var wanted = Math.min(_iBaseScale, _iBaseScale * fit);
        if (wanted < 0.28) wanted = 0.28;   // floor, so tiles never get unreadable
        _iScale = wanted;
        _oTilesContainer.scaleX = _oTilesContainer.scaleY = _iScale;

        // Desired visual center of the green playing field in this container's local coordinates.
        // X is exact screen center; Y is slightly above geometric center to leave room for the hand/profile.
        var targetGlobalX = CANVAS_WIDTH_HALF;
        var targetGlobalY = 760;
        var targetLocalX = (targetGlobalX - _oTilesContainer.x) / _oTilesContainer.scaleX;
        var targetLocalY = (targetGlobalY - _oTilesContainer.y) / _oTilesContainer.scaleY;

        var dx = targetLocalX - (minX + maxX)/2;
        var dy = targetLocalY - (minY + maxY)/2;

        for (var j=0; j<_aBoardTiles.length; j++){
            var bt = _aBoardTiles[j];
            if (!bt || !bt.getTile || !bt.getTile()) continue;
            bt.setXImmediate(bt.getX()+dx);
            bt.setYImmediate(bt.getY()+dy);
        }
    };

    // Re-align the board from scratch: snap every board tile to the exact
    // position its logical coordinates say it should be at, then re-center.
    // Used as a self-heal after a burst of moves (lag spike / reconnect),
    // where a tile could otherwise be left visually stranded at a stale
    // spot while the rest of the chain has already shifted around it.
    this.resyncBoardPositions = function(){
        if (!_aBoardTiles || !_aBoardTiles.length) return;
        for (var i=0; i<_aBoardTiles.length; i++){
            var bt = _aBoardTiles[i];
            if (!bt || !bt.getTile || !bt.getTile()) continue;
            var sp = bt.getTile();
            // Whatever the logical x/y is, force the sprite to match it.
            sp.x = bt.getX();
            sp.y = bt.getY();
        }
        this.centerPlayedChain();
    };

    this.zoomCamera = function(){
        // Fixed camera: the reference UI keeps a stable table and tile scale.
        _oTilesContainer.scaleX = _oTilesContainer.scaleY = _iScale;
    };
    
    this.startTileMovement = function(oTile, iX, iY, iRotation) {
        var oTileSprite = oTile.getTile();
        var iMovementSpeed = 750;

        oTile.removeHitArea();
        oTile.setPlayerTile(false);
        
        // SET THE TILE INDEX ON TOP OF THE OTHERS
        _oTilesContainer.setChildIndex( oTileSprite, _oTilesContainer.numChildren - 1);
        
        // COMPENSATE THE ZOOM, BACK TO THE ORIGINAL SCALE
        var iScaleVar = 1 - _iScale;
        oTileSprite.scaleX += iScaleVar;
        oTileSprite.scaleY += iScaleVar;
        
        // MOVE THE TILE — a single smooth glide into place with a gentle
        // ease-out settle, instead of the old "accelerate in, then pop
        // bigger, then shrink back" bounce, which read as a jerky throw.
        // The tile now decelerates naturally as it lands and finishes at
        // exactly its normal size, so nothing overshoots or snaps.
        _bTileAnimating = true;
        new createjs.Tween(oTileSprite)
            .to({ x: iX, y: iY, rotation: iRotation, scaleX: TILE_INIT_SCALE, scaleY: TILE_INIT_SCALE}, Math.round(iMovementSpeed * 1.35), createjs.Ease.quintOut)
            .call( function() {
                playSound("tile",0.2,0);
                s_oGame.centerPlayedChain();
                if (iX !== 0 || iY !== 0) {
                    s_oGame.zoomCamera();      // CAMERA "ZOOM" EFFECT
                }
                s_oGame.checkAfterTileMoved(); // CHECK FOR DOMINO OR NEXT TURN
                _bTileAnimating = false;
                s_oGame._drainRemoteMoveQueue(); // apply any move that arrived mid-animation

                // Safety net: verify every board tile actually sits where its
                // logical position says. A tile whose tween got interrupted
                // (backgrounded tab, lag spike) can otherwise be left visually
                // stranded on top of the chain. Cheap to check, and only
                // corrects when something is genuinely out of place.
                setTimeout(function(){
                    try {
                        if (_bTileAnimating || _aRemoteMoveQueue.length) return;
                        var aBT = s_oGame.getBoardTiles ? s_oGame.getBoardTiles() : null;
                        if (!aBT) return;
                        for (var k = 0; k < aBT.length; k++) {
                            var bt = aBT[k];
                            if (!bt || !bt.getTile || !bt.getTile()) continue;
                            var sp = bt.getTile();
                            if (Math.abs(sp.x - bt.getX()) > 2 || Math.abs(sp.y - bt.getY()) > 2) {
                                s_oGame.resyncBoardPositions();
                                return;
                            }
                        }
                    } catch(e){}
                }, 120);
            });
    };
    
    this.checkAfterTileMoved = function(){
        if (s_oGame.checkForDomino(_iTurn) === true) {
            _bDomino = true;
            _bStartGame = false;
            s_oGame.showDominoText();
            return;
        } else {
            _aPlayers[_iTurn].arrangeTiles();
            s_oGame.changeTurn();
        }
    };
    
    this.checkFirstTile = function() {
        _bGameReady = true;
        // The new deal is now actually on screen. Until this point any
        // authoritative state from the server describes a round this screen
        // is not showing yet -- applying it rewrote the hand of whatever
        // game instance happened to still be around (the "hand corrected:
        // 7 tile(s)" that wiped a full hand during the VS splash).
        try { window.YD_DEAL_PENDING = false; } catch(e){}
        
        var iFirstPlayer;           // THE FIRST PLAYER TO PLAY
        var iFirstTileValue = 0;    // THE FIRST TILE'S VALUE
        var oFirstTile;             // THE FIRST TILE TO BE DRAWN
        
        // CHECK THE FIRST TILE TO BE DRAWN (THE HIGHEST-VALUE DOUBLE)
        // SO WE'LL ALSO HAVE THE FIRST PLAYER TO PLAY.
        for (var i = 0; i < _iPlayers; i++) {
            var aTilesArray = _aPlayers[i].getTilesArray();
            
            for (var j = 0; j < aTilesArray.length; j++) {
                var iValue = aTilesArray[j].getDotsValue(0)+aTilesArray[j].getDotsValue(1);
                
                if (iValue >= iFirstTileValue) {
                    if ( aTilesArray[j].isDouble() ) {
                        iFirstTileValue = aTilesArray[j].getDotsValue(0)+aTilesArray[j].getDotsValue(1);
                        oFirstTile = j;
                        iFirstPlayer = i; };
                }
            };
        };
        
        // IF THERE'S NO DOUBLE TO CHOOSE, CHOOSE THE HIGHEST VALUE TILE
        if (iFirstTileValue === 0) {
            for (var i = 0; i < _iPlayers; i++) {
                var aTilesArray = _aPlayers[i].getTilesArray();

                for (var j = 0; j < aTilesArray.length; j++) {
                    var iValue = aTilesArray[j].getDotsValue(0)+aTilesArray[j].getDotsValue(1);
                    
                    if (iValue >= iFirstTileValue) {
                        iFirstTileValue = aTilesArray[j].getDotsValue(0)+aTilesArray[j].getDotsValue(1);
                        oFirstTile = j;
                        iFirstPlayer = i; 
                    }
                };
            };
        }

        if (window.s_bOnline && window.s_oOnlineDeal) {
            // ONLINE: server decides who starts (my seat vs starter seat)
            iFirstPlayer = (window.s_oOnlineDeal.starterSeat === window.s_oOnlineDeal.seat) ? 0 : 1;
        }
        _iTurn = iFirstPlayer;
        var aTilesArray = _aPlayers[iFirstPlayer].getTilesArray();
        var oTile = aTilesArray[oFirstTile];
        // oFirstTile came from the double-search loop above, which runs BEFORE
        // the online correction can overwrite iFirstPlayer. When the server's
        // starter seat differs from what that local search found -- routine
        // during a resync, where the opponent's hand is a placeholder of
        // blank tiles and looks like "the" highest double -- oFirstTile
        // indexes into the WRONG player's hand and can land past its end.
        // That threw "Cannot read properties of undefined (reading
        // 'setGlowVisible')" and aborted the rest of deal setup, which is why
        // the face-down tiles stayed stuck at the top of the table forever.
        // The glow is purely cosmetic, so fall back rather than crash.
        if (!oTile && aTilesArray.length) { oTile = aTilesArray[0]; }

        if (iFirstPlayer === 0) {
            if (s_bGlowActive && oTile) {
                oTile.setGlowVisible(true);
            }
            _oBlockInput.visible = false;
        } else if (iFirstPlayer > 0) {
            if (window.s_bOnline) {
                // ONLINE: opponent starts; wait for their first move via network
                _oBlockInput.visible = true;
            } else if (oTile) {
                this.checkClickedTile(oTile);
            }
        }
        _aPlayers[_iTurn].setTurn(true);
        this.setTurnVisibility();
    };
    
    this._checkGame = function() {
        if (_bMatchOver === true) {
            return; }

        if (_bFirstTile === true) {
            _bFirstTile = false; }

        if (!_bDrawnedTile) {
            // IF IT'S THE HUMAN PLAYER'S TURN, CHECK THE TILES
            if (_iTurn === 0) {
                _oBlockInput.visible = false;
                s_oGame.checkToDrawn();
            // IF IT'S A CPU PLAYER'S TURN, CHECK THE TILES TO DRAW THE BEST
            } else {
                _oBlockInput.visible = true;
                if (window.s_bOnline) {
                    // ONLINE: opponent's move arrives via the network; do nothing here
                } else if (_bDomino === true) {
                    return;
                } else {
                    s_oGame.cpuDrawTile();
                }
            }
        }

        // CHECK HOW MANY PLAYERS ARE LOCKED
        if (_bDomino === false) {
            s_oGame.checkLockedPlayers();
        }
    };
    
    this.checkForDomino = function(i) {        
        var aTilesArray = _aPlayers[i].getTilesArray();
        // IF A PLAYER HAS FINISHED HIS TILES, THE MATCH IS OVER (DOMINO)
        if (aTilesArray.length === 0) {
            return true;
        } else {
            return false;
        }
    };
    
    this.showDominoText = function() {
        var iSpeedStart = 500;

        // SHOW THE TILES
        for (var i = 0; i < _iPlayers; i++) {
            var aTilesArray = _aPlayers[i].getTilesArray();
            
            for (var j = 0; j < aTilesArray.length; j++) {
                var oTile = aTilesArray[j];
                if (i > 0) {
                    oTile.turnTile();
                }
            };
        };

        // The opponent's index-1 hand is our own local best guess -- its
        // real unplayed tiles are legitimately hidden from us, the same as
        // in a real game, so this is only ever an estimate (often 0, from
        // placeholder tiles). Our own index-0 hand is always exactly known
        // (it's our own hand), so it never needs correcting. Use the guess
        // as an immediate fallback while we ask the server -- which tracks
        // both real hands for move-legality checks -- for the true number.
        var iLocalOpponentGuess = s_oGame.totalTilesValue(1);

        var finalizeAndShowDomino = function(iOpponentTotal){
            _iPendingWinnerPoints = 0;
            for (var p = 0; p < _iPlayers; p++) {
                var val = (p === 1) ? iOpponentTotal : s_oGame.totalTilesValue(p);
                if (p !== _iTurn) {
                    _iPendingWinnerPoints += val;
                } else {
                    _iPendingWinnerPoints -= val;
                }
            }

            // SHOW A "DOMINO" MESSAGE, THIS PLAYER WINS THIS ROUND
            var iPlayerN = _iTurn+1;
            var sWinnerName = (_iTurn === 0 && window.DOMINO_P0_NAME) ? window.DOMINO_P0_NAME
                             : (_iTurn === 1 && window.DOMINO_P1_NAME) ? window.DOMINO_P1_NAME
                             : (TEXT_PLAYER + " " + iPlayerN);
            _oDominoText.refreshText(sWinnerName + " " + TEXT_DOMINO);
            _oDominoPointsText.refreshText("");
            _oDominoPointsText.alpha = 0;

            _oMsgContainerDomino.scaleX = _oMsgContainerDomino.scaleY = 0.7;
            new createjs.Tween.get(_oMsgContainerDomino)
                .to({alpha: 1, scaleX: 1.06, scaleY: 1.06}, iSpeedStart, createjs.Ease.backOut)
                .to({scaleX: 1, scaleY: 1}, 140, createjs.Ease.cubicOut)
                .call(function(){
                    // ANIMATE THE POINTS COUNTING UP, e.g. "+42 points"
                    var iTarget = _iPendingWinnerPoints;
                    var sSign = iTarget >= 0 ? "+" : "";
                    new createjs.Tween.get(_oDominoPointsText)
                        .to({alpha: 1}, 200);
                    var iStart = Date.now(), iDur = 650, iFrom = 0;
                    var counterId = setInterval(function(){
                        var t = Math.min(1, (Date.now()-iStart)/iDur);
                        var eased = 1 - Math.pow(1-t, 3); // cubic-out
                        var iVal = Math.round(iFrom + (iTarget-iFrom)*eased);
                        _oDominoPointsText.refreshText(sSign + iVal + " pts");
                        if (t >= 1) { clearInterval(counterId); }
                    }, 30);
                });
            
            playSound("domino",1,0);

            // Auto-continue once the points animation has had time to play —
            // safe now that the real desync causes are fixed (see the LOCKED
            // popup fix above). The manual tap on the continue button still works.
            setTimeout(function(){
                if (_oMsgContainerDomino && _oMsgContainerDomino.alpha >= 1) {
                    try { s_oGame._onDominoContinue(); } catch(e){}
                }
            }, 1400);
        };

        if (window.s_bOnline && window.s_oNetGetHandTotals) {
            // ONLINE: never fall back to a private guess of the hidden hand.
            // A slow/lost ACK used to make one phone score locally after 900ms
            // while the other phone received the server total, creating the
            // intermittent one-sided score drift.  Wait for the authoritative
            // server result; net_online retries the request for us.
            window.s_oNetGetHandTotals(function(resp){
                if (!resp || !resp.ok) {
                    try { if (window.reportGlitch) window.reportGlitch("round score sync unavailable; score not advanced"); } catch(e){}
                    return;
                }
                _iPendingWinnerPoints = Number(resp.points || 0);
                _iTurn = Number(resp.winnerLocal) === 1 ? 1 : 0;
                if (resp.scores && resp.scores.length >= 2) {
                    _aScore[0] = Number(resp.scores[0] || 0);
                    _aScore[1] = Number(resp.scores[1] || 0);
                    _bAuthoritativeScoreApplied = true;
                    s_oGame.saveScore();
                }
                finalizeAndShowDomino(Number(resp.opponent || 0));
                // finalizeAndShowDomino derives the same delta; force the exact
                // server value after it runs so both phones persist one result.
                _iPendingWinnerPoints = Number(resp.points || 0);
            });
        } else {
            finalizeAndShowDomino(iLocalOpponentGuess);
        }
    };

    this._onLockedContinue = function() {
        if (_oMsgContainerLocked.alpha < 1) {
            return;
        }
        
        // IF THE GAME IS NOT OVER YET, CHANGE TURN
        if (_bMatchOver === false) {
            new createjs.Tween.get(_oMsgContainerLocked)
                .to({alpha: 0}, 500, createjs.Ease.cubicIn)
                .call(s_oGame.changeTurn);
        // IF THE GAME IS OVER
        } else {
            if (window.s_bOnline && window.s_oNetGetHandTotals) {
                // Locked round: use the same authoritative server calculation
                // on both phones instead of each client scoring hidden tiles.
                window.s_oNetGetHandTotals(function(resp){
                    if (!resp || !resp.ok) {
                        try { if (window.reportGlitch) window.reportGlitch("locked round score sync unavailable; waiting"); } catch(e){}
                        return;
                    }
                    _iWinnerPlayer = Number(resp.winnerLocal) === 1 ? 1 : 0;
                    _iWinnerPoints = Number(resp.points || 0);
                    if (resp.scores && resp.scores.length >= 2) {
                        _aScore[0] = Number(resp.scores[0] || 0);
                        _aScore[1] = Number(resp.scores[1] || 0);
                        _bAuthoritativeScoreApplied = true;
                        s_oGame.saveScore();
                    }
                    s_oGame.matchOver();
                });
            } else {
                s_oGame.getMatchWinnerScore();
                s_oGame.matchOver();
            }
        }
    };
    
    this._onDominoContinue = function() {
        if (_oMsgContainerDomino.alpha < 1) {
            return;
        }
        
        // Points were already calculated (and animated) in showDominoText —
        // reuse that value here instead of recomputing it.
        _iWinnerPoints += _iPendingWinnerPoints;
        _iWinnerPlayer = _iTurn;        
        
        s_oGame.matchOver();
    };
    
    this.checkLockedPlayers = function() {
        // CHECK THE ACTUAL SITUATION OF THE GAME
        for (var i = 0; i < _iPlayers; i++) {
            if ( s_oGame.checkForDomino(i) === false) {
                // CHECK HOW MANY PLAYERS ARE LOCKED
                if ( _aPlayers[i].getLocked() === true) {
                    _aLockedPlayers[i] = true;
                } else {
                    _aLockedPlayers[i] = false;
                }
                
                // IF THERE'S A "LOCKED" SITUATION, IT'S MATCH OVER
                this.checkLockedMatch();
            }
        };
    };
    
    this.checkLockedMatch = function() {
        if (_iPlayers === 2) {
            if (_aLockedPlayers[0] === true &&
                _aLockedPlayers[1] === true ) {
                _bMatchOver = true;
            } else {
                _bMatchOver = false;
            }
        } else if (_iPlayers === 3) {
            if (_aLockedPlayers[0] === true &&
                _aLockedPlayers[1] === true &&
                _aLockedPlayers[2] === true ) {
                _bMatchOver = true;
            } else {
                _bMatchOver = false;
            }
        } else if (_iPlayers === 4) {
            if (_aLockedPlayers[0] === true &&
                _aLockedPlayers[1] === true &&
                _aLockedPlayers[2] === true &&
                _aLockedPlayers[3] === true ) {
                _bMatchOver = true;
            } else {
                _bMatchOver = false;
            }
        }
    };
    
    this.totalTilesValue = function(iPlayer) {
        var aTilesArray = _aPlayers[iPlayer].getTilesArray();
        var iPlayerTilesValue = 0;
        
        for (var i = 0; i < aTilesArray.length; i++) {
            var oTile = aTilesArray[i];
            if (iPlayer > 0) {
                oTile.turnTile();
            }
            iPlayerTilesValue += oTile.getDotsValue(0) + oTile.getDotsValue(1);
        };
        
        return iPlayerTilesValue;   // THE TOTAL VALUE OF THE ARRAY
    };
    
    this.getMatchWinnerScore = function(iOpponentOverride){
        if (_bMatchLocked) {
            return;
        }
        
        // CALCULATE HOW MANY POINTS EACH PLAYER HAS SCORED
        // Index 1 (opponent) is our own guess unless the caller already
        // fetched the server's authoritative total (see _onLockedContinue)
        // -- our own index-0 hand is always exactly known and never needs
        // correcting.
        var aMatchScores = new Array();
        for (var i = 0; i < _iPlayers; i++) {
            var iPlayerTilesValue = (i === 1 && typeof iOpponentOverride === "number")
                ? iOpponentOverride
                : s_oGame.totalTilesValue(i);
            aMatchScores[i] = [i, iPlayerTilesValue];
        };

        // THE WINNER IS THE PLAYER WITH THE LOWEST TILE VALUE
        aMatchScores.sort(function(a, b) {
            var valueA, valueB;

            valueA = a[1]; // 1 is the PlayerTilesValue
            valueB = b[1];
            if (valueA < valueB) {
                return -1;
            }
            else if (valueA > valueB) {
                return 1;
            }
            return 0;
        });

        // THE WINNER SCORE IS THE TOTAL OF THE OTHER PLAYER'S POINTS MINUS HIS/HER SCORE
        for (var i = 1; i < aMatchScores.length; i++) {
            _iWinnerPoints += aMatchScores[i][1];
        }; 
        _iWinnerPoints -= aMatchScores[0][1];
        _iWinnerPlayer = aMatchScores[0][0];
    };
    
    this.lockedMatch = function() {
        s_oGame.getMatchWinnerScore();
        _bMatchLocked = true;
    };
    
    this.resetScore = function(iPlayers){
        // RESET THE SAVED SCORES (FOR NEXT GAMES)        
        switch (iPlayers) {
            case 2:
                s_aPlayersScore2 = [0,0];
                setItemJson("classicdomino_scores2", s_aPlayersScore2);
                _aScore = s_aPlayersScore2;
                break;
            case 3:
                s_aPlayersScore3 = [0,0,0];
                setItemJson("classicdomino_scores3", s_aPlayersScore3);
                _aScore = s_aPlayersScore3;
                break;
            case 4:
                s_aPlayersScore4 = [0,0,0,0];
                setItemJson("classicdomino_scores4", s_aPlayersScore4);
                _aScore = s_aPlayersScore4;
                break;
        }
    };
    
    // Apply a cumulative score handed down by the server.
    //
    // Called from net_online when the room pushes 'round_score'. This is the
    // only path that works on BOTH phones every time: a phone that never
    // decided the blocked round was over would otherwise never ask for the
    // score, and would sit showing the previous total forever while the
    // other phone showed the new one.
    this.applyAuthoritativeScores = function(aScores){
        if (!aScores || aScores.length < 2) return;
        var a = Number(aScores[0] || 0);
        var b = Number(aScores[1] || 0);
        if (_aScore[0] === a && _aScore[1] === b) return;   // nothing new
        _aScore[0] = a;
        _aScore[1] = b;
        _bAuthoritativeScoreApplied = true;
        try { s_oGame.saveScore(); } catch(e){}
        // The panels only pick up _aScore when they are rebuilt, so refresh
        // them by hand -- otherwise the number on screen stays stale until
        // the next deal.
        for (var i = 0; i < _aPlayers.length && i < _aScore.length; i++) {
            try {
                if (_aPlayers[i] && _aPlayers[i].updateScoreText) {
                    _aPlayers[i].updateScoreText(_aScore[i]);
                }
            } catch(e){}
        }
        try { console.log("[score] server totals applied: " + _aScore[0] + "-" + _aScore[1]); } catch(e){}
    };

    this.saveScore = function(){
        switch(_iPlayers) {
            case 2: 
                setItemJson("classicdomino_scores2", _aScore);
                for (var i = 0; i < _aScore.length; i++) {
                    s_aPlayersScore2[i] = _aScore[i];
                };
                break;
            case 3: 
                setItemJson("classicdomino_scores3", _aScore);
                for (var i = 0; i < _aScore.length; i++) {
                    s_aPlayersScore3[i] = _aScore[i];
                };
                break;
            case 4: 
                setItemJson("classicdomino_scores4", _aScore);
                for (var i = 0; i < _aScore.length; i++) {
                    s_aPlayersScore4[i] = _aScore[i];
                };
                break;
        };
    };
    
    this.matchOver = function() {
        // ONLINE SCORE-SYNC-FINAL: when the server already supplied cumulative
        // totals for this round, never add the points again locally. Offline/bot
        // games keep the original local scoring path unchanged.
        if (window.s_bOnline && _bAuthoritativeScoreApplied) {
            _bAuthoritativeScoreApplied = false;
            this.saveScore();
        } else {
            _aScore[_iWinnerPlayer] += _iWinnerPoints;
            this.saveScore();
        }

        // Stop any running turn-countdown ring — the match (or this round)
        // has ended, so no player's timer should keep animating.
        for (var iP = 0; iP < _iPlayers; iP++) {
            if (_aPlayers[iP] && _aPlayers[iP].stopTurnRing) _aPlayers[iP].stopTurnRing();
        }

        // CHECK IF THERE'S A PLAYER WITH THE MAX SCORE (GAME OVER - WIN/LOSE)
        this.checkForWinner();
    };
    
    this.checkForWinner = function() {
        var bMatchOver = false;
        try {
            if (window.reportGlitch) {
                window.reportGlitch("round ended: scores " + _aScore[0] + "-" + _aScore[1] +
                    " (winner seat " + _iWinnerPlayer + ", +" + _iWinnerPoints + ")");
            }
        } catch(e){}

        for (var i = 0; i < _iPlayers; i++) {
            // THE GAME IS OVER WHEN A PLAYER REACHES 100 POINTS (score goal is always 100;
            // the coin value 100/200/500 is only the ENTRY stake, not the score target)
            if (_aScore[i] >= 100) {
                bMatchOver = true;
                // IF THE HUMAN PLAYER WINS THE GAME
                if (i === 0) {
                    _bWin = true;
                    this._checkWin();
                    if (!_bResultReported) {
                        _bResultReported = true;
                        if (window.s_bOnline && window.dominoOnlineReportResult) {
                            window.dominoOnlineReportResult(true);
                        } else if (window.dominoReportResult) {
                            window.dominoReportResult(true);
                        }
                    }
                // IF A CPU PLAYER WINS THE GAME
                } else {
                    this._gameOver();
                    if (!_bResultReported) {
                        _bResultReported = true;
                        if (window.s_bOnline && window.dominoOnlineReportResult) {
                            window.dominoOnlineReportResult(false);
                        } else if (window.dominoReportResult) {
                            window.dominoReportResult(false);
                        }
                    }
                }
            }
        };
        
        // THE GAME IS NOT OVER YET, NEW MATCH!
        if (bMatchOver === false) {
            // SHOW A "MATCH OVER" MESSAGE WITH PLAYERS' SCORES
            this.matchOverScreen();
        }
    };
    
    this.matchOverScreen = function() {
        _bStartGame = false;

        // The round-summary "MATCH OVER" panel has been removed per request.
        // Go straight to the next round after a short pause, no panel shown.
        if (!_bAutoRoundAdvancing) {
            _bAutoRoundAdvancing = true;
            playSound("match_over",1,0);

            setTimeout(function(){
                _bAutoRoundAdvancing = false;
                try { if (window.reportGlitch) window.reportGlitch("requesting next round"); } catch(e){}
                if (window.s_bOnline && window.dominoRequestNextRound) {
                    // Real online match: ask the server to deal round 2+ so
                    // both players get the SAME fresh hands. Locally
                    // reshuffling here (the old behaviour) desynced the two
                    // boards and left both players unable to play.
                    // s_oGame.restart() happens automatically once the
                    // server's next "online_start" deal arrives.
                    window.dominoRequestNextRound();
                } else {
                    try { s_oGame.restart(); } catch(e){}
                }
            }, 1200);
        }
    };

    this.checkBoard = function(){ 
        var oClickPanel = new createjs.Shape();
        oClickPanel.graphics.beginFill("rgba(0,0,0,0.4)").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        oClickPanel.on("click", s_oGame.returnToEndPanel, s_oGame, true, oClickPanel);
        s_oStage.addChild(oClickPanel);
        
        _oMatchOverPanel.hide();
    };

    this.returnToEndPanel = function(evt, oClickPanel){ 
        s_oStage.removeChild(oClickPanel);
        _oMatchOverPanel.show();
    };

    this.getScore = function(iPlayer) {
        return _aScore[iPlayer];
    };

    // Lets net_online.js push a freshly-confirmed photo/avatar onto the
    // in-game HUD avatar, covering the case where window.DOMINO_USER's
    // photo_url/avatar wasn't populated yet when this match's HUD was
    // first built.
    this.refreshMyAvatar = function(photoUrl, emoji) {
        try {
            if (_aPlayers && _aPlayers[0] && _aPlayers[0].refreshAvatar) {
                _aPlayers[0].refreshAvatar(photoUrl, emoji);
            }
        } catch(e){}
    };

    // Same, for the opponent's HUD avatar (seat 1). The opponent's photo
    // arrives with the 'matched' payload, but the HUD is only built a
    // moment later inside gotoGame() — and the VS intro sits in between —
    // so the avatar could be constructed before DOMINO_P1_PHOTO was read.
    // net_online.js calls this once the board exists to make sure the
    // opponent's picture actually shows instead of a blank/emoji circle.
    this.refreshOpponentAvatar = function(photoUrl, emoji) {
        try {
            if (_aPlayers && _aPlayers[1] && _aPlayers[1].refreshAvatar) {
                _aPlayers[1].refreshAvatar(photoUrl, emoji);
            }
        } catch(e){}
    };
    
    this.setValueSide1 = function(value) {
        _iSide1Value = value; };

    this.setValueSide2 = function(value) {
        _iSide2Value = value; };

    this.getValueSide1 = function() {
        return _iSide1Value; };
    
    this.getValueSide2 = function() {
        return _iSide2Value; };
    
    this.gameReady = function() {
        return _bGameReady; };
    
    this.setTurnVisibility = function(){
        for (var i = 0; i < _iPlayers; i++) {
            if (i === _iTurn) {
                _aPlayers[i].setTurn(true);
            } else {
                _aPlayers[i].setTurn(false);
            }
        };
    };
    
    this.changeTurn = function() {
        _bDrawnedTile = false;
        _iTurn += 1;

        if (_iTurn >= _iPlayers) {
            _iTurn = 0;
        }

        s_oGame.setTurnVisibility();

        // SET EVERY GLOW INVISIBLE
        if (_iTurn !== 0) {
            var aTiles = _aPlayers[0].getTilesArray();

            for (var i = 0; i < aTiles.length; i++) {
                var oTile = aTiles[i];
                oTile.setGlowVisible(false);
            };
        }
        
        s_oGame._checkGame();
    };

    this.getTurn = function(){ return _iTurn; };
    /**
     * Compare what this phone is showing against the server's authoritative
     * position. Returns null when they agree, or a short reason when they
     * don't.
     *
     * This is the check that was missing. Previously each phone maintained
     * its own copy of the game and simply assumed it was right; when it
     * drifted, nothing noticed until the player tapped a tile and got a
     * "not your turn" or "tile not in hand" rejection deep into the round,
     * by which point the match was already unplayable.
     */
    this.diffAgainstServer = function(state){
        try {
            if (!state) { return null; }
            var boardCount = _aBoardTiles ? _aBoardTiles.length : 0;
            var serverBoard = (state.board || []).length;
            if (boardCount !== serverBoard) {
                return 'board ' + boardCount + ' vs ' + serverBoard;
            }
            var myHand = (_aPlayers && _aPlayers[0]) ? _aPlayers[0].getTilesArray().length : -1;
            var serverHand = (state.yourHand || []).length;
            if (myHand !== serverHand) {
                return 'hand ' + myHand + ' vs ' + serverHand;
            }
            var oppHand = (_aPlayers && _aPlayers[1]) ? _aPlayers[1].getTilesArray().length : -1;
            if (state.oppHandCount != null && oppHand !== state.oppHandCount) {
                return 'oppHand ' + oppHand + ' vs ' + state.oppHandCount;
            }
            if (serverBoard > 0) {
                if (state.leftEnd != null && _iSide1Value !== state.leftEnd) {
                    return 'leftEnd ' + _iSide1Value + ' vs ' + state.leftEnd;
                }
                if (state.rightEnd != null && _iSide2Value !== state.rightEnd) {
                    return 'rightEnd ' + _iSide2Value + ' vs ' + state.rightEnd;
                }
            }
            return null;
        } catch(e){ return 'diff failed: ' + e.message; }
    };

    /**
     * Make this phone's own hand match the server's exactly.
     *
     * The player's hand was never checked against the server before. When
     * it drifted, the player tapped a tile they could see on screen and the
     * server answered "tile_not_in_hand" -- a rejection that made no sense
     * to them, and which the client responded to by reloading. Correcting
     * the hand from the authoritative list instead means the tiles on
     * screen are always tiles they can actually play.
     *
     * aServerValues is the server's list of tile values for this seat.
     */
    this.reconcileHand = function(aServerValues){
        try {
            if (!aServerValues || !_aPlayers || !_aPlayers[0]) { return null; }
            var oPlayer = _aPlayers[0];

            var want = {};
            for (var i = 0; i < aServerValues.length; i++) {
                var v = Number(aServerValues[i]);
                want[v] = (want[v] || 0) + 1;
            }

            var have = {};
            var aTiles = oPlayer.getTilesArray();
            for (var j = 0; j < aTiles.length; j++) {
                var hv = aTiles[j].getValue();
                have[hv] = (have[hv] || 0) + 1;
            }

            var changed = 0;

            // Drop anything the server says we no longer hold. Iterate
            // backwards because removeTile mutates the array.
            for (var k = aTiles.length - 1; k >= 0; k--) {
                var tv = aTiles[k].getValue();
                if ((want[tv] || 0) < (have[tv] || 0)) {
                    have[tv] -= 1;
                    try { aTiles[k].unload(); } catch(e){}
                    oPlayer.removeTile(aTiles[k]);
                    changed++;
                }
            }

            // Add anything the server says we hold that we're not showing.
            for (var sv in want) {
                if (!Object.prototype.hasOwnProperty.call(want, sv)) continue;
                var need = want[sv] - (have[sv] || 0);
                for (var n = 0; n < need; n++) {
                    (function(val){
                        oPlayer.addTile({ getValue: function(){ return val; } });
                    })(Number(sv));
                    var aNow = oPlayer.getTilesArray();
                    var last = aNow.length - 1;
                    oPlayer.setTileVisible(last, true);
                    var oNew = aNow[last];
                    if (oNew && oNew.isTurned && oNew.isTurned() === false) { oNew.turnTile(); }
                    changed++;
                }
            }

            if (changed && oPlayer.setArrangingDone) { oPlayer.setArrangingDone(); }
            return changed ? ('hand corrected: ' + changed + ' tile(s)') : null;
        } catch(e){ return 'reconcileHand failed: ' + e.message; }
    };

    /**
     * Rebuild the whole position from the server's state, in place.
     *
     * Recovery used to be done with location.reload(). On a phone with a
     * weak connection that is the worst possible move: the reload drops the
     * socket, which triggers a fresh reconnect, which can trigger another
     * mismatch -- a loop, on the exact devices least able to survive it.
     *
     * Rebuilding here keeps the socket alive. Nothing is re-negotiated and
     * nothing is replayed against a guess: the board is cleared and laid
     * out again from the server's own move list, the hands are set to the
     * server's, and the turn comes from the server.
     *
     * Returns true if the rebuild ran.
     */
    // True while the deal animation (CBoxAnimation) is still handing tiles
    // out. s_oBox exists only for that window -- it is created when the round
    // is dealt and nulled in its unload -- and the click handlers above
    // already gate on exactly this. Anything that rebuilds hands or the board
    // must wait, because the queued animation callbacks still hold references
    // to the tile objects a rebuild would destroy.
    this.isDealing = function(){
        return (typeof s_oBox !== "undefined" && s_oBox !== null);
    };

    this.rebuildFromState = function(state){
        try {
            if (!state || !state.board) { return false; }
            // Refuse while net_online.js's manual resume replay
            // (waitForCleanDeal/applyNext) is mid-flight. That path also walks
            // the log and mutates the same hands/board one action at a time;
            // running this full wipe-and-rebuild on top of it is the second
            // writer that produced the myHand/oppHand/boardTiles mismatches
            // and the boxTilesDistribution "stale destination" warnings. Let
            // the in-progress replay finish and do its own final count check.
            if (window.YD_RESYNC_IN_PROGRESS) { return false; }
            // Same reasoning for the deal animation: it holds references to
            // the very tiles this would destroy.
            if (this.isDealing && this.isDealing()) { return false; }

            window.s_bApplyingRemote = true;
            _bRebuilding = true;

            // Clear the board.
            if (_aBoardTiles) {
                for (var i = _aBoardTiles.length - 1; i >= 0; i--) {
                    try { _aBoardTiles[i].unload(); } catch(e){}
                }
            }
            _aBoardTiles = new Array();
            _oSide1Tile = null;
            _oSide2Tile = null;
            _iSide1Value = -1;
            _iSide2Value = -1;
            _iDrawnTilesSide1 = 0;
            _iDrawnTilesSide2 = 0;

            // Clear both hands.
            for (var p = 0; p < 2; p++) {
                if (!_aPlayers[p]) continue;
                var aT = _aPlayers[p].getTilesArray();
                for (var j = aT.length - 1; j >= 0; j--) {
                    try { aT[j].unload(); } catch(e2){}
                    _aPlayers[p].removeTile(aT[j]);
                }
            }

            // Put OUR tiles back. The server sends our hand exactly.
            var mine = state.yourHand || [];
            for (var k = 0; k < mine.length; k++) {
                (function(val){
                    _aPlayers[0].addTile({ getValue: function(){ return val; } });
                })(Number(mine[k]));
                var aNow = _aPlayers[0].getTilesArray();
                _aPlayers[0].setTileVisible(aNow.length - 1, true);
                var oNew = aNow[aNow.length - 1];
                if (oNew && oNew.isTurned && oNew.isTurned() === false) { oNew.turnTile(); }
            }
            if (_aPlayers[0].setArrangingDone) { _aPlayers[0].setArrangingDone(); }

            // Lay the board out again from the server's move list. Each
            // entry names the seat, so map it to this screen (0 = me).
            //
            // The opponent's hand is deliberately left EMPTY for this part.
            // Filling it with placeholder tiles first was a mistake: every
            // placeholder had the same value, so a replayed opponent move
            // could never find its real tile, "materialised" a fresh one
            // each time, and left the opponent holding far more tiles than
            // they should -- the flood of "replay tile N missing" reports.
            // Replaying into an empty hand materialises each tile exactly
            // once, which is correct.
            var mySeat = Number(state.seat);
            for (var b = 0; b < state.board.length; b++) {
                var mv = state.board[b];
                if (!mv) continue;
                var rel = (Number(mv.seat) === mySeat) ? 0 : 1;
                this.applyReplayMove(rel, Number(mv.value), mv.side, mv.rotation);
            }

            // Now top the opponent up to the count the server reports. They
            // are face-down, so the values don't matter -- only the count,
            // and it is only correct once the board is done taking tiles
            // out of that hand.
            var oppCount = Number(state.oppHandCount || 0);
            var haveOpp = _aPlayers[1].getTilesArray().length;
            for (var q = haveOpp; q < oppCount; q++) {
                _aPlayers[1].addTile({ getValue: function(){ return 0; } });
                var aOpp = _aPlayers[1].getTilesArray();
                _aPlayers[1].setTileVisible(aOpp.length - 1, true);
            }
            // And trim if we somehow ended up with too many.
            var aOppNow = _aPlayers[1].getTilesArray();
            for (var r = aOppNow.length - 1; r >= oppCount; r--) {
                try { aOppNow[r].unload(); } catch(e4){}
                _aPlayers[1].removeTile(aOppNow[r]);
            }
            if (_aPlayers[1].setArrangingDone) { _aPlayers[1].setArrangingDone(); }

            _iOnlineBoneyardLeft = Math.max(0, Number(state.boneyardCount || 0));

            _bRebuilding = false;
            window.s_bApplyingRemote = false;

            if (state.turnSeat != null && this.applyServerTurn) {
                this.applyServerTurn(Number(state.turnSeat) === mySeat ? 0 : 1);
            }
            return true;
        } catch(e){
            _bRebuilding = false;
            window.s_bApplyingRemote = false;
            try {
                if (window.reportGlitch) window.reportGlitch("rebuildFromState failed: " + e.message);
            } catch(e3){}
            return false;
        }
    };

    this.isAwaitingServerMove = function(){ return awaitingServerMove(); };

    /**
     * The server owns the turn. If it has recently told us the turn is the
     * opponent's, refuse the tap here instead of sending a move that comes
     * back "not_your_turn" and leaves the player staring at a board that
     * will not move.
     *
     * Deliberately fails OPEN: if we have never heard from the server, or
     * its last word is stale, play is allowed. A wrong "no" would make the
     * game unplayable, which is far worse than the rejection it prevents.
     */
    this.serverForbidsPlay = function(){
        try {
            if (!window.s_bOnline || window.s_bApplyingRemote) { return false; }
            if (window.YD_SERVER_TURN_IS_MINE !== false) { return false; }
            var iAge = Date.now() - (window.YD_SERVER_TURN_AT || 0);
            if (iAge > 15000) { return false; }
            return true;
        } catch(e){ return false; }
    };

    this.getBoardTiles = function(){ return _aBoardTiles; };
    this.getScoreOf = function(i){ return (_aScore && _aScore[i] != null) ? _aScore[i] : 0; };

    // ONLINE 10s AUTO-PLAY: if the local player does not move in time,
    // automatically play one legal tile. If no legal tile exists, keep
    // drawing from the server until a legal tile arrives or the boneyard ends.
    this.autoPlayCurrentTurn = function(){
        if (_bMatchOver || _iTurn !== 0 || !_bGameReady) {
            return false;
        }

        var aTiles = _aPlayers[0].getTilesArray();
        if (!aTiles || aTiles.length === 0) {
            return false;
        }

        // First tile: any tile is legal. Prefer the highest-value tile.
        if (_bFirstTile === true) {
            var oBest = aTiles[0];
            var iBest = -1;
            for (var i = 0; i < aTiles.length; i++) {
                var iSum = aTiles[i].getDotsValue(0) + aTiles[i].getDotsValue(1);
                if (iSum > iBest) {
                    iBest = iSum;
                    oBest = aTiles[i];
                }
            }
            this.checkClickedTile(oBest);
            return true;
        }

        var aCorrect = this._cpuPlayable();
        if (!aCorrect || aCorrect.length === 0) {
            window.s_bAutoPlayPending = true;
            this.checkToDrawn();
            return false;
        }

        window.s_bAutoPlayPending = false;

        // Prefer the highest-value legal tile.
        aCorrect.sort(function(a,b){
            var av = a.getDotsValue(0) + a.getDotsValue(1);
            var bv = b.getDotsValue(0) + b.getDotsValue(1);
            return bv - av;
        });

        this.checkClickedTile(aCorrect[0]);

        // If both ends are legal, checkClickedTile normally waits for a side
        // selection. For auto-play, choose the left side immediately.
        if (_bSelectedTile) {
            this._onSelectedSide(LEFT_SIDE);
        }

        return true;
    };

    this.update = function() {
        

        // HUD Stock counter.
        if (_oInfoText) {
            var iBone = window.s_bOnline ? _iOnlineBoneyardLeft : ((_aBoneyard) ? _aBoneyard.length : 0);
            _oInfoText.refreshText(String(iBone));
        }

        // DELAY THE CLOSING ANIMATIONS, AT THE END OF A LOCKED MATCH
        if (_bStartGame && _bMatchOver && !_bMatchLocked) {
            _iMatchTimer += s_iTimeElaps;

            if (_iMatchTimer > MATCHOVER_TIMER) {
                if (_bDomino === true) {
                    return;
                }
                
                _bStartGame = false;
                _iMatchTimer = 0;
                this.lockedMatch();
                return;
            }
        }
    };


    // ===== ONLINE DRAW: server-selected tile =====
    // Shared "drop bounce" entrance for a newly drawn tile. The tile's
    // real hand slot is set by CPlayer.arrangeTiles(), which itself
    // tweens x/y over 150ms — so reading oSprite.y immediately (as this
    // used to) captured a STALE position before that tween had settled,
    // and this function's own tween then raced against it on the same
    // property. That's exactly why the newest tile (the one just drawn)
    // could end up frozen at the wrong spot instead of its hand slot:
    // whichever tween last touched .y that frame "won", and the 400ms
    // safety-net below was restoring the same stale fy, so it couldn't
    // self-correct either. Waiting for arrangeTiles' tween to finish
    // before capturing fy (and using override so nothing else can still
    // be animating .y underneath us) fixes it at the source.
    function playDrawEntrance(oNew){
        var oSprite = null, fsx, fsy;
        try {
            oSprite = oNew && oNew.getTile ? oNew.getTile() : null;
            if (!oSprite) return;
            // Deliberately does NOT touch .y (or .x) at all anymore. That
            // position is owned by CPlayer.arrangeTiles(), which runs its
            // own 150ms tween on this same sprite right before this function
            // is called (via addTile in drawFromBoneyard/applyLocalDraw/
            // applyRemoteDraw). Reading oSprite.y here was racing that tween
            // — whichever one touched .y last that frame won — so a freshly
            // drawn tile could end up frozen at the wrong spot; overriding
            // that tween to force our own fy also cancelled arrangeTiles'
            // separate X tween on the same object, and a version of this fix
            // that just delayed everything left the tile invisible if
            // anything cleared the reference in the meantime. Only animating
            // alpha/scale sidesteps all of that — the tile still gets a nice
            // pop-in, and its position is left entirely to arrangeTiles.
            fsx = oSprite.scaleX || TILE_INIT_SCALE; fsy = oSprite.scaleY || TILE_INIT_SCALE;
            oSprite.alpha = 0;
            oSprite.scaleX = fsx * 0.9;
            oSprite.scaleY = fsy * 0.9;
            createjs.Tween.get(oSprite, {override:false})
                .to({ alpha: 1, scaleX: fsx, scaleY: fsy }, 260, createjs.Ease.backOut);
        } catch(e){}
        // Safety net: whatever happened above, guarantee the tile is fully
        // visible shortly after — a newly drawn tile must never be left
        // permanently invisible if the entrance tween above fails for any
        // reason. Only touches alpha/scale, never position, for the same
        // reason as above.
        if (oSprite) {
            setTimeout(function(){
                try {
                    oSprite.alpha = 1;
                    if (typeof fsx === "number") oSprite.scaleX = fsx;
                    if (typeof fsy === "number") oSprite.scaleY = fsy;
                } catch(e){}
            }, 400);
        }
    }

    this.applyLocalDraw = function(iValue, iBoneyardLeft) {
        if (_bMatchOver) { return; }

        _bWaitingOnlineDraw = false;
        _iOnlineBoneyardLeft = Math.max(0, Number(iBoneyardLeft || 0));

        var oPlayer = _aPlayers[0];
        oPlayer.addTile({ getValue: function(){ return iValue; } });

        var aTiles = oPlayer.getTilesArray();
        var iIdx = aTiles.length - 1;
        oPlayer.setTileVisible(iIdx, true);

        var oNew = aTiles[iIdx];
        if (oNew && oNew.isTurned && oNew.isTurned() === false) {
            oNew.turnTile();
        }
        playDrawEntrance(oNew);

        if (oPlayer.setArrangingDone) { oPlayer.setArrangingDone(); }

        // If the 10-second auto-play already fired, continue automatically
        // after each server draw instead of waiting another 10 seconds.
        if (window.s_bAutoPlayPending) {
            setTimeout(function(){
                try { if (s_oGame && s_oGame.autoPlayCurrentTurn) { s_oGame.autoPlayCurrentTurn(); } } catch(e){}
            }, 120);
        }

        // Re-check. If still no legal tile, checkToDrawn will request another
        // server tile; if the boneyard is empty it will pass.
        _aCorrectTiles = new Array();
        this.setGlowVisibleTrue();

        if (_aCorrectTiles.length === 0) {
            this.checkToDrawn();
        } else {
            if (oPlayer.getLocked && oPlayer.getLocked() === true) {
                oPlayer.setLocked(false);
            }
            _bDrawnedTile = false;
        }
    };

    // Deterministic reconnect replay helpers. These mutate the requested
    // local/remote seat without sending anything back to the network.
    this.applyReplayDraw = function(iPlayer, iValue, iBoneyardLeft) {
        if (_bMatchOver) { return; }
        _iOnlineBoneyardLeft = Math.max(0, Number(iBoneyardLeft || 0));
        var oPlayer = _aPlayers[iPlayer === 0 ? 0 : 1];
        oPlayer.addTile({ getValue: function(){ return iValue; } });
        var aTiles = oPlayer.getTilesArray();
        var idx = aTiles.length - 1;
        oPlayer.setTileVisible(idx, true);
        var oTile = aTiles[idx];
        if (iPlayer === 0 && oTile && oTile.isTurned && oTile.isTurned() === false) { oTile.turnTile(); }
        if (oPlayer.setArrangingDone) { oPlayer.setArrangingDone(); }
    };

    this.applyReplayMove = function(iPlayer, iValue, iSide, iRotation) {
        if (_bMatchOver) { return; }
        var p = iPlayer === 0 ? 0 : 1;
        var aTiles = _aPlayers[p].getTilesArray();
        var oTile = null;
        for (var i = 0; i < aTiles.length; i++) { if (aTiles[i].getValue() === iValue) { oTile = aTiles[i]; break; } }

        if (!oTile) {
            // The server's log says this tile WAS played, so it belongs on
            // the board whatever this phone currently thinks is in the
            // hand. Giving up here (which is what used to happen, silently)
            // left the board short by one tile for every replayed move that
            // couldn't be matched -- the "restore count mismatch local=7
            // server=11" seen in production, after which every later move
            // landed on a board that was already wrong.
            //
            // The server is the authority: materialise the tile, then play
            // it, so the rebuilt board always matches the server exactly.
            var oPlayer = _aPlayers[p];
            oPlayer.addTile({ getValue: function(){ return iValue; } });
            var aAfter = oPlayer.getTilesArray();
            var idx = aAfter.length - 1;
            oPlayer.setTileVisible(idx, true);
            oTile = aAfter[idx];
            if (oTile && oTile.isTurned && oTile.isTurned() === false) { oTile.turnTile(); }
            if (oPlayer.setArrangingDone) { oPlayer.setArrangingDone(); }
            // During a deliberate rebuild the hand starts empty on purpose,
            // so every tile is "missing" and reporting each one just floods
            // the log. Only report when this happens during normal play,
            // where it genuinely indicates drift.
            try {
                if (!_bRebuilding && window.reportGlitch) {
                    window.reportGlitch("replay tile " + iValue + " missing from seat " + p + " hand -- materialised from server log");
                }
            } catch(e){}
        }

        window.s_bApplyingRemote = true;
        _iTurn = p;
        oTile.setDrawn();
        _bDrawnedTile = true;
        this.moveToBoard(oTile, iRotation, iSide);
        window.s_bApplyingRemote = false;
    };

    this.applyReplayPass = function(iPlayer) {
        if (_bMatchOver) { return; }
        var p = iPlayer === 0 ? 0 : 1;
        window.s_bApplyingRemote = true;
        _iTurn = p;
        if (_aPlayers[p].getLocked() === false) { _aPlayers[p].setLocked(true); }
        this.passTurn();
        window.s_bApplyingRemote = false;
    };

    // Force the local turn to match the server's authoritative turnSeat.
    //
    // Everywhere else the client works out whose turn it is by starting from
    // starterSeat and alternating as the round's log is replayed. That is
    // fine while every action arrives, but after a reconnect or a forced
    // resume the replay can be empty, partial or slightly out of order --
    // and then the local turn silently drifts away from the server's. The
    // player is allowed to tap a tile when it isn't actually their turn, the
    // server rejects it with not_your_turn, and the client reloads and tries
    // to resume again, which is what the match freezing/kicking looks like
    // from the outside.
    //
    // iRelTurn is already relative to this client: 0 = me, 1 = opponent.
    this.applyServerTurn = function(iRelTurn) {
        if (_bMatchOver) { return; }
        var p = Number(iRelTurn) === 0 ? 0 : 1;
        if (_iTurn === p) { return; }
        _iTurn = p;
        _bDrawnedTile = false;
        if (p !== 0) {
            // Not our turn: hide any tile glow left over from before.
            var aTiles = _aPlayers[0].getTilesArray();
            for (var i = 0; i < aTiles.length; i++) { aTiles[i].setGlowVisible(false); }
        }
        _oBlockInput.visible = (p !== 0);
        this.setTurnVisibility();
    };

    this.applyRemoteDraw = function(iValue, iBoneyardLeft) {
        if (_bMatchOver) { return; }

        _iOnlineBoneyardLeft = Math.max(0, Number(iBoneyardLeft || 0));

        // Opponent is player 1 on this screen. Keep the real value locally
        // so a later remote move can find the exact tile, but leave it face-down.
        var oPlayer = _aPlayers[1];
        oPlayer.addTile({ getValue: function(){ return iValue; } });

        var aTiles = oPlayer.getTilesArray();
        var iIdx = aTiles.length - 1;
        oPlayer.setTileVisible(iIdx, true);
        playDrawEntrance(aTiles[iIdx]);

        if (oPlayer.setArrangingDone) { oPlayer.setArrangingDone(); }
    };

    this.applyOnlineBoneyardEmpty = function() {
        _bWaitingOnlineDraw = false;
        _iOnlineBoneyardLeft = 0;

        _aCorrectTiles = new Array();
        this.setGlowVisibleTrue();

        if (_aCorrectTiles.length === 0) {
            if (_aPlayers[0].getLocked() === false) {
                _aPlayers[0].setLocked(true);
            }
            this.passTurn();
        }
    };

    // ===== ONLINE: apply a move/pass received from the opponent =====
    this.applyRemoteMove = function(iValue, iSide, iRotation) {
        if (_bMatchOver) { return; }
        // If a tile is still tweening into place, its getX()/getY() would
        // return a mid-flight position, not its final resting spot — placing
        // the next tile off that would misalign/overlap it. Queue instead
        // and drain the queue once the current tween's completion callback
        // fires (see startTileMovement).
        if (_bTileAnimating) {
            _aRemoteMoveQueue.push({ iValue: iValue, iSide: iSide, iRotation: iRotation });
            return;
        }
        this._applyRemoteMoveNow(iValue, iSide, iRotation);
    };

    this._applyRemoteMoveNow = function(iValue, iSide, iRotation) {
        if (_bMatchOver) { return; }
        // opponent is always player 1 on my screen
        var aTiles = _aPlayers[1].getTilesArray();
        var oTile = null;
        for (var i = 0; i < aTiles.length; i++) {
            if (aTiles[i].getValue() === iValue) { oTile = aTiles[i]; break; }
        }
        if (!oTile) {
            // Same reasoning as applyReplayMove: the server has already
            // accepted this move, so the tile goes on the board even if our
            // picture of the opponent's hand has drifted. Silently dropping
            // it left this phone a tile behind for the rest of the match,
            // and the player only found out when their own next move was
            // rejected.
            var oOpp = _aPlayers[1];
            oOpp.addTile({ getValue: function(){ return iValue; } });
            var aAfter = oOpp.getTilesArray();
            var idx = aAfter.length - 1;
            oOpp.setTileVisible(idx, true);
            oTile = aAfter[idx];
            if (oOpp.setArrangingDone) { oOpp.setArrangingDone(); }
            try {
                if (window.reportGlitch) {
                    window.reportGlitch("remote tile " + iValue + " missing from opponent hand -- materialised from server move");
                }
            } catch(e){}
        }
        if (_aPlayers[1].getLocked() === true) { _aPlayers[1].setLocked(false); }
        window.s_bApplyingRemote = true;
        _iTurn = 1;
        oTile.setDrawn();
        _bDrawnedTile = true;
        this.moveToBoard(oTile, iRotation, iSide);
        window.s_bApplyingRemote = false;
    };

    this._drainRemoteMoveQueue = function() {
        if (_aRemoteMoveQueue.length === 0) {
            // Queue just emptied. If we had been buffering (i.e. a burst of
            // moves arrived faster than they could animate — typical after a
            // lag spike or a reconnect), snap the whole board back into exact
            // alignment. Any tile left visually stranded mid-flight gets
            // corrected here instead of staying overlapped until the round
            // ends and the board is rebuilt from scratch.
            if (_bDrainedBurst) {
                _bDrainedBurst = false;
                var self = this;
                setTimeout(function(){
                    try { if (!_bTileAnimating) self.resyncBoardPositions(); } catch(e){}
                }, 60);
            }
            return;
        }
        _bDrainedBurst = true;
        var next = _aRemoteMoveQueue.shift();
        if (next.isPass) {
            window.s_bApplyingRemote = true;
            _iTurn = 1;
            if (_aPlayers[1].getLocked() === false) { _aPlayers[1].setLocked(true); }
            this.passTurn();
            window.s_bApplyingRemote = false;
            this._drainRemoteMoveQueue(); // a pass doesn't animate, so keep draining
        } else {
            this._applyRemoteMoveNow(next.iValue, next.iSide, next.iRotation);
        }
    };

    this.applyRemotePass = function() {
        if (_bMatchOver) { return; }
        if (_bTileAnimating) {
            _aRemoteMoveQueue.push({ isPass: true });
            return;
        }
        window.s_bApplyingRemote = true;
        _iTurn = 1;
        if (_aPlayers[1].getLocked() === false) { _aPlayers[1].setLocked(true); }
        this.passTurn();
        window.s_bApplyingRemote = false;
    };

    s_oGame = this;

    this._init();
}

var s_oGame;