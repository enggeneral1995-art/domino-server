function CInterface() {
    var _oContainer, _oBalanceText;

    function roundedCard(x,y,w,h,r){
        var sh = new createjs.Shape();
        sh.graphics.setStrokeStyle(2).beginStroke("#5e4424").beginFill("rgba(16,16,14,0.96)")
          .drawRoundRect(x,y,w,h,r);
        sh.shadow = new createjs.Shadow("rgba(0,0,0,.55)",0,4,10);
        _oContainer.addChild(sh);
        return sh;
    }
    function circleButton(cx,cy,r,glyph,fontSize,onClick){
        var sh=new createjs.Shape();
        sh.graphics.setStrokeStyle(3).beginStroke("#d8ac51").beginFill("#141513").drawCircle(cx,cy,r);
        sh.shadow=new createjs.Shadow("rgba(0,0,0,.55)",0,4,10); _oContainer.addChild(sh);
        var t=new createjs.Text(glyph,"bold "+fontSize+"px Arial","#f2bd46");
        t.textAlign="center"; t.textBaseline="middle"; t.x=cx; t.y=cy+1; _oContainer.addChild(t);
        if(onClick){
            var hit=new createjs.Shape(); hit.graphics.beginFill("#fff").drawCircle(cx,cy,r); hit.alpha=.01; hit.cursor="pointer";
            hit.on("mousedown",onClick); _oContainer.addChild(hit);
        }
    }

    this._init = function(){
        _oContainer = new createjs.Container(); s_oStage.addChild(_oContainer);

        // Top-left menu button
        roundedCard(18,24,58,58,14);
        var menu=new createjs.Text("☰","bold 32px Arial","#efbd57"); menu.textAlign="center"; menu.textBaseline="middle"; menu.x=47; menu.y=53; _oContainer.addChild(menu);
        var menuHit=new createjs.Shape(); menuHit.graphics.beginFill("#fff").drawRoundRect(18,24,58,58,14); menuHit.alpha=.01; menuHit.cursor="pointer";
        menuHit.on("mousedown",function(){ if(typeof CAreYouSurePanel!=="undefined") new CAreYouSurePanel(); else if(s_oGame&&s_oGame.onExit) s_oGame.onExit(); }); _oContainer.addChild(menuHit);

        // Trophy / goal removed on request — the "یاری هەتا" panel on the
        // table already shows the same goal number.

        // Balance / plus
        roundedCard(517,24,232,58,27);
        var coin=new createjs.Shape(); coin.graphics.setStrokeStyle(2).beginStroke("#9b6e18").beginFill("#efbd45").drawCircle(544,53,13); _oContainer.addChild(coin);
        var cd=new createjs.Text("$","bold 15px Arial","#6e4b0c"); cd.textAlign="center"; cd.textBaseline="middle"; cd.x=544; cd.y=53; _oContainer.addChild(cd);
        _oBalanceText=new createjs.Text("0","bold 22px Arial","#ffffff"); _oBalanceText.textAlign="right"; _oBalanceText.textBaseline="middle"; _oBalanceText.x=702; _oBalanceText.y=53; _oContainer.addChild(_oBalanceText);
        var plus=new createjs.Shape(); plus.graphics.beginFill("#279a2f").drawCircle(724,53,18); _oContainer.addChild(plus);
        var pt=new createjs.Text("+","bold 26px Arial","#fff"); pt.textAlign="center"; pt.textBaseline="middle"; pt.x=724; pt.y=52; _oContainer.addChild(pt);

        // Bottom sound / settings buttons and the turn banner removed on
        // request — the turn is already signalled by the countdown ring
        // around the active player's avatar.

        createjs.Ticker.addEventListener("tick", this._refreshHud.bind(this));
    };

    this._refreshHud=function(){
        try{
            var bal=(window.DOMINO_USER&&window.DOMINO_USER.balance!=null)?Number(window.DOMINO_USER.balance):0;
            if(_oBalanceText) _oBalanceText.text=bal.toLocaleString(undefined,{maximumFractionDigits:2});
        }catch(e){}
    };
    this.refreshButtonPos=function(){};
    this.unload=function(){ if(_oContainer){ _oContainer.removeAllEventListeners(); s_oStage.removeChild(_oContainer); _oContainer=null; } };
    this._init();
}
var s_oInterface = null;
