// Language strings for the canvas game UI. Sourced from window.t() (see
// i18n.js, which must load before this file) so the game HUD follows the
// player's selected language (Kurdish / English / Arabic).
var _t = (typeof window !== "undefined" && window.t) ? window.t : function(k, fallback){ return fallback; };

var TEXT_HELP_TITLE         = _t("TEXT_HELP_TITLE", "HOW TO PLAY");
var TEXT_HELP1              = _t("TEXT_HELP1", "MATCH TILES WITH THE SAME NUMBER OF DOTS");
var TEXT_HELP2              = _t("TEXT_HELP2", "PLAY ALL YOUR TILES BEFORE THE OTHERS, WITH THE LEAST POSSIBLE MOVES");
var TEXT_HELP3              = _t("TEXT_HELP3", "THE FIRST PLAYER THAT REACHES ");
var TEXT_HELP4              = _t("TEXT_HELP4", " POINTS WINS THE GAME");

var TEXT_SELECT             = _t("TEXT_SELECT", "SELECT PLAYERS");
var TEXT_GOAL               = _t("TEXT_GOAL", "SELECT YOUR GOAL");
var TEXT_PLAYER             = _t("TEXT_PLAYER", "PLAYER");
var TEXT_WINS               = _t("TEXT_WINS", "WINS");

var TEXT_DOMINO             = _t("TEXT_DOMINO", "DOMINO!");
var TEXT_LOCKED             = _t("TEXT_LOCKED", "LOCKED!");
var TEXT_SELECTSIDE         = _t("TEXT_SELECTSIDE", "SELECT SIDE TO ATTACH");
var TEXT_PTS                = _t("TEXT_PTS", "PTS");
var TEXT_BESTSCORE          = _t("TEXT_BESTSCORE", "YOUR BEST SCORE");
var TEXT_MATCHSCORE         = _t("TEXT_MATCHSCORE", "MATCH SCORE");
var TEXT_GAMESUMMARY        = _t("TEXT_GAMESUMMARY", "GAME SUMMARY");
var TEXT_GAMEWON            = _t("TEXT_GAMEWON", "CONGRATULATIONS! YOU WON!");
var TEXT_MATCHOVER          = _t("TEXT_MATCHOVER", "MATCH OVER!");
var TEXT_GAMEOVER           = _t("TEXT_GAMEOVER", "GAME OVER!");
var TEXT_ARE_SURE           = _t("TEXT_ARE_SURE", "ARE YOU SURE YOU WANT TO EXIT? ALL UNSAVED PROGRESS WILL BE LOST");

var TEXT_RESTART            = _t("TEXT_RESTART", "A PREVIOUS MATCH WAS FOUND IN MEMORY. DO YOU WANT TO RESTART OVER THE GAME OR CONTINUE?");
var TEXT_SCORE              = _t("TEXT_SCORE", "LAST SAVED SCORE");

var TEXT_PRELOADER_CONTINUE = _t("TEXT_PRELOADER_CONTINUE", "START");
var TEXT_CREDITS_DEVELOPED  = _t("TEXT_CREDITS_DEVELOPED", "DEVELOPED BY");
var TEXT_ERR_LS             = _t("TEXT_ERR_LS", "YOUR WEB BROWSER DOES NOT SUPPORT STORING SETTING LOCALLY. IN SAFARI, THE MOST COMMON CAUSE OF THIS IS USING 'PRIVATE BROWSING MODE'. SOME INFO MAY NOT SAVE OR SOME FEATURE MAY NOT WORK PROPERLY.");

var TEXT_SHARE_IMAGE = "200x200.jpg";
var TEXT_SHARE_TITLE = _t("TEXT_SHARE_TITLE", "Congratulations!");
var TEXT_SHARE_MSG1 = _t("TEXT_SHARE_MSG1", "You collected <strong>");
var TEXT_SHARE_MSG2 = _t("TEXT_SHARE_MSG2", " points</strong>!<br><br>Share your score with your friends!");
var TEXT_SHARE_SHARE1 = _t("TEXT_SHARE_SHARE1", "My score is ");
var TEXT_SHARE_SHARE2 = _t("TEXT_SHARE_SHARE2", " points! Can you do better");

// HUD labels (previously hardcoded directly in CGame.js)
var TEXT_HUD_DRAWGAMETO = _t("TEXT_HUD_DRAWGAMETO", "Draw Game to");
var TEXT_HUD_STOCK      = _t("TEXT_HUD_STOCK", "Stock");
var TEXT_HUD_ROUND      = _t("TEXT_HUD_ROUND", "Round");
var TEXT_HUD_SCORE      = _t("TEXT_HUD_SCORE", "Score");
