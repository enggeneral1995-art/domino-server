
function CPlayer(iPlayerN, iScore) {
    var _iPlayerN = iPlayerN;
    var _iScore = Number(iScore || 0);
    var _aPlayersTiles = [];
    var _oPlayer;
    var _oHud;
    var _oPanel;
    var _oNameText;
    var _oScoreText;
    var _bLocked = false;
    var _bArrangingTiles = false;
    var _oTurnRing = null;
    var _fTurnRingTick = null;

    function panel(container, x, y, w, h, stroke) {
        // Dark card with a thin gold edge — matches the reference design.
        var s = new createjs.Shape();
        s.graphics.setStrokeStyle(2)
          .beginStroke("#c9a24a")
          .beginFill("#131313")
          .drawRoundRect(x,y,w,h,24);
        s.shadow = new createjs.Shadow("rgba(0,0,0,.55)", 0, 5, 12);
        container.addChild(s);
        return s;
    }

    var _oAvatarContainer;
    var _iAvatarCx, _iAvatarCy, _sAvatarRing;

    function avatar(container, cx, cy, ring, photoUrl, emoji) {
        // Gold-ringed circular avatar, matching the reference design.
        var outer = new createjs.Shape();
        outer.graphics.setStrokeStyle(5).beginStroke("#d9b25e")
          .beginFill("#1b1b1b").drawCircle(cx,cy,50);
        outer.shadow = new createjs.Shadow("rgba(0,0,0,.5)",0,3,8);
        container.addChild(outer);

        if (photoUrl) {
            var img = new Image();
            img.onload = function(){
                try {
                    var bmp = new createjs.Bitmap(img);
                    var size = 90;
                    var scale = size / Math.min(img.width, img.height);
                    bmp.scaleX = bmp.scaleY = scale;
                    bmp.x = cx - (img.width*scale)/2;
                    bmp.y = cy - (img.height*scale)/2;
                    var mask = new createjs.Shape();
                    mask.graphics.beginFill("#000").drawCircle(cx, cy, 47);
                    bmp.mask = mask;
                    container.addChild(bmp);
                    if (typeof s_oStage !== "undefined" && s_oStage) s_oStage.update();
                } catch(e){}
            };
            img.src = photoUrl;
            return;
        }

        // No real photo — show the player's chosen emoji avatar if they
        // have one, matching the emoji picker in the profile/menu screens.
        // Falls back to a generic silhouette only when there's no emoji
        // either (e.g. still loading, or a brand-new guest profile).
        if (emoji) {
            var glyph = new createjs.Text(emoji, "44px Arial", "#ffffff");
            glyph.textAlign = "center";
            glyph.textBaseline = "middle";
            glyph.x = cx;
            glyph.y = cy + 2;
            container.addChild(glyph);
            return;
        }

        var head = new createjs.Shape();
        head.graphics.beginFill("#8f95aa").drawCircle(cx,cy-14,18);
        container.addChild(head);

        var body = new createjs.Shape();
        body.graphics.beginFill("#7c8297").drawRoundRect(cx-29,cy+6,58,34,17);
        container.addChild(body);
    }

    // Redraws the local player's avatar with a (possibly newly available)
    // photo, without needing to reconstruct the whole HUD. Used as a safety
    // net right when a match starts, in case window.DOMINO_USER.photo_url
    // wasn't populated yet at the moment this panel was first built.
    this.refreshAvatar = function(photoUrl, emoji) {
        if (!_oAvatarContainer) return;
        _oAvatarContainer.removeAllChildren();
        avatar(_oAvatarContainer, _iAvatarCx, _iAvatarCy, _sAvatarRing, photoUrl, emoji);
    };

    function iconChip(container, cx, cy, glyph){
        var s = new createjs.Shape();
        s.graphics.beginFill("rgba(255,255,255,0.08)").drawRoundRect(cx-14,cy-14,28,28,9);
        container.addChild(s);
        var t = new createjs.Text(glyph, "13px Arial", "#c9a24a");
        t.textAlign = "center"; t.textBaseline = "middle";
        t.x = cx; t.y = cy+1;
        container.addChild(t);
    }

    this._init = function() {
        _oPlayer = new createjs.Container();
        s_oStage.addChild(_oPlayer);

        _oHud = new createjs.Container();
        s_oStage.addChild(_oHud);

        var me = (_iPlayerN === 0);

        // Reference layout: opponent top center, me bottom-left.
        var x = me ? 38 : 174;
        var y = me ? 1145 : 126;
        var w = me ? 470 : 438;
        var h = 118;

        _oPanel = panel(_oHud, x, y, w, h, me ? "#1c7f6b" : "#1d846f");
        var initialPhoto = me
          ? (window.DOMINO_USER && window.DOMINO_USER.photo_url)
          : window.DOMINO_P1_PHOTO;
        var initialEmoji = me
          ? (window.DOMINO_USER && window.DOMINO_USER.avatar)
          : window.DOMINO_P1_AVATAR;
        _iAvatarCx = x+62;
        _iAvatarCy = y+59;
        _sAvatarRing = me ? "#f4bd5e" : "#ffc96e";
        // Dedicated sub-container just for the avatar graphic, so refreshing
        // it later (new photo arrives, turn ring updates) never touches the
        // panel, name, or score text that also live in _oHud.
        _oAvatarContainer = new createjs.Container();
        _oHud.addChild(_oAvatarContainer);
        avatar(_oAvatarContainer, _iAvatarCx, _iAvatarCy, _sAvatarRing, initialPhoto, initialEmoji);

        _oNameText = new createjs.Text(me ? "You" : "Opponent", "bold 30px Arial", "#ffffff");
        _oNameText.x = x+126;
        _oNameText.y = y+25;
        _oNameText.maxWidth = me ? 230 : 250;
        _oHud.addChild(_oNameText);

        // Reference design has no chip row inside the player card — the
        // score sits under the name instead, and chat/emoji live in the
        // floating round buttons on the right edge of the screen.
        if (!me) {
            iconChip(_oHud, x+w-38, y+28, "≡");
        }

        // Turn countdown ring is started/stopped from setTurn() below, so
        // it only ever shows on whichever avatar currently has the turn.

        // Score — small gold coin dot with the number beside it, sitting
        // directly under the name (reference layout), not a separate box.
        var coinCx = x+132;
        var coinCy = y+76;
        var coin = new createjs.Shape();
        coin.graphics.setStrokeStyle(2).beginStroke("#8a6a1e")
          .beginFill("#e8b93f").drawCircle(coinCx, coinCy, 12);
        _oHud.addChild(coin);

        _oScoreText = new createjs.Text(String(_iScore), "bold 27px Arial", "#ffffff");
        _oScoreText.textAlign = "left";
        _oScoreText.textBaseline = "middle";
        _oScoreText.x = coinCx + 22;
        _oScoreText.y = coinCy + 1;
        _oHud.addChild(_oScoreText);
    };

    this.setName = function(szName) {
        var s = String(szName || (_iPlayerN===0 ? "You" : "Opponent")).trim();
        if (!s) s = (_iPlayerN===0 ? "You" : "Opponent");
        if (s.length > 13) s = s.slice(0,12) + "…";
        _oNameText.text = s;
    };

    this.updateScoreText = function(value) {
        _iScore = Number(value || 0);
        if (_oScoreText) _oScoreText.text = String(_iScore);
    };

    this.setTurn = function(value) {
        if (_oPanel) _oPanel.alpha = value ? 1 : 0.82;
        if (value) {
            this.startTurnRing(_iAvatarCx, _iAvatarCy, 10);
        } else {
            this.stopTurnRing();
        }
    };

    // Circular turn-countdown ring drawn directly on the profile photo
    // (cx, cy = avatar center). Design-only demo loop: sweeps clockwise
    // from a full green ring down to empty over durationSec, turning red
    // for the last quarter, then repeats. Wire a real "seconds left" value
    // in here later by replacing the elapsed/remain calculation below.
    this.startTurnRing = function(cx, cy, durationSec) {
        this.stopTurnRing();
        var shape = new createjs.Shape();
        _oHud.addChild(shape);
        _oTurnRing = shape;

        var radius = 55;
        var trackColor = "rgba(255,255,255,0.12)";
        var progressColor = "#5fe07a";
        var dangerColor = "#ef5a5a";
        var startTime = Date.now();

        _fTurnRingTick = function() {
            var elapsed = (Date.now() - startTime) / 1000;
            var remain = Math.max(0, 1 - (elapsed % durationSec) / durationSec);
            var col = remain < 0.25 ? dangerColor : progressColor;

            shape.graphics.clear();
            shape.graphics.setStrokeStyle(5).beginStroke(trackColor)
              .drawCircle(cx, cy, radius);
            if (remain > 0.002) {
                var start = -Math.PI / 2;
                var end = start + remain * Math.PI * 2;
                shape.graphics.setStrokeStyle(5, "round").beginStroke(col)
                  .arc(cx, cy, radius, start, end, false);
            }
        };
        createjs.Ticker.addEventListener("tick", _fTurnRingTick);
        _fTurnRingTick();
    };

    this.stopTurnRing = function() {
        if (_fTurnRingTick) {
            createjs.Ticker.removeEventListener("tick", _fTurnRingTick);
            _fTurnRingTick = null;
        }
        if (_oTurnRing && _oTurnRing.parent) {
            _oTurnRing.parent.removeChild(_oTurnRing);
        }
        _oTurnRing = null;
    };

    this._initLock = function(){};
    this.getX = function(){ return _oPlayer.x; };
    this.getY = function(){ return _oPlayer.y; };
    this.getContainer = function(){ return _oPlayer; };
    this.getTilesArray = function(){ return _aPlayersTiles; };
    this.setLocked = function(v){ _bLocked = v; };
    this.getLocked = function(){ return _bLocked; };
    this.isArrangementActive = function(){ return _bArrangingTiles; };
    this.setArrangingDone = function(){ _bArrangingTiles = false; };

    this.setTileVisible = function(i, value) {
        if (_aPlayersTiles[i]) {
            _aPlayersTiles[i].setVisible(value);
            _aPlayersTiles[i].addHitArea();
        }
    };

    this.removeTile = function(oTile) {
        var idx = _aPlayersTiles.indexOf(oTile);
        if (idx > -1) _aPlayersTiles.splice(idx,1);
        this.arrangeTiles();
    };

    this.addTile = function(oOldTile) {
        var oNew = new CTile(_oPlayer, oOldTile.getValue(), _iPlayerN, 0, 0);
        _aPlayersTiles.push(oNew);
        oNew.addHitArea();
        _bArrangingTiles = true;
        this.arrangeTiles();
    };

    this.arrangeContainer = function(){ _bArrangingTiles = false; };

    this.arrangeTiles = function() {
        _bArrangingTiles = true;
        var n = _aPlayersTiles.length;

        // Keep every hand fully inside screen and centered.
        var maxSpan = (_iPlayerN === 0) ? 560 : 470;
        var spacing = (n > 1) ? Math.min(76, maxSpan/(n-1)) : 0;
        var startX = CANVAS_WIDTH_HALF - (spacing*(n-1))/2;
        var y = (_iPlayerN === 0) ? 1338 : 318;

        for (var i=0; i<n; i++) {
            _aPlayersTiles[i].setX(startX + i*spacing);
            _aPlayersTiles[i].setY(y);
        }

        setTimeout(function(){ _bArrangingTiles = false; }, 100);
    };

    this._init();
    s_oPlayer = this;
}
var s_oPlayer;
