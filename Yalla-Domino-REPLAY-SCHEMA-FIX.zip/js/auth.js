/* auth.js — premium login / register gate for Yalla Domino.
 * Visual refresh only: existing API/session logic is preserved.
 */
(function () {
  var SERVER = "https://domino-server-production-dcd7.up.railway.app";

  window.DOMINO_TOKEN = null;
  window.DOMINO_USER = null;

  function el(t, css, txt){
    var e=document.createElement(t);
    if(css)e.style.cssText=css;
    if(txt!=null)e.textContent=txt;
    return e;
  }

  var ov = el("div",
    "position:fixed;inset:0;z-index:100000;display:flex;align-items:center;justify-content:center;"+
    "box-sizing:border-box;padding:22px 20px;overflow:auto;"+
    "background:"+
      "radial-gradient(circle at 50% 19%,rgba(235,171,46,.16) 0,rgba(235,171,46,.05) 20%,transparent 42%),"+
      "radial-gradient(circle at 50% 100%,rgba(103,52,15,.22),transparent 48%),"+
      "linear-gradient(180deg,#091538 0%,#091538 58%,#081230 100%);"+
    "font-family:Arial,Helvetica,sans-serif;color:#f9e2ae;-webkit-tap-highlight-color:transparent"
  );

  var shell = el("div",
    "width:min(92vw,390px);margin:auto;position:relative;padding-top:54px"
  );

  var glow = el("div",
    "position:absolute;left:50%;top:8px;transform:translateX(-50%);width:152px;height:72px;"+
    "border-radius:50%;background:rgba(244,181,52,.18);filter:blur(28px);pointer-events:none"
  );

  var logoWrap = el("div",
    "position:absolute;left:50%;top:0;transform:translateX(-50%);z-index:3;width:106px;height:106px;"+
    "box-sizing:border-box;padding:5px;border-radius:50%;"+
    "background:linear-gradient(145deg,#ffe4a6,#e6ae2a 45%,#0f2570);"+
    "box-shadow:0 0 0 5px #091538,0 0 0 7px rgba(225,169,48,.7),0 0 34px rgba(238,177,47,.35)"
  );
  var logo = document.createElement("img");
  logo.src = "icon-192.png?v=fix-20260911l";
  logo.alt = "Yalla Domino";
  logo.style.cssText = "width:100%;height:100%;display:block;object-fit:cover;border-radius:50%;background:#091334";
  logoWrap.appendChild(logo);

  var card = el("div",
    "box-sizing:border-box;width:100%;padding:70px 24px 26px;border-radius:30px;"+
    "background:linear-gradient(180deg,rgba(23,20,13,.97),rgba(8,8,6,.99));"+
    "border:2px solid #dba321;"+
    "box-shadow:inset 0 0 0 1px rgba(255,221,126,.12),0 22px 55px rgba(0,0,0,.58),0 0 26px rgba(196,126,18,.08)"
  );

  var h = el("div",
    "font-family:Georgia,'Times New Roman',serif;font-size:34px;line-height:1.05;font-weight:700;"+
    "color:#ffdc8a;text-align:center;letter-spacing:.02em;text-shadow:0 2px 12px rgba(222,150,22,.22);margin-bottom:8px",
    "Yalla Domino"
  );
  var sub = el("div",
    "font-size:14px;line-height:1.4;color:#bcb7aa;text-align:center;margin-bottom:24px",
    "Sign in and start playing"
  );

  var tabs = el("div",
    "display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:5px;border:1px solid rgba(214,155,43,.55);"+
    "border-radius:16px;background:#081230;margin-bottom:20px"
  );
  var tabLogin = document.createElement("button");
  var tabReg = document.createElement("button");
  tabLogin.type = tabReg.type = "button";
  tabLogin.textContent = "Login";
  tabReg.textContent = "Register";
  tabs.appendChild(tabLogin);
  tabs.appendChild(tabReg);

  function tabStyle(on){
    return "appearance:none;border:0;min-height:46px;border-radius:11px;font-size:16px;font-weight:800;cursor:pointer;"+
      "font-family:Arial,Helvetica,sans-serif;transition:.15s ease;"+
      (on
        ? "background:linear-gradient(180deg,#ffda83 0%,#f4b72a 58%,#bb8507 100%);color:#0e225a;box-shadow:inset 0 1px rgba(255,255,255,.65),0 5px 14px rgba(205,135,18,.22)"
        : "background:transparent;color:#d6c7a4");
  }

  function field(ph, type, icon){
    var wrap = el("div",
      "position:relative;margin-bottom:13px"
    );
    var ic = el("span",
      "position:absolute;left:16px;top:50%;transform:translateY(-50%);font-size:18px;opacity:.78;pointer-events:none",
      icon
    );
    var i = el("input");
    i.type = type;
    i.placeholder = ph;
    i.autocomplete = type === "password" ? "current-password" : (type === "email" ? "email" : "tel");
    i.autocapitalize="off";
    i.spellcheck=false;
    i.style.cssText =
      "width:100%;height:58px;box-sizing:border-box;padding:0 16px 0 48px;border-radius:15px;"+
      "border:1.5px solid #9e781e;background:#080807;color:#fff5df;font-size:16px;font-family:Arial,Helvetica,sans-serif;"+
      "outline:none;box-shadow:inset 0 0 0 1px rgba(255,218,115,.02);caret-color:#f6be3b";
    i.addEventListener("focus",function(){
      i.style.borderColor="#f3be41";
      i.style.boxShadow="0 0 0 3px rgba(236,178,57,.11)";
    });
    i.addEventListener("blur",function(){
      i.style.borderColor="#9e781e";
      i.style.boxShadow="inset 0 0 0 1px rgba(255,218,115,.02)";
    });
    wrap.appendChild(ic);
    wrap.appendChild(i);
    return {wrap:wrap,input:i};
  }

  var emailField = field("Email address", "email", "✉️");
  var phoneField = field("Phone (optional)", "tel", "📱");
  var passField  = field("Password", "password", "🔒");
  var codeField  = field("6-digit code", "text", "🔢");
  var newPassField = field("New password", "password", "🔒");
  var inEmail=emailField.input, inPhone=phoneField.input, inPass=passField.input;
  var inCode=codeField.input, inNewPass=newPassField.input;
  codeField.wrap.style.display = "none";
  newPassField.wrap.style.display = "none";
  codeField.input.autocomplete = "one-time-code";
  newPassField.input.autocomplete = "new-password";

  var submit = el("button",
    "appearance:none;width:100%;min-height:58px;margin-top:7px;border:1.5px solid #ffdc8a;border-radius:16px;"+
    "font-family:Arial,Helvetica,sans-serif;font-weight:900;font-size:18px;letter-spacing:.01em;color:#0f2561;cursor:pointer;"+
    "background:linear-gradient(180deg,#ffdc89 0%,#f7ba2c 58%,#ce9206 100%);"+
    "box-shadow:inset 0 1px rgba(255,255,255,.75),0 8px 20px rgba(211,139,17,.22)",
    "Login"
  );
  submit.addEventListener("touchstart",function(){ submit.style.transform="scale(.985)"; },{passive:true});
  submit.addEventListener("touchend",function(){ submit.style.transform=""; },{passive:true});

  var msg = el("div",
    "font-size:13px;line-height:1.35;color:#ffd573;text-align:center;margin-top:13px;min-height:18px",
    ""
  );

  var foot = el("div",
    "display:flex;align-items:center;justify-content:center;gap:8px;color:#716c61;font-size:12px;margin-top:18px",
    ""
  );
  var dot = el("span","width:7px;height:7px;border-radius:50%;background:#cba449;box-shadow:0 0 8px rgba(76,200,101,.4)");
  var footText = el("span","","Secure connection");
  foot.appendChild(dot); foot.appendChild(footText);

  var forgotLink = el("div",
    "text-align:center;margin-top:14px;font-size:13px;color:#d6c7a4;cursor:pointer;text-decoration:underline",
    "Forgot password?"
  );

  var backToLoginLink = el("div",
    "text-align:center;margin-top:14px;font-size:13px;color:#d6c7a4;cursor:pointer;text-decoration:underline",
    "← Back to login"
  );
  backToLoginLink.style.display = "none";

  card.appendChild(h);
  card.appendChild(sub);
  card.appendChild(tabs);
  card.appendChild(emailField.wrap);
  card.appendChild(phoneField.wrap);
  card.appendChild(passField.wrap);
  card.appendChild(codeField.wrap);
  card.appendChild(newPassField.wrap);
  card.appendChild(submit);
  card.appendChild(forgotLink);
  card.appendChild(backToLoginLink);
  card.appendChild(msg);
  card.appendChild(foot);

  shell.appendChild(glow);
  shell.appendChild(logoWrap);
  shell.appendChild(card);
  ov.appendChild(shell);

  var mode = "login";
  var forgotStep = 0; // 0 = not in forgot flow, 1 = enter email, 2 = enter code + new password
  function setMode(m){
    mode = m;
    forgotStep = 0;
    var isLogin = m === "login";
    tabs.style.display = "grid";
    tabLogin.style.cssText = tabStyle(isLogin);
    tabReg.style.cssText = tabStyle(!isLogin);
    phoneField.wrap.style.display = isLogin ? "none" : "block";
    passField.wrap.style.display = "block";
    codeField.wrap.style.display = "none";
    newPassField.wrap.style.display = "none";
    submit.textContent = isLogin ? "Login" : "Create account";
    submit.style.display = "block";
    sub.textContent = isLogin ? "Sign in and start playing" : "Create your player account";
    inPass.autocomplete = isLogin ? "current-password" : "new-password";
    forgotLink.style.display = isLogin ? "block" : "none";
    backToLoginLink.style.display = "none";
    msg.textContent = "";
  }
  tabLogin.onclick = function(){ setMode("login"); };
  tabReg.onclick = function(){ setMode("register"); };

  function enterForgotStep1(){
    forgotStep = 1;
    tabs.style.display = "none";
    sub.textContent = "Enter your email and we'll send you a reset code";
    phoneField.wrap.style.display = "none";
    passField.wrap.style.display = "none";
    codeField.wrap.style.display = "none";
    newPassField.wrap.style.display = "none";
    submit.textContent = "Send reset code";
    submit.style.display = "block";
    forgotLink.style.display = "none";
    backToLoginLink.style.display = "block";
    msg.textContent = "";
  }

  function enterForgotStep2(){
    forgotStep = 2;
    sub.textContent = "Enter the code we emailed you and a new password";
    codeField.wrap.style.display = "block";
    newPassField.wrap.style.display = "block";
    submit.textContent = "Reset password";
    msg.textContent = "";
  }

  forgotLink.onclick = function(){ enterForgotStep1(); };
  backToLoginLink.onclick = function(){ setMode("login"); };

  function show(){ ov.style.display = "flex"; }
  function hide(){ ov.style.display = "none"; }

  function saveSession(token, user){
    window.DOMINO_TOKEN = token; window.DOMINO_USER = user;
    try { localStorage.setItem("domino_token", token); } catch(e){}
    hide();
    if (typeof window.dominoOnUserReady === "function") window.dominoOnUserReady(user);
  }

  window.dominoLogout = function(){
    try { localStorage.removeItem("domino_token"); } catch(e){}
    window.DOMINO_TOKEN=null; window.DOMINO_USER=null;
    location.reload();
  };

  submit.onclick = function(){
    if (forgotStep === 1) {
      var fEmail = (inEmail.value||"").trim();
      if(!fEmail){ msg.textContent="Enter your email"; return; }
      submit.disabled = true; submit.style.opacity = ".72";
      msg.textContent = "Sending code…";
      fetch(SERVER + "/api/auth/forgot-password", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({email:fEmail}) })
        .then(function(r){ return r.json().then(function(d){ return {ok:r.ok, d:d}; }); })
        .then(function(res){
          submit.disabled = false; submit.style.opacity = "1";
          if(!res.ok){ msg.textContent = friendly(res.d && res.d.error); return; }
          msg.textContent = "If that email is registered, a code is on its way.";
          enterForgotStep2();
        })
        .catch(function(){ submit.disabled=false; submit.style.opacity="1"; msg.textContent = "Network error"; });
      return;
    }

    if (forgotStep === 2) {
      var rEmail = (inEmail.value||"").trim();
      var rCode = (inCode.value||"").trim();
      var rNewPass = inNewPass.value||"";
      if(!rCode || !rNewPass){ msg.textContent="Enter the code and a new password"; return; }
      submit.disabled = true; submit.style.opacity = ".72";
      msg.textContent = "Resetting password…";
      fetch(SERVER + "/api/auth/reset-password", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({email:rEmail,code:rCode,newPassword:rNewPass}) })
        .then(function(r){ return r.json().then(function(d){ return {ok:r.ok, d:d}; }); })
        .then(function(res){
          submit.disabled = false; submit.style.opacity = "1";
          if(!res.ok){ msg.textContent = friendly(res.d && res.d.error); return; }
          setMode("login");
          msg.textContent = "Password reset — please sign in.";
        })
        .catch(function(){ submit.disabled=false; submit.style.opacity="1"; msg.textContent = "Network error"; });
      return;
    }

    var email = (inEmail.value||"").trim();
    var pass = inPass.value||"";
    var phone = (inPhone.value||"").trim();
    if(!email || !pass){ msg.textContent="Enter email and password"; return; }
    submit.disabled = true;
    submit.style.opacity = ".72";
    msg.textContent = "Please wait…";
    var url = SERVER + (mode==="login" ? "/api/login" : "/api/register");
    var body = mode==="login" ? {email:email,password:pass} : {email:email,phone:phone,password:pass};
    fetch(url, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body) })
      .then(function(r){ return r.json().then(function(d){ return {ok:r.ok, d:d}; }); })
      .then(function(res){
        submit.disabled = false; submit.style.opacity = "1";
        if(!res.ok){ msg.textContent = friendly(res.d && res.d.error); return; }
        saveSession(res.d.token, res.d.user);
      })
      .catch(function(){ submit.disabled=false; submit.style.opacity="1"; msg.textContent = "Network error"; });
  };

  inPass.addEventListener("keydown",function(e){ if(e.key === "Enter") submit.click(); });
  inCode.addEventListener("keydown",function(e){ if(e.key === "Enter") submit.click(); });
  inNewPass.addEventListener("keydown",function(e){ if(e.key === "Enter") submit.click(); });
  inEmail.addEventListener("keydown",function(e){ if(e.key === "Enter" && forgotStep===1) submit.click(); });

  function friendly(code){
    var m = {
      email_already_used:"That email is already registered",
      invalid_credentials:"Wrong email or password",
      account_banned:"This account has been suspended.",
      password_too_short:"Password must be at least 6 characters",
      email_and_password_required:"Enter email and password",
      email_required:"Please enter your email address",
      email_invalid:"Please enter a valid email address",
      email_disposable:"Temporary or fake email addresses are not allowed",
      email_typo:"Check your email — that domain looks misspelled",
      invalid_or_expired_code:"That code is invalid or has expired",
      missing_fields:"Please fill in all fields",
      email_send_failed:"Could not send the email — please try again shortly"
    };
    return m[code] || "Something went wrong";
  }

  document.addEventListener("DOMContentLoaded", function(){
    document.body.appendChild(ov);
    setMode("login");
    var saved = null;
    try { saved = localStorage.getItem("domino_token"); } catch(e){}
    if(saved){
      msg.textContent = "Signing in…";
      fetch(SERVER + "/api/me", { headers:{ Authorization:"Bearer "+saved } })
        .then(function(r){ return r.ok ? r.json() : Promise.reject(); })
        .then(function(d){ saveSession(saved, d.user); })
        .catch(function(){ try{localStorage.removeItem("domino_token");}catch(e){}; msg.textContent=""; show(); });
    } else {
      show();
    }
  });
})();
