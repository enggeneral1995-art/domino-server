/* global_chat.js — public lobby chat, visible to every online player.
 * Fully standalone: its own socket connection, its own DOM overlay.
 * Does not touch net_online.js's in-match chat or game networking.
 */
(function () {
  var SERVER = "https://domino-server-production-dcd7.up.railway.app";

  var socket = null;
  var panelOpen = false;
  var unread = 0;

  function el(t, css, txt) {
    var e = document.createElement(t);
    if (css) e.style.cssText = css;
    if (txt != null) e.textContent = txt;
    return e;
  }

  /* ---------- floating toggle button (+ label) ---------- */

  var toggleWrap = el("div",
    "position:fixed;left:14px;top:14px;z-index:2147483003;display:flex;flex-direction:column;" +
    "align-items:center;gap:4px;-webkit-tap-highlight-color:transparent;user-select:none;cursor:pointer"
  );

  var toggleBtn = el("div",
    "position:relative;width:52px;height:52px;border-radius:50%;" +
    "display:flex;align-items:center;justify-content:center;font-size:24px;" +
    "background:linear-gradient(145deg,#e6cbff,#b17ef0 45%,#7a3fc9);" +
    "box-shadow:0 0 0 3px #091538,0 0 0 5px rgba(177,126,240,.7),0 6px 18px rgba(0,0,0,.45)",
    "💬"
  );

  var toggleLabel = el("div",
    "color:#c9a3f5;font-size:11px;font-weight:bold;text-align:center;" +
    "text-shadow:0 1px 3px rgba(0,0,0,.8);white-space:nowrap",
    t("UI_GLOBAL_CHAT_TITLE")
  );

  var badge = el("div",
    "position:absolute;top:-4px;right:-4px;min-width:18px;height:18px;padding:0 4px;border-radius:9px;" +
    "background:#e03b3b;color:#fff;font:bold 11px/18px Arial,sans-serif;text-align:center;display:none"
  );
  toggleBtn.appendChild(badge);
  toggleWrap.appendChild(toggleBtn);
  toggleWrap.appendChild(toggleLabel);

  /* ---------- chat panel ---------- */

  var panel = el("div",
    "position:fixed;left:14px;right:14px;top:100px;max-width:380px;margin:0 auto;z-index:2147483003;" +
    "height:min(60vh,440px);display:none;flex-direction:column;border-radius:20px;overflow:hidden;" +
    "font-family:Arial,Helvetica,sans-serif;" +
    "background:radial-gradient(circle at 30% 0%,#2a1050,#0a0a1f 70%);" +
    "border:2px solid #7a3fc9;box-shadow:0 18px 45px rgba(0,0,0,.55)"
  );

  var header = el("div",
    "display:flex;align-items:center;justify-content:space-between;padding:12px 16px;" +
    "background:rgba(0,0,0,.25);border-bottom:1px solid rgba(122,63,201,.4)"
  );
  var headerTitle = el("div", "color:#f0dcff;font-weight:bold;font-size:15px", t("UI_GLOBAL_CHAT_TITLE"));
  var closeBtn = el("div",
    "color:#bcb7aa;font-size:20px;line-height:1;cursor:pointer;padding:2px 6px", "×"
  );
  header.appendChild(headerTitle);
  header.appendChild(closeBtn);

  var messagesWrap = el("div",
    "flex:1;overflow-y:auto;padding:10px 14px;display:flex;flex-direction:column;gap:8px"
  );

  var footer = el("div",
    "display:flex;gap:8px;padding:10px;border-top:1px solid rgba(122,63,201,.4);background:rgba(0,0,0,.2)"
  );

  var input = document.createElement("input");
  input.type = "text";
  input.placeholder = t("UI_CHAT_MSG_PLACEHOLDER");
  input.maxLength = 300;
  input.style.cssText =
    "flex:1;min-width:0;padding:10px 12px;border-radius:12px;border:1px solid rgba(122,63,201,.5);" +
    "background:#0b1943;color:#f0dcff;font-size:14px;outline:none";

  var sendBtn = el("div",
    "padding:10px 16px;border-radius:12px;cursor:pointer;font-weight:bold;font-size:14px;" +
    "background:linear-gradient(145deg,#e6cbff,#b17ef0 45%,#7a3fc9);color:#22093f;" +
    "display:flex;align-items:center;justify-content:center;-webkit-tap-highlight-color:transparent",
    t("UI_CHAT_SEND_BTN")
  );

  footer.appendChild(input);
  footer.appendChild(sendBtn);

  panel.appendChild(header);
  panel.appendChild(messagesWrap);
  panel.appendChild(footer);

  function mount() {
    document.body.appendChild(toggleWrap);
    document.body.appendChild(panel);
  }

  if (document.body) {
    mount();
  } else {
    document.addEventListener("DOMContentLoaded", mount);
  }

  /* ---------- open / close ---------- */

  function setOpen(v) {
    panelOpen = v;
    panel.style.display = v ? "flex" : "none";
    if (v) {
      unread = 0;
      badge.style.display = "none";
      setTimeout(function () { messagesWrap.scrollTop = messagesWrap.scrollHeight; }, 0);
    }
  }

  toggleWrap.addEventListener("click", function () { setOpen(!panelOpen); });
  closeBtn.addEventListener("click", function () { setOpen(false); });

  /* ---------- admin open/close switch ---------- */

  // The admin can close the lobby chat at any time. Hiding the launcher is
  // only the visible half -- the server also refuses new messages -- but it
  // is the half players see, so keep it in step live rather than only on
  // the next reload.
  var chatEnabled = true;

  function applyChatEnabled(enabled) {
    chatEnabled = enabled !== false;
    try {
      toggleWrap.style.display = chatEnabled ? "" : "none";
      if (!chatEnabled) setOpen(false);
    } catch (e) {}
  }

  // Current setting at start-up.
  try {
    fetch(SERVER + "/api/app-config")
      .then(function (r) { return r.json(); })
      .then(function (cfg) { applyChatEnabled(cfg && cfg.chat_enabled !== false); })
      .catch(function () {});
  } catch (e) {}

  // Live switch, so players don't have to reload to see it change.
  try {
    socket.on("chat_enabled_changed", function (d) {
      applyChatEnabled(!!(d && d.enabled));
    });
  } catch (e) {}

  /* ---------- messages ---------- */

  var seenMessages = {}; // dedup key -> true, so reconnect catch-up doesn't double-render
  var seenCount = 0;
  var messageRowsById = {};

  function msgKey(msg) {
    return (msg.userId || "") + "|" + (msg.ts || "") + "|" + (msg.text || "");
  }

  function addMessage(msg, mine) {
    var key = msgKey(msg);
    if (seenMessages[key]) return; // already shown (e.g. re-delivered on reconnect catch-up)
    if (seenCount > 2000) { seenMessages = {}; seenCount = 0; } // safety cap for long sessions
    seenMessages[key] = true;
    seenCount++;

    var row = el("div",
      "max-width:82%;padding:8px 12px;border-radius:14px;font-size:13.5px;line-height:1.4;" +
      "word-wrap:break-word;align-self:" + (mine ? "flex-end" : "flex-start") + ";" +
      (mine
        ? "background:rgba(230,203,255,.1);color:#f0dcff;border:1px solid rgba(230,203,255,.25)"
        : "background:rgba(255,255,255,.06);color:#e9e4d6;border:1px solid rgba(255,255,255,.08)")
    );

    if (!mine) {
      var nameEl = el("div", "font-size:11px;font-weight:bold;color:#e6cbff;margin-bottom:2px", msg.name || t("UI_PLAYER_LABEL"));
      row.appendChild(nameEl);
    }

    var textEl = el("div", "", msg.text);
    row.appendChild(textEl);

    if (msg.id != null) {
      row.dataset.msgId = String(msg.id);
      messageRowsById[msg.id] = row;
    }

    if (msg.id != null && window.DOMINO_USER && window.DOMINO_USER.is_chat_moderator) {
      var delBtn = el("span",
        "margin-left:8px;cursor:pointer;opacity:.55;font-size:11px;user-select:none",
        "🗑"
      );
      delBtn.title = t("UI_CHAT_MOD_DELETE");
      delBtn.addEventListener("click", function () {
        try {
          if (socket && socket.connected) {
            socket.emit("delete_global_chat_message", { token: window.DOMINO_TOKEN, message_id: msg.id });
          }
        } catch (e) {}
      });
      row.appendChild(delBtn);
    }

    messagesWrap.appendChild(row);

    // cap history in the DOM so the panel doesn't grow forever
    while (messagesWrap.children.length > 200) {
      messagesWrap.removeChild(messagesWrap.firstChild);
    }

    messagesWrap.scrollTop = messagesWrap.scrollHeight;

    if (!panelOpen && !mine) {
      unread++;
      badge.textContent = unread > 9 ? "9+" : String(unread);
      badge.style.display = "block";
    }
  }

  function addSystemNote(text) {
    var row = el("div",
      "align-self:center;color:#8f8a7c;font-size:12px;padding:2px 0", text
    );
    messagesWrap.appendChild(row);
    messagesWrap.scrollTop = messagesWrap.scrollHeight;
  }

  /* ---------- sending ---------- */

  function doSend() {
    var text = input.value.trim();
    if (!text) return;

    if (!window.DOMINO_TOKEN) {
      addSystemNote(t("UI_CHAT_LOGIN_TO_SEND"));
      return;
    }

    if (!socket || !socket.connected) {
      addSystemNote(t("UI_CHAT_NOT_CONNECTED"));
      return;
    }

    socket.emit("global_chat_message", { token: window.DOMINO_TOKEN, text: text });
    input.value = "";
  }

  sendBtn.addEventListener("click", doSend);
  input.addEventListener("keydown", function (e) {
    if (e.key === "Enter") doSend();
  });

  /* ---------- hide during an active match, show on menu/home ---------- */
  /* CMain fires "start_session" on s_oMain when a match starts (gotoGame)
     and "end_session" when it ends / player exits back to the menu. We
     hide the chat button+panel for the duration of a match and restore it
     once the player is back on the home/menu screen. */

  function hideForGame() {
    setOpen(false);
    toggleWrap.style.display = "none";
  }

  function showForMenu() {
    toggleWrap.style.display = "flex";
  }

  function waitForMainAndBind() {
    if (window.s_oMain && window.jQuery) {
      jQuery(window.s_oMain).on("start_session", hideForGame);
      jQuery(window.s_oMain).on("end_session", showForMenu);
      return;
    }
    setTimeout(waitForMainAndBind, 200);
  }

  waitForMainAndBind();

  /* ---------- history (last 12h; loaded on startup AND on every
     reconnect, so messages sent while the tab was backgrounded/asleep
     — which silently drops the socket on mobile — get caught up on
     instead of just staying missing until a full app restart) ---------- */

  function loadHistory() {
    fetch(SERVER + "/api/global-chat/history")
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var msgs = (data && data.messages) || [];
        msgs.forEach(function (msg) {
          var mine = !!(window.DOMINO_USER && window.DOMINO_USER.id === msg.userId);
          addMessage(msg, mine); // addMessage itself skips anything already shown
        });
      })
      .catch(function () {});
  }

  /* ---------- connection ---------- */

  function connect() {
    try {
      socket = io(SERVER, {
        transports: ["polling", "websocket"],
        reconnection: true,
        reconnectionAttempts: Infinity,
        reconnectionDelay: 800,
        reconnectionDelayMax: 5000,
        randomizationFactor: 0.5,
        timeout: 20000
      });
    } catch (e) {
      return;
    }

    socket.on("global_chat_message", function (msg) {
      if (!msg || typeof msg.text !== "string") return;
      var mine = !!(window.DOMINO_USER && window.DOMINO_USER.id === msg.userId);
      addMessage(msg, mine);
    });

    socket.on("global_chat_message_deleted", function (d) {
      try {
        var id = d && d.id;
        if (id == null) return;
        var row = messageRowsById[id];
        if (row && row.parentNode) row.parentNode.removeChild(row);
        delete messageRowsById[id];
      } catch (e) {}
    });

    socket.on("admin_message", function (msg) {
      if (!msg || typeof msg.text !== "string") return;
      try {
        alert(msg.text);
        if (msg.id != null && window.DOMINO_TOKEN) {
          fetch(SERVER + "/api/admin-messages/" + encodeURIComponent(msg.id) + "/read", {
            method: "POST",
            headers: { "Authorization": "Bearer " + window.DOMINO_TOKEN }
          }).catch(function () {});
        }
      } catch (e) {}
    });

    // Fires on the first connect AND every reconnect after a drop — catch
    // up on anything sent while we were disconnected.
    socket.on("connect", function () {
      loadHistory();
      checkUnreadAdminMessages();
    });
  }

  // Shows any admin message(s) that arrived while the player was fully
  // offline (missed the live "admin_message" socket push above) --
  // checked once per connect, not polled continuously.
  function checkUnreadAdminMessages() {
    if (!window.DOMINO_TOKEN) return;
    fetch(SERVER + "/api/admin-messages/unread", {
      headers: { "Authorization": "Bearer " + window.DOMINO_TOKEN }
    })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var msgs = (data && data.messages) || [];
        msgs.forEach(function (msg) {
          alert(msg.text);
          fetch(SERVER + "/api/admin-messages/" + encodeURIComponent(msg.id) + "/read", {
            method: "POST",
            headers: { "Authorization": "Bearer " + window.DOMINO_TOKEN }
          }).catch(function () {});
        });
      })
      .catch(function () {});
  }

  // Mobile browsers/PWAs frequently freeze background tabs, which kills
  // the WebSocket without the page ever seeing a clean "disconnect"
  // event fire in time — socket.io's own reconnection backoff can then
  // sit idle for a while after the tab becomes active again. Nudging it
  // the moment the page becomes visible makes reconnection (and the
  // history catch-up above) happen immediately instead of waiting.
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && socket && !socket.connected) {
      socket.connect();
    }
  });

  loadHistory();
  connect();
})();
