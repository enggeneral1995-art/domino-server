/* history_panel.js — "History" button (top-right) with two tabs:
 *   1) paid match wins/losses  (GET /api/matches/mine)
 *   2) deposit/withdraw log    (GET /api/wallet/transactions)
 * Fully standalone, same pattern as global_chat.js — its own DOM
 * overlay, does not touch net_online.js or the game engine.
 */
(function () {
  var SERVER = "https://domino-server-production-dcd7.up.railway.app";

  var panelOpen = false;
  var activeTab = "matches"; // "matches" | "wallet"
  var loadedTab = { matches: false, wallet: false };

  function el(t, css, txt) {
    var e = document.createElement(t);
    if (css) e.style.cssText = css;
    if (txt != null) e.textContent = txt;
    return e;
  }

  function fmtDate(iso) {
    try {
      var d = new Date(iso);
      return d.toLocaleDateString() + " " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    } catch (e) {
      return "";
    }
  }

  /* ---------- floating toggle button (+ label), top-right ---------- */

  var toggleWrap = el("div",
    "position:fixed;right:14px;top:14px;z-index:2147483003;display:flex;flex-direction:column;" +
    "align-items:center;gap:4px;-webkit-tap-highlight-color:transparent;user-select:none;cursor:pointer"
  );

  var toggleBtn = el("div",
    "position:relative;width:52px;height:52px;border-radius:50%;" +
    "display:flex;align-items:center;justify-content:center;font-size:24px;" +
    "background:linear-gradient(145deg,#e6cbff,#b17ef0 45%,#7a3fc9);" +
    "box-shadow:0 0 0 3px #091538,0 0 0 5px rgba(177,126,240,.7),0 6px 18px rgba(0,0,0,.45)",
    "🧾"
  );

  var toggleLabel = el("div",
    "color:#ffdc8a;font-size:11px;font-weight:bold;text-align:center;" +
    "text-shadow:0 1px 3px rgba(0,0,0,.8);white-space:nowrap",
    t("UI_HISTORY_TITLE")
  );

  toggleWrap.appendChild(toggleBtn);
  toggleWrap.appendChild(toggleLabel);

  /* ---------- panel ---------- */

  var panel = el("div",
    "position:fixed;left:14px;right:14px;top:100px;max-width:380px;margin:0 auto;z-index:2147483003;" +
    "height:min(64vh,480px);display:none;flex-direction:column;border-radius:20px;overflow:hidden;" +
    "font-family:Arial,Helvetica,sans-serif;" +
    "background:linear-gradient(180deg,rgba(23,20,13,.98),rgba(8,8,6,.99));" +
    "border:2px solid #dba321;box-shadow:0 18px 45px rgba(0,0,0,.55)"
  );

  var header = el("div",
    "display:flex;align-items:center;justify-content:space-between;padding:12px 16px;" +
    "background:rgba(0,0,0,.25);border-bottom:1px solid rgba(214,155,43,.4)"
  );
  var headerTitle = el("div", "color:#ffdc8a;font-weight:bold;font-size:15px", t("UI_HISTORY_TITLE"));
  var closeBtn = el("div",
    "color:#bcb7aa;font-size:20px;line-height:1;cursor:pointer;padding:2px 6px", "×"
  );
  header.appendChild(headerTitle);
  header.appendChild(closeBtn);

  var tabs = el("div",
    "display:flex;gap:8px;padding:10px 12px;border-bottom:1px solid rgba(214,155,43,.25)"
  );

  function tabStyle(active) {
    return "flex:1;text-align:center;padding:9px 6px;border-radius:12px;font-size:13px;font-weight:bold;cursor:pointer;" +
      (active
        ? "background:linear-gradient(145deg,#ffe4a6,#e6ae2a 45%,#c98a12);color:#241705;"
        : "background:rgba(255,255,255,.05);color:#bcb7aa;border:1px solid rgba(214,155,43,.3)");
  }

  var tabMatches = el("div", tabStyle(true), t("UI_HISTORY_TAB_MATCHES"));
  var tabWallet = el("div", tabStyle(false), t("UI_HISTORY_TAB_WALLET"));
  tabs.appendChild(tabMatches);
  tabs.appendChild(tabWallet);

  var listWrap = el("div",
    "flex:1;overflow-y:auto;padding:10px 14px;display:flex;flex-direction:column;gap:8px"
  );

  panel.appendChild(header);
  panel.appendChild(tabs);
  panel.appendChild(listWrap);

  function mount() {
    document.body.appendChild(toggleWrap);
    document.body.appendChild(panel);
  }

  if (document.body) {
    mount();
  } else {
    document.addEventListener("DOMContentLoaded", mount);
  }

  /* ---------- open / close ---------- */

  function setOpen(v) {
    panelOpen = v;
    panel.style.display = v ? "flex" : "none";
    if (v) {
      loadActiveTab();
    }
  }

  toggleWrap.addEventListener("click", function () { setOpen(!panelOpen); });
  closeBtn.addEventListener("click", function () { setOpen(false); });

  function switchTab(tab) {
    activeTab = tab;
    tabMatches.style.cssText = tabStyle(tab === "matches");
    tabWallet.style.cssText = tabStyle(tab === "wallet");
    loadActiveTab();
  }

  tabMatches.addEventListener("click", function () { switchTab("matches"); });
  tabWallet.addEventListener("click", function () { switchTab("wallet"); });

  /* ---------- rendering ---------- */

  function clearList() {
    while (listWrap.firstChild) listWrap.removeChild(listWrap.firstChild);
  }

  function showMessage(text) {
    clearList();
    listWrap.appendChild(
      el("div", "text-align:center;color:#8f8a7c;font-size:13px;padding:24px 8px", text)
    );
  }

  function row(css) {
    return el("div",
      "padding:10px 12px;border-radius:14px;background:rgba(255,255,255,.05);" +
      "border:1px solid rgba(255,255,255,.08);font-size:13px;color:#e9e4d6;" + (css || "")
    );
  }

  function renderMatches(matches) {
    clearList();
    if (!matches.length) {
      showMessage(t("UI_HISTORY_NO_MATCHES"));
      return;
    }
    matches.forEach(function (m) {
      var won = m.won;
      var isSettled = m.status === "settled";

      var amountText = "";
      var amountColor = "#bcb7aa";
      if (isSettled) {
        if (won) {
          amountText = "+" + m.prize;
          amountColor = "#3ddc84";
        } else {
          amountText = "-" + m.stake;
          amountColor = "#ff4d4d";
        }
      } else {
        amountText = m.status;
        amountColor = "#e6ae2a";
      }

      var r = row();
      var top = el("div", "display:flex;justify-content:space-between;align-items:center;margin-bottom:4px");
      top.appendChild(el("div", "font-weight:bold;color:#ffdc8a", m.opponent_name || t("UI_OPPONENT")));
      top.appendChild(el("div", "font-weight:bold;color:" + amountColor, amountText + "$"));
      r.appendChild(top);

      var mid = el("div", "display:flex;justify-content:space-between;color:#bcb7aa;font-size:12.5px");
      mid.appendChild(el("span", "", t("UI_HISTORY_POINTS_LABEL") + m.stake));
      r.appendChild(mid);

      r.appendChild(el("div", "color:#8f8a7c;font-size:11px;margin-top:4px", fmtDate(m.settled_at || m.created_at)));

      listWrap.appendChild(r);
    });
  }

  function renderWallet(txs) {
    clearList();
    if (!txs.length) {
      showMessage(t("UI_HISTORY_NO_WALLET"));
      return;
    }
    txs.forEach(function (t) {
      var isDeposit = t.type === "deposit";
      var label = isDeposit ? t("UI_HISTORY_DEPOSIT") : t("UI_HISTORY_WITHDRAW");
      var color = isDeposit ? "#3ddc84" : "#ffb454";

      var r = row();
      var top = el("div", "display:flex;justify-content:space-between;align-items:center;margin-bottom:4px");
      top.appendChild(el("div", "font-weight:bold;color:" + color, label));
      top.appendChild(el("div", "font-weight:bold;color:#34d399", "USDT " + Number(t.amount).toFixed(2)));
      r.appendChild(top);

      var mid = el("div", "display:flex;justify-content:space-between;color:#bcb7aa;font-size:12.5px");
      mid.appendChild(el("span", "", t.network || ""));
      mid.appendChild(el("span", "", t.status || ""));
      r.appendChild(mid);

      r.appendChild(el("div", "color:#8f8a7c;font-size:11px;margin-top:4px", fmtDate(t.created_at)));

      listWrap.appendChild(r);
    });
  }

  /* ---------- fetching ---------- */

  function loadActiveTab() {
    if (!window.DOMINO_TOKEN) {
      showMessage(t("UI_HISTORY_LOGIN_FIRST"));
      return;
    }

    if (activeTab === "matches") {
      if (loadedTab.matches) { return refetch("matches"); }
      showMessage(t("UI_HISTORY_LOADING"));
      fetchMatches();
    } else {
      if (loadedTab.wallet) { return refetch("wallet"); }
      showMessage(t("UI_HISTORY_LOADING"));
      fetchWallet();
    }
  }

  // cache-bust: always refetch fresh data on every open/switch, but show
  // a lightweight loading state only the first time per tab per session
  function refetch(tab) {
    if (tab === "matches") fetchMatches(); else fetchWallet();
  }

  function authedFetch(path) {
    return fetch(SERVER + path, {
      headers: { Authorization: "Bearer " + window.DOMINO_TOKEN }
    }).then(function (r) {
      if (!r.ok) throw new Error("http_" + r.status);
      return r.json();
    });
  }

  function fetchMatches() {
    authedFetch("/api/matches/mine")
      .then(function (data) {
        loadedTab.matches = true;
        if (activeTab === "matches") renderMatches(data.matches || []);
      })
      .catch(function () {
        if (activeTab === "matches") showMessage(t("UI_HISTORY_ERROR"));
      });
  }

  function fetchWallet() {
    authedFetch("/api/wallet/transactions")
      .then(function (data) {
        loadedTab.wallet = true;
        if (activeTab === "wallet") renderWallet(data.transactions || []);
      })
      .catch(function () {
        if (activeTab === "wallet") showMessage(t("UI_HISTORY_ERROR"));
      });
  }

  /* ---------- hide during an active match, show on menu/home ---------- */

  function hideForGame() {
    setOpen(false);
    toggleWrap.style.display = "none";
  }

  function showForMenu() {
    toggleWrap.style.display = "flex";
  }

  function waitForMainAndBind() {
    if (window.s_oMain && window.jQuery) {
      jQuery(window.s_oMain).on("start_session", hideForGame);
      jQuery(window.s_oMain).on("end_session", showForMenu);
      return;
    }
    setTimeout(waitForMainAndBind, 200);
  }

  waitForMainAndBind();
})();
