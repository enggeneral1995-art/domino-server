/* net_online.js — connects the purchased Domino game to the online server.
 * v6: top USDT balance + Deposit + Withdraw actions, with wallet modal
 *     + goal picker + profile panel (avatar, username, wins/losses).
 * Adds USDT wallet UI (deposit / withdraw) backed by secure server endpoints.
 */
(function () {
  var SERVER = "https://domino-server-production-dcd7.up.railway.app";

  // Called the moment the client detects a freeze it can't recover from on
  // its own -- flags the match immediately in the admin panel (status
  // 'disputed') instead of it silently sitting there until someone happens
  // to notice or the 30-minute auto-refund safety net catches it.
  function reportStuckMatch(reason){
    try {
      var matchId = window.s_oOnlineDeal && window.s_oOnlineDeal.match_id;
      if (!matchId) return; // free/offline match, or no match context -- nothing to flag
      var token = null;
      try { token = localStorage.getItem("domino_token"); } catch(e){}
      var headers = { "Content-Type": "application/json" };
      if (token) headers["Authorization"] = "Bearer " + token;
      fetch(SERVER + "/api/report-stuck-match", {
        method: "POST",
        headers: headers,
        body: JSON.stringify({ match_id: matchId, reason: reason }),
        keepalive: true
      }).catch(function(){});
    } catch(e){}
  }
  window.reportStuckMatch = reportStuckMatch;

  // For small, self-healing hiccups that don't need a match flagged as
  // disputed -- a retry that succeeded on the 2nd try, a brief socket
  // drop -- but are still worth seeing in Diagnostics as a sign of
  // real-world network trouble, even when nothing broke for the player.
  function reportGlitch(message){
    try {
      var matchId = window.s_oOnlineDeal && window.s_oOnlineDeal.match_id;
      var token = null;
      try { token = localStorage.getItem("domino_token"); } catch(e){}
      var headers = { "Content-Type": "application/json" };
      if (token) headers["Authorization"] = "Bearer " + token;
      var payload = { message: "[glitch][" + (window.YD_BUILD || "unknown-build") + "] " + message, source: "glitch-report", url: location.href };
      if (matchId) payload.match_id = matchId;
      fetch(SERVER + "/api/client-error", {
        method: "POST",
        headers: headers,
        body: JSON.stringify(payload),
        keepalive: true
      }).catch(function(){});
    } catch(e){}
  }
  window.reportGlitch = reportGlitch;
  // Build marker. Diagnosing anything is guesswork until we know WHICH
  // client the player is actually running -- a cached old bundle looks
  // exactly like a fix that didn't work. Read it in the browser console
  // or via window.YD_BUILD.
  window.YD_BUILD = "friends-phase6";
  try { console.log("[YD] client build " + window.YD_BUILD); } catch(e){}

  window.requestBoardSyncDiagnostic = function(context){
    try {
      var token = window.DOMINO_TOKEN;
      try {
        if (typeof s_oGame !== "undefined" && s_oGame && s_oGame.getDebugCounts) {
          console.error("[sync-check] (" + context + ") CLIENT locally has: " + JSON.stringify(s_oGame.getDebugCounts()));
        }
      } catch(e){}
      socket.emit("request_board_sync", { token: token });
      socket.once("board_sync_result", function(d){
        try {
          if (!d || !d.ok) { console.error("[sync-check] server had nothing for us (" + context + ")"); return; }
          console.error("[sync-check] (" + context + ") SERVER says: log has " + (d.log ? d.log.length : 0) +
            " entries this round, your hand=" + (d.yourHand ? d.yourHand.length : "?") +
            ", boneyard=" + d.boneyardCount);
        } catch(e){}
        // The server just told us whose turn it authoritatively is. If our
        // local turn drifted (the usual cause of a rejected not_your_turn
        // move and the reload loop that follows), correct it here instead
        // of leaving the player able to tap a tile they aren't allowed to
        // play.
        try {
          if (d && d.ok) { noteServerTurn(d.turnSeat, d.seat); }
          if (d && d.ok && d.turnSeat != null && d.seat != null &&
              typeof s_oGame !== "undefined" && s_oGame && s_oGame.applyServerTurn) {
            s_oGame.applyServerTurn(Number(d.turnSeat) === Number(d.seat) ? 0 : 1);
          }
        } catch(e){}
      });
    } catch(e){}
  };

  // globals the game engine reads
  window.s_bOnline = false;
  window.s_oOnlineDeal = null;
  window.s_bApplyingRemote = false;
  // True only while the manual resume replay (waitForCleanDeal/applyNext,
  // triggered by resume_result's needsFullRebuild) is mid-flight. Checked
  // by CGame.js's rebuildFromState and by the game_state handler below so
  // the two rebuild paths never mutate the same hands/board at once.
  window.YD_RESYNC_IN_PROGRESS = false;
  window.s_oNetSend = null;
  window.s_oNetDraw = null;
  try { window.DOMINO_MUTED = localStorage.getItem("yd_muted") === "1"; } catch(e){ window.DOMINO_MUTED = false; }

  var socket = null;
  var myGoal = 100;
  var myStake = 1;
  var myPrize = 1.90;
  var isFreeMatch = false;
  var currentMatchId = null;
  var autoTurnTimer = null;
  // Resume retries are capped so a client that the server has no room for
  // stops silently spinning on "Connecting..." until the grace window
  // expires. ~30 attempts x 1.5s lands just under the server's 60s grace.
  var resumeRetryCount = 0;
  // Tracks the newest authoritative state applied, and how many times in a
  // row this phone's board has disagreed with it.
  var lastStateSerial = null;
  var stateMismatchStreak = 0;
  // Which round this screen is currently showing. Any authoritative state
  // carrying a different roundSerial belongs to a round we have not dealt
  // yet (or have already left behind) and must be ignored outright.
  var currentRoundSerial = null;
  // What the server last told us about whose turn it is, and when. The
  // engine consults this before letting the player commit anything, so a
  // move the server would refuse is never sent in the first place.
  window.YD_SERVER_TURN_IS_MINE = null;
  window.YD_SERVER_TURN_AT = 0;

  // Why an authoritative state was ignored. Guessing at this from the
  // outside has cost us several rounds of trial and error -- log it, but
  // no more than once every 5s per distinct reason so the console stays
  // readable during a match.
  var lastDropLogAt = {};
  function logStateDrop(reason, extra){
    try {
      var now = Date.now();
      if (lastDropLogAt[reason] && (now - lastDropLogAt[reason]) < 5000) return;
      lastDropLogAt[reason] = now;
      console.error("[state-drop] " + reason + (extra ? " " + extra : ""));
    } catch(e){}
  }

  function noteServerTurn(turnSeat, seat){
    try {
      if (turnSeat == null || seat == null) return;
      var bMine = (Number(turnSeat) === Number(seat));
      if (window.YD_SERVER_TURN_IS_MINE !== bMine) {
        try { console.log("[turn] server says turn is " + (bMine ? "OURS" : "THEIRS")); } catch(e){}
      }
      window.YD_SERVER_TURN_IS_MINE = bMine;
      window.YD_SERVER_TURN_AT = Date.now();
    } catch(e){}
  }
  var RESUME_MAX_RETRIES = 30;
  // no_match_to_resume: the server has looked and found nothing. Only worth
  // retrying across the brief reload/disconnect race, so a handful of tries.
  var RESUME_MAX_RETRIES_DEFINITIVE = 4;
  // Lightweight self-heal. The server sends the full position after every
  // change, so a client that misses one of those messages should correct
  // itself on the next one -- but if a message is simply never delivered
  // (backgrounded tab, a lost frame on a weak mobile link), nothing asks for
  // another, and the board silently sits one entry behind until the player
  // taps a tile and gets not_your_turn. This asks for a fresh position on a
  // timer so the gap closes on its own within a few seconds.
  var gameStateHeartbeat = null;
  function startGameStateHeartbeat(){
    stopGameStateHeartbeat();
    gameStateHeartbeat = setInterval(function(){
      try {
        if (window.s_bOnline && socket && socket.connected) {
          socket.emit("request_game_state");
        }
      } catch(e){}
    }, 4000);
  }
  function stopGameStateHeartbeat(){
    if (gameStateHeartbeat) { clearInterval(gameStateHeartbeat); gameStateHeartbeat = null; }
  }

  var autoTurnWatch = null;
  var autoTurnDeadline = 0;
  var autoTurnBadge = null;

  // Turn-countdown UI now lives only as the ring drawn directly on the
  // local player's profile photo (see CPlayer.js startTurnRing) — the old
  // floating badge here duplicated that, so it's removed. This function
  // still tracks the 10s deadline and triggers auto-play, just silently.
  function clearAutoTurnTimer(){
    if(autoTurnTimer){ clearTimeout(autoTurnTimer); autoTurnTimer=null; }
    autoTurnDeadline=0;
    window.s_bAutoPlayPending=false;
  }

  // Shared cleanup for "this match is over because of a disconnect" --
  // used both when the opponent drops (server sends opponent_left) and
  // when THIS phone reconnects after its own drop. The server now forfeits
  // a match the instant either side's socket really disconnects, so a
  // reconnecting phone has nothing left to resume -- there is no
  // resume_match to ask for anymore. Showing this screen immediately beats
  // leaving the player stuck on "Connecting..." forever.
  function endMatchAfterDrop(){
    clearAutoTurnTimer();
    hideChips();
    window.s_bOnline = false;
    stopGameStateHeartbeat();
    started = false;
    if (matchEndedNormally) return;
    msg.textContent = t("UI_OPPONENT_LEFT");
    showOverlay();
  }

  function armAutoTurnIfNeeded(){
    try{
      // ONLINE authority belongs to the server. Running a second 10s timer
      // in the browser races the server watchdog: both can move at nearly
      // the same instant, after which the client move is correctly rejected
      // as not_your_turn and the old client used to reload mid-match.
      // Keep browser auto-play only for offline/bot games.
      if (window.s_bOnline) { clearAutoTurnTimer(); return; }
      var active = typeof s_oGame!=="undefined" && s_oGame && typeof s_oGame.getTurn==="function" && typeof s_oGame.autoPlayCurrentTurn==="function";
      var myTurn = active && s_oGame.getTurn()===0;
      if(!myTurn){ clearAutoTurnTimer(); return; }
      var now=Date.now();
      if(!autoTurnTimer){
        autoTurnDeadline=now+10000;
        autoTurnTimer=setTimeout(function(){
          autoTurnTimer=null; autoTurnDeadline=0;
          try{
            if(!window.s_bOnline && s_oGame && s_oGame.getTurn()===0 && s_oGame.autoPlayCurrentTurn){ s_oGame.autoPlayCurrentTurn(); }
          }catch(e){
            try { console.error(e); } catch(e2){}
            reportStuckMatch("auto_play_error: " + (e && e.message));
          }
        },10000);
      }
    }catch(e){}
  }
  var mySeat = 0;
  var started = false;
  var matchTimer = null;      // matchmaking timeout helper
  var WAIT_MS = 45000;         // paid matchmaking: how long to wait before giving up (no bot fallback)
  var FREE_WAIT_MS = 15000;    // free play status refresh only; never falls back to a bot

  function clearMatchTimer(){ if(matchTimer){ clearTimeout(matchTimer); matchTimer=null; } }

  var AVATARS = ["😎","🤠","🥷","🧙‍♂️","🧑‍🚀","👩‍🚀","👨‍✈️","👩‍✈️","👨‍💼","👩‍💼","🧑‍🎤","🧑‍💻"];

  // Names shown for the built-in CPU opponent instead of the literal word
  // "Computer" — picked at random each match so it looks like a real player.
  // Mixed Kurdish, Arabic, and English names/nicknames, built from first-
  // name and surname/nickname pools so the combined list has thousands of
  // unique combinations instead of one flat list.
  var CPU_FIRST_NAMES = [
    // Kurdish
    "Rebin","Kawa","Aram","Soran","Diyar","Barzan","Sherko","Hawre","Zana","Peshraw",
    "Newzad","Rawa","Karwan","Alan","Bnar","Gashtin","Hemin","Halo","Ronahi","Shvan",
    "Sara","Lana","Zhala","Hana","Runak","Nazdar","Avin","Shene","Roza","Baran",
    "Chiman","Dilan","Evar","Gulan","Helin","Jian","Kani","Mizgin","Nishtiman","Rojin",
    // Arabic
    "Ahmad","Mohammed","Ali","Omar","Yousif","Hussein","Karim","Sami","Fadi","Tariq",
    "Bilal","Anas","Zaid","Rami","Nabil","Hamza","Yasin","Adel","Salim","Waleed",
    "Fatima","Aisha","Layla","Noor","Rania","Salma","Dina","Huda","Rana","Yasmin",
    "Amal","Reem","Lubna","Mona","Suha","Nadia","Iman","Basma","Wafa","Samira",
    // English
    "James","John","Robert","Michael","David","Daniel","Matthew","Ryan","Kevin","Brian",
    "Emma","Olivia","Sophia","Ava","Isabella","Mia","Charlotte","Amelia","Grace","Chloe",
    "Alex","Jordan","Taylor","Morgan","Casey","Jamie","Sam","Chris","Tony","Mark"
  ];
  var CPU_SURNAMES = [
    // Kurdish-style
    "Hawrami","Sorani","Kurdi","Zagrosi","Botani","Hewleri","Silevani","Bahdinani",
    // Arabic-style
    "Al-Baghdadi","Al-Basri","Al-Amin","Al-Rashid","Hassan","Mahmoud","Saleh","Jassim",
    // English-style
    "Smith","Miller","Brown","Wilson","Moore","Taylor","Anderson","Clark",
    // Gamer-tag style (language-neutral, works with any first name)
    "Pro","X","99","King","Star","FX","TV","Q","Z","Master","Ninja","Legend","Ace","Fox","Wolf","Storm"
  ];
  function randomCpuIdentity(){
    var first = CPU_FIRST_NAMES[Math.floor(Math.random()*CPU_FIRST_NAMES.length)];
    var name = first;
    // ~60% of the time, append a surname/tag for extra variety (still reads
    // naturally either way — "Ahmad" or "Ahmad Pro" / "Sara Al-Amin").
    if (Math.random() < 0.6) {
      var last = CPU_SURNAMES[Math.floor(Math.random()*CPU_SURNAMES.length)];
      name = first + " " + last;
    }
    var avatar = AVATARS[Math.floor(Math.random()*AVATARS.length)];
    return { name: name, avatar: avatar };
  }

  // ---- helpers ----
  function el(t, css, txt){ var e=document.createElement(t); if(css)e.style.cssText=css; if(txt!=null)e.textContent=txt; return e; }
  function nameOf(u){ return (u && (u.username || String(u.email||t("UI_PLAYER_LABEL")).split("@")[0])) || t("UI_PLAYER_LABEL"); }
  function avatarOf(u){
    var a = (u && u.avatar) || "";
    return AVATARS.indexOf(a) !== -1 ? a : "😎";
  }
  function paintAvatar(el, u){
    var url = u && u.photo_url;
    if (url){
      el.textContent = "";
      el.style.backgroundImage = "url('"+url+"')";
      el.style.backgroundSize = "cover";
      el.style.backgroundPosition = "center";
    } else {
      el.style.backgroundImage = "none";
      el.textContent = avatarOf(u);
    }
  }
  // Resize + compress a File to a small square JPEG data-URI, so photo
  // uploads stay tiny (a few KB) regardless of the original photo size.
  function fileToAvatarDataUrl(file, cb){
    var reader = new FileReader();
    reader.onerror = function(){ cb(null); };
    reader.onload = function(){
      var img = new Image();
      img.onerror = function(){ cb(null); };
      img.onload = function(){
        var SIZE = 200;
        var canvas = document.createElement("canvas");
        canvas.width = SIZE; canvas.height = SIZE;
        var ctx = canvas.getContext("2d");
        var side = Math.min(img.width, img.height);
        var sx = (img.width - side) / 2, sy = (img.height - side) / 2;
        ctx.drawImage(img, sx, sy, side, side, 0, 0, SIZE, SIZE);
        try { cb(canvas.toDataURL("image/jpeg", 0.82)); }
        catch(e){ cb(null); }
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  }
  function coinsOf(u){ return (u && (u.coins!=null ? u.coins : (u.balance!=null?Math.round(u.balance):0))) || 0; }
  function usdtBalanceOf(u){ return Number((u && u.balance) || 0); }
  // "usdterc20" / "usdtbsc" (as NOWPayments returns pay_currency) -> "USDT (ERC20)" / "USDT (BEP20)"
  function formatPayCurrency(pc){
    if(!pc) return "USDT";
    var s = String(pc).toUpperCase();
    if(s.indexOf("USDT")===0){
      var rest = s.slice(4);
      if(rest==="BSC") rest = "BEP20";
      return rest ? "USDT ("+rest+")" : "USDT";
    }
    return s;
  }

  // shared button style
  var GOLD = "background:linear-gradient(180deg,#e6cbff,#b17ef0 45%,#7a3fc9);color:#22093f;border:2px solid #e6cbff;";
  var PANEL = "background:linear-gradient(180deg,#15584b,#2458e9);border:3px solid #ddb268;border-radius:20px;box-shadow:0 16px 40px rgba(0,0,0,.6);";

  /* ================= LOBBY ================= */
  // Yalla Domino premium lobby — visual-only refresh. Existing game/wallet logic stays intact.
  var ov = el("div","position:fixed;inset:0;z-index:99999;display:flex;flex-direction:column;align-items:center;background:radial-gradient(120% 70% at 50% 0%,#2355e1 0%,#0f235d 43%,#070707 100%);font-family:Arial,sans-serif;color:#fff;overflow:auto;padding:18px 14px 28px;box-sizing:border-box;pointer-events:auto");
  var shell = el("div","width:100%;max-width:500px;box-sizing:border-box");
  ov.appendChild(shell);

  // ---- HEADER / BRAND ----
  var header = el("div","position:relative;min-height:148px;display:flex;justify-content:center;align-items:flex-start;border-bottom:1px solid rgba(218,161,55,.45);margin-bottom:14px");
  var brand = el("img","width:132px;height:132px;object-fit:contain;filter:drop-shadow(0 8px 18px rgba(0,0,0,.55))");
  brand.src = "icon-512.png?v=fix-20260911l"; brand.alt = "Yalla Domino";
  header.appendChild(brand); shell.appendChild(header);

  // ---- PROFILE ----
  var profileRow = el("div","display:flex;align-items:flex-start;gap:14px;padding:8px 4px 16px");
  var avBadge = el("div","width:66px;height:66px;border-radius:50%;background:#0e225a;border:3px solid #dcb167;box-shadow:0 0 0 2px rgba(255,220,125,.12);display:flex;align-items:center;justify-content:center;font-size:34px;flex:0 0 auto;overflow:hidden;background-size:cover;background-position:center;margin-top:2px","👤");
  var nameWrap = el("div","flex:1;min-width:0");
  var nameTxt = el("div","font-size:19px;color:#fff;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis",t("UI_PLAYER_LABEL"));
  var statsRow = el("div","display:flex;gap:8px;margin-top:9px");
  var winCard = el("div","flex:1;background:#173996;border:1px solid #3b9986;border-radius:12px;padding:8px 10px;text-align:center");
  var winCardNum = el("div","font-size:16px;font-weight:900;color:#74f5db","0");
  var winCardLbl = el("div","font-size:10px;color:#a5c4be;margin-top:1px","🏆 "+t("UI_WINS"));
  winCard.appendChild(winCardNum); winCard.appendChild(winCardLbl);
  var lossCard = el("div","flex:1;background:#1c1414;border:1px solid #5a2a26;border-radius:12px;padding:8px 10px;text-align:center");
  var lossCardNum = el("div","font-size:16px;font-weight:900;color:#e6847e","0");
  var lossCardLbl = el("div","font-size:10px;color:#c49a95;margin-top:1px","❌ "+t("UI_LOSSES"));
  lossCard.appendChild(lossCardNum); lossCard.appendChild(lossCardLbl);

  // ---- TELEGRAM JOIN BONUS BANNER (replaces the wins/losses row here) ----
  var tgBonusBanner = el("div","margin-top:9px;padding:10px 12px;border-radius:12px;border:1px solid #d9a955;background:linear-gradient(135deg,#0a1840,#132f7c);display:flex;align-items:center;gap:10px;cursor:pointer");
  var tgBonusIcon = el("div","font-size:22px;flex:0 0 auto","🎁");
  var tgBonusTextWrap = el("div","flex:1;min-width:0");
  var tgBonusTitle = el("div","font-size:13px;font-weight:800;color:#ffdc9f",t("UI_TG_BONUS_TITLE"));
  var tgBonusSub = el("div","font-size:10.5px;color:#c9b98f;margin-top:2px",t("UI_TG_BONUS_SUB"));
  tgBonusTextWrap.appendChild(tgBonusTitle); tgBonusTextWrap.appendChild(tgBonusSub);
  var tgBonusArrow = el("div","font-size:18px;color:#d9a955;flex:0 0 auto","›");
  tgBonusBanner.appendChild(tgBonusIcon); tgBonusBanner.appendChild(tgBonusTextWrap); tgBonusBanner.appendChild(tgBonusArrow);

  tgBonusBanner.onclick = function(){
    if(!window.DOMINO_TOKEN){ tgBonusSub.textContent = t("UI_TG_BONUS_LOGIN_FIRST"); return; }
    tgBonusSub.textContent = t("UI_TG_BONUS_WAIT");
    fetch(SERVER+"/api/telegram/join-info", { headers: { "Authorization": "Bearer "+window.DOMINO_TOKEN } })
      .then(function(r){ return r.json(); })
      .then(function(info){
        if(info && info.alreadyClaimed){
          tgBonusIcon.textContent = "✅";
          tgBonusTitle.textContent = t("UI_TG_BONUS_ALREADY_TITLE");
          tgBonusSub.textContent = t("UI_TG_BONUS_THANKS");
          return;
        }
        if(info && info.channelLink){
          window.open(info.channelLink, "_blank");
        }
        return fetch(SERVER+"/api/telegram/claim-bonus", {
          method: "POST",
          headers: { "Authorization": "Bearer "+window.DOMINO_TOKEN }
        })
          .then(function(r){ return r.json(); })
          .then(function(res){
            if(res && res.credited){
              tgBonusIcon.textContent = "✅";
              tgBonusTitle.textContent = t("UI_TG_BONUS_CLAIMED_TITLE");
              tgBonusSub.textContent = "$"+Number(res.amount).toFixed(2)+t("UI_TG_BONUS_CREDITED_SUFFIX");
              if(typeof renderUser === "function" && window.DOMINO_USER){
                window.DOMINO_USER.balance = Number(window.DOMINO_USER.balance||0) + Number(res.amount||0);
                renderUser(window.DOMINO_USER);
              }
            } else if(res && res.alreadyClaimed){
              tgBonusIcon.textContent = "✅";
              tgBonusTitle.textContent = t("UI_TG_BONUS_ALREADY_TITLE");
              tgBonusSub.textContent = t("UI_TG_BONUS_THANKS");
            } else {
              tgBonusSub.textContent = t("UI_TG_BONUS_ERROR");
            }
          });
      })
      .catch(function(){
        tgBonusSub.textContent = t("UI_TG_BONUS_ERROR");
      });
  };

  nameWrap.appendChild(nameTxt); nameWrap.appendChild(tgBonusBanner); profileRow.appendChild(avBadge); profileRow.appendChild(nameWrap); shell.appendChild(profileRow);

  // ---- BALANCE ----
  var topBalance = el("div","position:relative;background:linear-gradient(110deg,#121212,#102665);border:1px solid #ac8a50;border-radius:18px;padding:18px 76px 18px 18px;box-sizing:border-box;box-shadow:inset 0 0 30px rgba(176,109,25,.08)");
  topBalance.appendChild(el("div","font-size:14px;color:#a7a7a7;letter-spacing:.04em",t("UI_USDT_BALANCE")));
  var topBalanceTxt = el("div","font-size:27px;color:#34d399;font-weight:800;margin-top:7px;white-space:nowrap","0.00 USDT");
  var usdt = el("div","position:absolute;right:18px;top:50%;transform:translateY(-50%);width:52px;height:52px;border-radius:50%;background:linear-gradient(145deg,#d9ad60,#14836d);border:2px solid #e7c893;display:flex;align-items:center;justify-content:center;color:white;font-size:29px;font-weight:bold;box-shadow:0 6px 16px rgba(0,0,0,.35)","₮");
  topBalance.appendChild(topBalanceTxt); topBalance.appendChild(usdt); shell.appendChild(topBalance);

  // ---- WALLET BUTTONS ----
  var walletTopRow = el("div","display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px");
  var topDepositBtn = el("button","border:1.5px solid #f8e7bf;border-radius:16px;padding:17px 6px;background:linear-gradient(180deg,#f9dba7,#ddb268 45%,#9f7d41);color:#1b43b0;font-family:Arial,sans-serif;font-weight:800;font-size:18px;cursor:pointer;box-shadow:0 7px 18px rgba(0,0,0,.35)",t("UI_DEPOSIT"));
  var topWithdrawBtn = el("button","border:1.5px solid #42ae98;border-radius:16px;padding:17px 6px;background:linear-gradient(180deg,#195a4d,#2151d6);color:#b4f0e4;font-family:Arial,sans-serif;font-weight:800;font-size:18px;cursor:pointer;box-shadow:0 7px 18px rgba(0,0,0,.35)",t("UI_WITHDRAW"));
  walletTopRow.appendChild(topDepositBtn); walletTopRow.appendChild(topWithdrawBtn); shell.appendChild(walletTopRow);

  // ---- 1 ON 1 CARD ----
  var playWrap = el("div","margin-top:14px");
  var bigPlay = el("button","width:100%;min-height:205px;border:1px solid #caa462;border-radius:20px;padding:20px 18px 76px;background:radial-gradient(circle at 24% 45%,rgba(181,110,24,.26),transparent 28%),linear-gradient(115deg,#0e225a,#0b0b0b);color:#fff;font-family:Arial,sans-serif;cursor:pointer;box-sizing:border-box;position:relative;overflow:hidden;box-shadow:0 10px 26px rgba(0,0,0,.42)");
  var dominoArt = el("div","position:absolute;left:28px;top:50%;transform:translateY(-50%) rotate(-10deg);font-size:76px;line-height:1;filter:drop-shadow(0 0 12px rgba(236,174,55,.55))","🁡");
  var bigTextWrap = el("div","position:relative;padding:26px 25% 0;text-align:center;box-sizing:border-box");
  var bigLbl = el("div","font-family:Georgia,serif;font-size:30px;font-weight:bold;color:#c9a3f5;text-shadow:0 2px 8px #000;line-height:1.25;word-break:break-word",t("UI_1ON1"));
  var bigHint = el("div","margin-top:10px;font-size:14px;line-height:1.4;color:#eee",""); bigHint.innerHTML=t("UI_PLAY_VS_REAL");
  bigTextWrap.appendChild(bigLbl); bigTextWrap.appendChild(bigHint);
  var onlineBadge = el("div","position:absolute;right:18px;top:30px;width:68px;height:88px;clip-path:polygon(50% 0,100% 18%,100% 78%,50% 100%,0 78%,0 18%);background:linear-gradient(#e6cbff,#7a3fc9);color:#22093f;display:flex;flex-direction:column;align-items:center;justify-content:center;font-weight:bold;border:1px solid #e6cbff","👥");
  var onlineCountNum = el("div","font-size:24px;line-height:1.1","—");
  onlineBadge.appendChild(onlineCountNum); onlineBadge.appendChild(el("div","font-size:10px",t("UI_ONLINE")));
  var playNow = el("div","position:absolute;left:50%;bottom:22px;transform:translateX(-50%);width:42%;padding:11px 6px;border-radius:13px;background:linear-gradient(180deg,#e6cbff,#b17ef0);color:#22093f;font-size:18px;font-weight:900;text-align:center;box-shadow:0 5px 14px rgba(0,0,0,.4)",t("UI_PLAY_NOW"));
  // Starts dim + relabeled until the socket actually connects -- tapping
  // Play before that used to just silently no-op (the only feedback was
  // tiny gray footer text easy to miss, especially on a slow connection
  // where this "not connected yet" window can last several seconds).
  bigPlay.style.opacity = "0.55";
  playNow.textContent = t("UI_CONNECTING_ELLIPSIS");
  bigPlay.appendChild(dominoArt); bigPlay.appendChild(bigTextWrap); bigPlay.appendChild(onlineBadge); bigPlay.appendChild(playNow); playWrap.appendChild(bigPlay); shell.appendChild(playWrap);

  // ---- TOURNAMENT CARD ----
  var tourWrap = el("div","margin-top:14px");
  var tourCard = el("button","position:relative;width:100%;border:1px solid #9c7d48;border-radius:20px;padding:0;background:linear-gradient(160deg,#132f7c 0%,#0d1d4e 55%,#081230 100%);color:#fff;font-family:Arial,sans-serif;cursor:pointer;box-sizing:border-box;overflow:hidden;box-shadow:0 10px 26px rgba(0,0,0,.45),inset 0 1px 0 rgba(255,255,255,.04);text-align:left");

  var tourGlow = el("div","position:absolute;top:-40%;right:-10%;width:70%;height:180%;background:radial-gradient(circle,rgba(63,217,114,.22) 0%,transparent 68%);pointer-events:none");
  tourCard.appendChild(tourGlow);

  var tourInner = el("div","position:relative;padding:16px 18px;display:flex;align-items:center;gap:14px");

  var tourIcon = el("div","width:52px;height:52px;flex:0 0 auto;border-radius:15px;background:linear-gradient(160deg,#e6cbff 0%,#b17ef0 60%,#7a3fc9 100%);display:flex;align-items:center;justify-content:center;font-size:26px;box-shadow:0 5px 14px rgba(0,0,0,.4),inset 0 1px 0 rgba(255,255,255,.35);transform:rotate(-4deg)","🏆");

  var tourTextWrap = el("div","flex:1;min-width:0");
  var tourTitleRow = el("div","display:flex;align-items:center;gap:7px;flex-wrap:wrap");
  var tourTitle = el("div","font-size:16px;font-weight:800;color:#fff9ea;letter-spacing:.01em",t("UI_WEEKLY_TOURNAMENT"));
  var tourLiveBadge = el("div","font-size:9px;font-weight:800;letter-spacing:.06em;color:#fff;background:#e6342b;border-radius:6px;padding:2px 7px;text-transform:uppercase;box-shadow:0 0 8px rgba(230,52,43,.6)",t("UI_LIVE_BADGE"));
  tourLiveBadge.style.animation = "dmPulse 1.1s ease-in-out infinite";
  tourTitleRow.appendChild(tourTitle); tourTitleRow.appendChild(tourLiveBadge);
  var tourSub = el("div","font-size:12px;color:#cac0a8;margin-top:5px;line-height:1.4",t("UI_TOUR_LOADING"));
  tourTextWrap.appendChild(tourTitleRow); tourTextWrap.appendChild(tourSub);

  var tourArrow = el("div","font-size:20px;color:#f7c46b;flex:0 0 auto;opacity:.75","›");
  tourInner.appendChild(tourIcon); tourInner.appendChild(tourTextWrap); tourInner.appendChild(tourArrow);
  tourCard.appendChild(tourInner);

  var tourFootBar = el("div","position:relative;padding:9px 18px;border-top:1px solid rgba(63,217,114,.18);background:rgba(0,0,0,.22);display:flex;align-items:center;justify-content:space-between;font-size:11px;color:#baad8e");
  var tourFootLeft = el("div","","🥇 "+t("UI_TOUR_TITLE"));
  var tourFootRight = el("div","font-weight:800;color:#f7c46b","→");
  tourFootBar.appendChild(tourFootLeft); tourFootBar.appendChild(tourFootRight);
  tourCard.appendChild(tourFootBar);

  tourWrap.appendChild(tourCard); shell.appendChild(tourWrap);

  // ---- PROFILE / SETTINGS ----
  var row2 = el("div","display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:14px");
  function tile(icon, label, sub){
    var b=el("button","min-height:92px;border:1px solid #2a7163;border-radius:17px;padding:13px;background:linear-gradient(135deg,#0f235d,#0d0d0d);font-family:Arial,sans-serif;color:#fff;cursor:pointer;display:grid;grid-template-columns:52px 1fr 18px;align-items:center;text-align:left;gap:8px");
    b.appendChild(el("div","width:48px;height:48px;border-radius:50%;border:1px solid #a2824c;display:flex;align-items:center;justify-content:center;color:#f3c97f;font-size:27px",icon));
    var tx=el("div",""); tx.appendChild(el("div","font-size:16px;font-weight:800",label)); tx.appendChild(el("div","font-size:10px;color:#aaa;margin-top:6px",sub)); b.appendChild(tx); b.appendChild(el("div","font-size:25px;color:#dcb167","›")); return b;
  }
  var profileTile = tile("●",t("UI_PROFILE"),t("UI_PROFILE_SUB"));
  var settingsTile = tile("⚙",t("UI_SETTINGS"),t("UI_SETTINGS_SUB"));
  row2.appendChild(profileTile); row2.appendChild(settingsTile); shell.appendChild(row2);

  // ---- FRIENDS (phase 1 only: search/request/accept/reject/remove) ----
  // Kept completely outside the game/matchmaking code so this feature cannot
  // alter turns, rooms, scoring or wallet behavior.
  var friendsTile = tile("👥","Friends / هاوڕێکان","Find players and manage friend requests");
  friendsTile.style.width="100%"; friendsTile.style.marginTop="12px";
  shell.appendChild(friendsTile);

  var frOv=el("div","position:fixed;inset:0;z-index:100050;display:none;align-items:flex-start;justify-content:center;background:rgba(0,0,0,.86);padding:18px 12px;box-sizing:border-box;overflow:auto");
  var frCard=el("div",PANEL+"width:100%;max-width:500px;padding:18px;box-sizing:border-box;margin:auto");
  var frTop=el("div","display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:14px");
  frTop.appendChild(el("div","font-size:24px;font-weight:900;color:#f7d395","👥 Friends / هاوڕێکان"));
  var frClose=el("button","border:0;background:transparent;color:#fff;font-size:28px;cursor:pointer","×"); frTop.appendChild(frClose); frCard.appendChild(frTop);
  // Shareable account ID. Uses the existing users.id; no second ID system.
  var frMyIdRow=el("div","display:flex;align-items:center;justify-content:space-between;gap:10px;background:#0b1944;border:1px solid #31548e;border-radius:12px;padding:10px 12px;margin-bottom:10px");
  var frMyIdText=el("div","font-size:14px;color:#fff;font-weight:800","My ID: —");
  var frCopyIdBtn=el("button",GOLD+"border-radius:9px;padding:8px 12px;font-weight:900;cursor:pointer","📋 Copy");
  frMyIdRow.appendChild(frMyIdText); frMyIdRow.appendChild(frCopyIdBtn); frCard.appendChild(frMyIdRow);
  function refreshMyFriendId(){ var id=Number((window.DOMINO_USER&&window.DOMINO_USER.id)||0); frMyIdText.textContent=id?("My ID: "+id):"My ID: —"; return id; }
  function copyFriendId(){ var id=refreshMyFriendId(); if(!id)return; var text=String(id); function ok(){frMsg.textContent="ID copied: "+text;setTimeout(function(){if(frMsg.textContent.indexOf("ID copied")===0)frMsg.textContent="";},1800);} if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(text).then(ok).catch(function(){try{var ta=document.createElement("textarea");ta.value=text;document.body.appendChild(ta);ta.select();document.execCommand("copy");ta.remove();ok();}catch(e){}});}else{try{var ta=document.createElement("textarea");ta.value=text;document.body.appendChild(ta);ta.select();document.execCommand("copy");ta.remove();ok();}catch(e){}} }
  frCopyIdBtn.onclick=copyFriendId;

  var frSearchRow=el("div","display:flex;gap:8px;margin-bottom:10px");
  var frInput=el("input","flex:1;min-width:0;border:1px solid #7f6a45;border-radius:12px;background:#091437;color:#fff;padding:12px;font-size:15px;box-sizing:border-box"); frInput.placeholder="Username or User ID";
  var frSearchBtn=el("button",GOLD+"border-radius:12px;padding:10px 14px;font-weight:900;cursor:pointer","Search");
  frSearchRow.appendChild(frInput); frSearchRow.appendChild(frSearchBtn); frCard.appendChild(frSearchRow);
  var frMsg=el("div","font-size:12px;color:#e7c893;min-height:18px;margin-bottom:8px",""); frCard.appendChild(frMsg);
  var frSearchResults=el("div","margin-bottom:16px",""); frCard.appendChild(frSearchResults);
  var frLists=el("div","",""); frCard.appendChild(frLists); frOv.appendChild(frCard); document.body.appendChild(frOv);

  function frHeaders(){ return {"Content-Type":"application/json","Authorization":"Bearer "+(window.DOMINO_TOKEN||"")}; }
  function frEscape(v){ return String(v==null?"":v).replace(/[&<>\"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'\"':"&quot;","'":"&#39;"}[c];}); }
  function frPerson(item, actionLabel, actionFn, secondaryLabel, secondaryFn){
    var row=el("div","display:flex;align-items:center;gap:10px;background:#0b1944;border:1px solid #31548e;border-radius:12px;padding:10px;margin:7px 0");
    var av=el("div","width:42px;height:42px;border-radius:50%;background:#173996;display:flex;align-items:center;justify-content:center;font-size:22px;overflow:hidden;flex:0 0 auto",item.avatar||"👤");
    if(item.photo_url){ av.textContent=""; av.style.backgroundImage="url("+item.photo_url+")"; av.style.backgroundSize="cover"; av.style.backgroundPosition="center"; }
    var tx=el("div","flex:1;min-width:0"); tx.appendChild(el("div","font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis",item.username||("Player "+item.id))); tx.appendChild(el("div","font-size:11px;color:#aaa;margin-top:3px","ID: "+item.id));
    row.appendChild(av); row.appendChild(tx);
    if(actionLabel){ var b=el("button",GOLD+"border-radius:9px;padding:8px 10px;font-weight:800;cursor:pointer",actionLabel); b.onclick=actionFn; row.appendChild(b); }
    if(secondaryLabel){ var b2=el("button","border:1px solid #9a4949;background:#351414;color:#ffaaaa;border-radius:9px;padding:8px 10px;font-weight:800;cursor:pointer",secondaryLabel); b2.onclick=secondaryFn; row.appendChild(b2); }
    return row;
  }
  function frApi(url,opts){ opts=opts||{}; opts.headers=frHeaders(); return fetch(SERVER+url,opts).then(function(r){return r.json().catch(function(){return {};}).then(function(d){return {ok:r.ok,d:d};});}); }
  function loadFriends(){
    if(!window.DOMINO_TOKEN){ frMsg.textContent="Please sign in first"; return; }
    frLists.innerHTML=""; frLists.appendChild(el("div","color:#aaa;text-align:center;padding:12px","Loading…"));
    frApi("/api/friends").then(function(r){
      frLists.innerHTML=""; if(!r.ok){frMsg.textContent="Could not load friends";return;}
      var d=r.d||{};
      function title(txt,n){ frLists.appendChild(el("div","font-size:15px;font-weight:900;color:#f7d395;margin:14px 0 5px",txt+" ("+n+")")); }
      title("Friend requests / داواکاری هاوڕێیەتی",(d.incoming||[]).length);
      (d.incoming||[]).forEach(function(x){ frLists.appendChild(frPerson(x,"Accept",function(){frApi("/api/friends/"+x.friendship_id+"/respond",{method:"POST",body:JSON.stringify({action:"accept"})}).then(loadFriends);},"Reject",function(){frApi("/api/friends/"+x.friendship_id+"/respond",{method:"POST",body:JSON.stringify({action:"reject"})}).then(loadFriends);})); });
      if(!(d.incoming||[]).length) frLists.appendChild(el("div","font-size:12px;color:#888","No new requests"));
      title("My friends / هاوڕێکانم",(d.friends||[]).length);
      (d.friends||[]).forEach(function(x){
        var row=frPerson(x,"Chat",function(){openFriendChat(x);},"Remove",function(){if(confirm("Remove this friend?")) frApi("/api/friends/"+x.friendship_id,{method:"DELETE"}).then(loadFriends);});
        row.setAttribute("data-friend-id",String(x.id));
        var tx=row.children[1]; if(tx){ var st=el("div","font-size:11px;margin-top:3px;color:#888","● Offline"); st.setAttribute("data-presence-id",String(x.id)); tx.appendChild(st); var note=el("div","font-size:11px;margin-top:3px;color:#ffd36b;display:none",""); note.setAttribute("data-friend-lastmsg",String(x.id)); tx.appendChild(note); }
        var badge=el("div","display:none;min-width:22px;height:22px;padding:0 6px;border-radius:999px;background:#e52d3f;color:#fff;align-items:center;justify-content:center;font-size:12px;font-weight:900;box-sizing:border-box","0"); badge.setAttribute("data-friend-unread",String(x.id)); row.insertBefore(badge,row.children[2]||null);
        frLists.appendChild(row);
      });
      if(!(d.friends||[]).length) frLists.appendChild(el("div","font-size:12px;color:#888","No friends yet"));
      refreshFriendUnread();
      title("Sent requests / داواکاری نێردراو",(d.outgoing||[]).length);
      (d.outgoing||[]).forEach(function(x){ frLists.appendChild(frPerson(x,null,null,"Cancel",function(){frApi("/api/friends/"+x.friendship_id,{method:"DELETE"}).then(loadFriends);})); });
    }).catch(function(){frMsg.textContent="Network error";});
  }
  function searchFriends(){
    var q=frInput.value.trim(); if(q.length<2){frMsg.textContent="Write at least 2 characters";return;}
    frMsg.textContent="Searching…"; frSearchResults.innerHTML="";
    frApi("/api/friends/search?q="+encodeURIComponent(q)).then(function(r){
      frMsg.textContent=""; if(!r.ok){frMsg.textContent="Search failed";return;}
      var users=(r.d&&r.d.users)||[]; if(!users.length){frMsg.textContent="No player found";return;}
      users.forEach(function(x){frSearchResults.appendChild(frPerson(x,"Add Friend",function(){frApi("/api/friends/request",{method:"POST",body:JSON.stringify({user_id:x.id})}).then(function(z){frMsg.textContent=z.ok?(z.d.accepted?"Friend added":"Request sent"):(z.d.error||"Could not send request");loadFriends();});}));});
    }).catch(function(){frMsg.textContent="Network error";});
  }
  // ---- FRIEND PRESENCE + PRIVATE CHAT (phase 2) ----
  var frChatOv=el("div","position:fixed;inset:0;z-index:100060;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.9);padding:12px;box-sizing:border-box");
  var frChatCard=el("div",PANEL+"width:100%;max-width:500px;height:min(680px,88vh);padding:0;box-sizing:border-box;display:flex;flex-direction:column;overflow:hidden");
  var frChatTop=el("div","display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid #31548e");
  var frChatTitle=el("div","font-size:18px;font-weight:900;color:#f7d395","Chat");
  var frChatClose=el("button","border:0;background:transparent;color:#fff;font-size:28px;cursor:pointer","×"); frChatTop.appendChild(frChatTitle);frChatTop.appendChild(frChatClose);
  var frChatMsgs=el("div","flex:1;overflow:auto;padding:12px;background:#06102c");
  var frChatBottom=el("div","display:flex;gap:8px;padding:10px;border-top:1px solid #31548e;background:#0b1944");
  var frChatInput=el("input","flex:1;min-width:0;border:1px solid #7f6a45;border-radius:12px;background:#091437;color:#fff;padding:12px;font-size:15px;box-sizing:border-box"); frChatInput.placeholder="Write a message…"; frChatInput.maxLength=500;
  var frChatSend=el("button",GOLD+"border-radius:12px;padding:10px 14px;font-weight:900;cursor:pointer","Send"); frChatBottom.appendChild(frChatInput);frChatBottom.appendChild(frChatSend);
  frChatCard.appendChild(frChatTop);frChatCard.appendChild(frChatMsgs);frChatCard.appendChild(frChatBottom);frChatOv.appendChild(frChatCard);document.body.appendChild(frChatOv);
  var activeFriend=null, friendLastMsg=0, friendChatTimer=null, friendPresenceTimer=null;
  function myFriendId(){ return Number((window.DOMINO_USER&&window.DOMINO_USER.id)||0); }
  function renderFriendMessage(m){
    if(frChatMsgs.querySelector('[data-msg-id="'+m.id+'"]')) return;
    var mine=Number(m.sender_id)===myFriendId();
    var wrap=el("div","display:flex;margin:7px 0;justify-content:"+(mine?"flex-end":"flex-start"));
    var bubble=el("div","max-width:80%;padding:9px 11px;border-radius:13px;background:"+(mine?"#1f5d9f":"#182a55")+";color:#fff;font-size:14px;line-height:1.35;word-break:break-word","");
    bubble.appendChild(el("div","",m.text||""));
    var dt=new Date(Number(m.ts)||Date.now()); var hh=String(dt.getHours()).padStart(2,"0"), mm=String(dt.getMinutes()).padStart(2,"0");
    bubble.appendChild(el("div","font-size:10px;opacity:.7;text-align:right;margin-top:4px",hh+":"+mm));
    wrap.setAttribute("data-msg-id",String(m.id));wrap.appendChild(bubble);frChatMsgs.appendChild(wrap);friendLastMsg=Math.max(friendLastMsg,Number(m.id)||0);frChatMsgs.scrollTop=frChatMsgs.scrollHeight;
  }
  function pollFriendChat(){ if(!activeFriend||frChatOv.style.display==="none")return; frApi("/api/friends/"+activeFriend.id+"/messages?after="+friendLastMsg).then(function(r){if(r.ok){((r.d&&r.d.messages)||[]).forEach(renderFriendMessage);frApi("/api/friends/"+activeFriend.id+"/read",{method:"POST",body:"{}"}).then(refreshFriendUnread);}}).catch(function(){}); }
  function openFriendChat(x){ activeFriend=x;friendLastMsg=0;frChatMsgs.innerHTML="";frChatTitle.textContent="💬 "+(x.username||("Player "+x.id));frChatOv.style.display="flex";frApi("/api/friends/"+x.id+"/read",{method:"POST",body:"{}"}).then(refreshFriendUnread);pollFriendChat();clearInterval(friendChatTimer);friendChatTimer=setInterval(pollFriendChat,2500);setTimeout(function(){frChatInput.focus();},100); }
  function closeFriendChat(){frChatOv.style.display="none";activeFriend=null;clearInterval(friendChatTimer);friendChatTimer=null;}
  function sendFriendMessage(){
    var text=frChatInput.value.trim();
    if(!activeFriend||!text)return;
    frChatInput.value="";
    frApi("/api/friends/"+activeFriend.id+"/messages",{method:"POST",body:JSON.stringify({text:text})}).then(function(r){
      if(r.ok&&r.d&&r.d.message){ renderFriendMessage(r.d.message); return; }
      // The send failed. The box was already cleared, so without this the
      // player's message simply vanishes and they have no idea why. Give it
      // back to them instead of swallowing it.
      if(!frChatInput.value) frChatInput.value=text;
      var why=(r.d&&r.d.error)||"";
      if(why==="too_fast") frChatSendNote("Slow down a moment, then send again.");
      else if(why==="not_friends") frChatSendNote("You are no longer friends with this player.");
      else frChatSendNote("Message not sent. Try again.");
    }).catch(function(){
      if(!frChatInput.value) frChatInput.value=text;
      frChatSendNote("Message not sent. Check your connection.");
    });
  }

  // A short, self-clearing line under the chat box.
  var frNoteTimer=null;
  function frChatSendNote(msg){
    try{
      var n=document.getElementById("frChatNote");
      if(!n){
        n=document.createElement("div");
        n.id="frChatNote";
        n.style.cssText="padding:4px 10px;font-size:12px;color:#ffb454;min-height:16px";
        if(frChatInput&&frChatInput.parentNode) frChatInput.parentNode.insertBefore(n,frChatInput);
      }
      n.textContent=msg;
      clearTimeout(frNoteTimer);
      frNoteTimer=setTimeout(function(){ try{n.textContent="";}catch(e){} },4000);
    }catch(e){}
  }
  frChatClose.onclick=closeFriendChat;frChatOv.onclick=function(e){if(e.target===frChatOv)closeFriendChat();};frChatSend.onclick=sendFriendMessage;frChatInput.addEventListener("keydown",function(e){if(e.key==="Enter")sendFriendMessage();});
  function refreshFriendUnread(){
    if(!window.DOMINO_TOKEN)return;
    frApi("/api/friends/unread").then(function(r){if(!r.ok)return;var u=(r.d&&r.d.unread)||{};document.querySelectorAll("[data-friend-unread]").forEach(function(n){var v=u[n.getAttribute("data-friend-unread")],c=v?Number(v.count)||0:0;n.textContent=c>99?"99+":String(c);n.style.display=c?"flex":"none";});document.querySelectorAll("[data-friend-lastmsg]").forEach(function(n){var v=u[n.getAttribute("data-friend-lastmsg")];if(v&&v.lastTs){var d=new Date(v.lastTs),hh=String(d.getHours()).padStart(2,"0"),mm=String(d.getMinutes()).padStart(2,"0");n.textContent="New message • "+hh+":"+mm;n.style.display="block";}else{n.textContent="";n.style.display="none";}});}).catch(function(){});
  }
  function updateFriendPresence(){
    if(!window.DOMINO_TOKEN)return;
    frApi("/api/friends/presence",{method:"POST",body:"{}"}).catch(function(){});
    frApi("/api/friends/presence").then(function(r){if(!r.ok)return;var on=(r.d&&r.d.online)||{};document.querySelectorAll("[data-presence-id]").forEach(function(n){var yes=!!on[n.getAttribute("data-presence-id")];n.textContent=yes?"● Online":"● Offline";n.style.color=yes?"#48e27b":"#888";});}).catch(function(){});
  }
  function startFriendPresence(){updateFriendPresence();refreshFriendUnread();clearInterval(friendPresenceTimer);friendPresenceTimer=setInterval(function(){updateFriendPresence();refreshFriendUnread();},10000);}
  friendsTile.onclick=function(){ frOv.style.display="flex"; frSearchResults.innerHTML=""; frMsg.textContent=""; refreshMyFriendId(); loadFriends(); startFriendPresence(); };
  frClose.onclick=function(){frOv.style.display="none";}; frOv.onclick=function(e){if(e.target===frOv)frOv.style.display="none";};
  frSearchBtn.onclick=searchFriends; frInput.addEventListener("keydown",function(e){if(e.key==="Enter")searchFriends();});

  // ---- IN-MATCH ADD FRIEND (real 1v1 only) ----
  // This is UI + the existing /api/friends/request endpoint only. It never
  // writes to domino room state, turns, scores, matchmaking or balances.
  var matchFriendBtn=el("button","position:fixed;z-index:100040;display:none;border:1px solid #f0c36a;border-radius:10px;padding:6px 9px;background:rgba(9,20,55,.94);color:#ffe2a3;font-size:11px;font-weight:900;box-shadow:0 3px 12px rgba(0,0,0,.35);cursor:pointer;white-space:nowrap","➕ Friend");
  document.body.appendChild(matchFriendBtn);
  // Keep the Friend control inside the opponent profile card rather than
  // floating over the table. Coordinates are derived from the scaled game
  // canvas, so the placement follows the board on different phone sizes.
  function positionMatchFriendButton(){
    try{
      var cv=document.getElementById("canvas"); if(!cv)return;
      var r=cv.getBoundingClientRect(); if(!r.width||!r.height)return;
      // Opponent HUD: right/lower portion of the top profile card.
      matchFriendBtn.style.left=(r.left+r.width*0.60)+"px";
      matchFriendBtn.style.top=(r.top+r.height*0.135)+"px";
      matchFriendBtn.style.right="auto";
      matchFriendBtn.style.transform="translate(-50%,-50%)";
      var scale=Math.max(.72,Math.min(1,r.width/768));
      matchFriendBtn.style.fontSize=(11*scale)+"px";
      matchFriendBtn.style.padding=(6*scale)+"px "+(9*scale)+"px";
    }catch(e){}
  }
  window.addEventListener("resize",positionMatchFriendButton);
  window.addEventListener("orientationchange",function(){setTimeout(positionMatchFriendButton,150);});
  function setMatchFriendState(){
    var opp=window.DOMINO_OPP||{}, oid=Number(opp.id||0);
    if(!window.s_bOnline||!oid||!window.DOMINO_TOKEN){matchFriendBtn.style.display="none";return;}
    matchFriendBtn.style.display="block"; positionMatchFriendButton(); matchFriendBtn.disabled=false; matchFriendBtn.textContent="➕ Friend";
    frApi("/api/friends").then(function(r){if(!r.ok)return;var d=r.d||{};
      if((d.friends||[]).some(function(x){return Number(x.id)===oid;})){matchFriendBtn.textContent="✓ Friends";matchFriendBtn.disabled=true;return;}
      if((d.outgoing||[]).some(function(x){return Number(x.id)===oid;})){matchFriendBtn.textContent="✓ Request sent";matchFriendBtn.disabled=true;return;}
      if((d.incoming||[]).some(function(x){return Number(x.id)===oid;})){matchFriendBtn.textContent="➕ Accept in Friends";matchFriendBtn.disabled=true;}
    }).catch(function(){});
  }
  matchFriendBtn.onclick=function(){var oid=Number((window.DOMINO_OPP&&window.DOMINO_OPP.id)||0);if(!oid)return;matchFriendBtn.disabled=true;matchFriendBtn.textContent="Sending…";frApi("/api/friends/request",{method:"POST",body:JSON.stringify({user_id:oid})}).then(function(r){if(r.ok){matchFriendBtn.textContent=r.d&&r.d.accepted?"✓ Friends":"✓ Request sent";}else if(r.d&&r.d.error==="already_friends"){matchFriendBtn.textContent="✓ Friends";}else if(r.d&&r.d.error==="request_already_sent"){matchFriendBtn.textContent="✓ Request sent";}else{matchFriendBtn.disabled=false;matchFriendBtn.textContent="➕ Friend";}}).catch(function(){matchFriendBtn.disabled=false;matchFriendBtn.textContent="➕ Friend";});};
  window.YD_refreshMatchFriendButton=setMatchFriendState;

  // ---- STATUS + LOGOUT ----
  var statusRow = el("div","display:flex;align-items:center;justify-content:center;gap:18px;color:#cfcfcf;font-size:13px;margin-top:18px");
  statusRow.appendChild(el("div","",t("UI_CONNECTED"))); statusRow.appendChild(el("div","color:#2f665b","│")); statusRow.appendChild(el("div","",t("UI_SECURE"))); shell.appendChild(statusRow);
  var msg = el("div","font-size:11px;color:#aaa;margin-top:7px;text-align:center;min-height:14px","connecting…");
  var logoutLink = el("button","display:block;width:60%;min-width:220px;margin:13px auto 4px;border:1px solid #b42420;border-radius:16px;padding:12px;background:transparent;color:#ef4139;font-size:16px;font-weight:800;cursor:pointer",t("UI_LOGOUT"));
  logoutLink.onclick = function(){ if(window.dominoLogout) window.dominoLogout(); };
  shell.appendChild(msg); shell.appendChild(logoutLink);
  function renderUser(u){
    if(!u) return;
    paintAvatar(avBadge, u);
    nameTxt.textContent = nameOf(u);
    winCardNum.textContent = String(u.wins||0);
    lossCardNum.textContent = String(u.losses||0);
    topBalanceTxt.textContent = usdtBalanceOf(u).toFixed(2) + " USDT";
  }
  window.dominoOnUserReady = function(user){ if(user){ renderUser(user); } };
  if (window.DOMINO_USER) renderUser(window.DOMINO_USER);

  // Report a finished game (offline vs Computer). Online is handled server-side later.
  var matchEndedNormally = false;
  window.dominoOnlineReportResult = function(didWin){
    matchEndedNormally = true;
    if (!window.s_bOnline) return;
    if (!socket || !socket.connected) return;
    socket.emit("report_result", {
      match_id: currentMatchId,
      didWin: !!didWin,
      token: window.DOMINO_TOKEN || ""
    });
  };

  // Ask the server to deal a fresh round within the SAME match (used when a
  // round ends without either player reaching the score goal). The board is
  // reloaded once the server's "online_start" event comes back with the new
  // hands — see the online_start handler below.
  // Ask the server for the authoritative position. Used by CGame when a
  // move answer arrives after its wait expired: rather than replaying a
  // move that may already be on the board, it asks what is actually true.
  window.dominoRequestState = function(){
    if (!window.s_bOnline || !socket || !socket.connected) return;
    try {
      lastStateSerial = null;        // accept the next state whatever its serial
      socket.emit("request_game_state");
    } catch(e){}
  };

  window.dominoRequestNextRound = function(){
    if (!window.s_bOnline || !socket || !socket.connected) return;
    socket.emit("next_round");
  };

  window.dominoReportResult = function(didWin){
    if (window.s_bOnline) return;
    if (!window.DOMINO_TOKEN) return;
    fetch(SERVER + "/api/game-result", {
      method:"POST",
      headers:{ "Content-Type":"application/json", Authorization:"Bearer "+window.DOMINO_TOKEN },
      body: JSON.stringify({ result: didWin ? "win" : "loss", entry: myGoal })
    })
      .then(function(r){ return r.ok ? r.json() : null; })
      .then(function(d){ if(d && d.user){ window.DOMINO_USER = d.user; renderUser(d.user); } })
      .catch(function(){});
  };

  function showOverlay(){ hideChips(); ov.style.display="flex"; }
  function hideOverlay(){ ov.style.display="none"; }

  /* ================= GOAL PICKER (after tapping 1 ON 1) ================= */
  var gov = el("div","position:fixed;inset:0;z-index:100000;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.82);backdrop-filter:blur(6px);font-family:Arial,sans-serif;color:#fff;padding:16px;box-sizing:border-box");

  var gcard = el("div","position:relative;background:radial-gradient(circle at 50% 0%,rgba(153,101,25,.28),transparent 34%),linear-gradient(165deg,#153183 0%,#0b1b47 58%,#081230 100%);border:2px solid #ddae5c;border-radius:30px;box-shadow:0 24px 75px rgba(0,0,0,.88),0 0 30px rgba(218,165,43,.16),inset 0 1px 0 rgba(255,230,150,.20);padding:58px 18px 22px;max-width:520px;width:96%;text-align:center;box-sizing:border-box;overflow:visible");

  var badge = el("div","position:absolute;left:50%;top:-52px;transform:translateX(-50%);width:104px;height:104px;border-radius:26px;display:flex;align-items:center;justify-content:center;background:#081230;border:3px solid #f4cb85;box-shadow:0 0 0 6px rgba(37,23,6,.92),0 0 30px rgba(238,190,67,.48);overflow:hidden");
  var badgeLogo = document.createElement("img");
  badgeLogo.src = "icon-192.png?v=fix-20260911l";
  badgeLogo.alt = "Yalla Domino";
  badgeLogo.style.cssText = "width:100%;height:100%;object-fit:cover;display:block";
  badge.appendChild(badgeLogo);
  gcard.appendChild(badge);

  gcard.appendChild(el("div","font-size:32px;font-weight:900;color:#facc7c;margin:6px 0 6px;text-shadow:0 2px 14px rgba(235,177,41,.30);letter-spacing:.2px",t("UI_CHOOSE_MATCH")));
  gcard.appendChild(el("div","font-size:17px;color:#f1eee8;opacity:.96;margin-bottom:14px",t("UI_CHOOSE_ENTRY")));

  var prizeTxt = el("div","display:inline-flex;align-items:center;justify-content:center;gap:9px;max-width:100%;box-sizing:border-box;padding:10px 18px;border-radius:14px;border:1px solid #227a68;background:linear-gradient(180deg,#11296c,#091538);font-size:16px;color:#f8f0de;margin-bottom:24px;box-shadow:inset 0 1px 0 rgba(255,225,140,.12)","");
  prizeTxt.innerHTML='<span style="font-size:24px">🎁</span><span><b style="color:#f7c46b">'+t("UI_FREE_MATCH")+'</b></span>';
  gcard.appendChild(prizeTxt);

  var goalRow = el("div","display:grid;grid-template-columns:repeat(4,1fr);gap:10px;justify-content:center;margin-bottom:28px");
  var goalBtns = [];
  var goalBtnMeta = []; // {btn, free} — used to hide paid options if paid features are disabled
  var stakeOptions = [
    {label:t("UI_ENTRY_FREE_SHORT"), stake:0, goal:100, prize:0, free:true, icon:"🎁"},
    {label:"$1", stake:1, goal:100, prize:1.90, free:false, icon:"🪙"},
    {label:"$3", stake:3, goal:200, prize:5.60, free:false, icon:"🪙"},
    {label:"$5", stake:5, goal:500, prize:9.00, free:false, icon:"🪙"}
  ];

  stakeOptions.forEach(function(opt){
    var b = el("button","position:relative;min-width:0;border:1.8px solid #d9aa5a;border-radius:16px;padding:15px 3px 13px;font-family:Arial,sans-serif;cursor:pointer;background:linear-gradient(180deg,#0f2561 0%,#081230 100%);color:#ecbd6b;box-shadow:inset 0 1px 0 rgba(255,235,165,.10),0 7px 18px rgba(0,0,0,.35)");
    b.innerHTML='<div style="font-size:24px;font-weight:900;line-height:1.05;margin-bottom:8px">'+opt.label+'</div><div style="font-size:22px;line-height:1">'+opt.icon+'</div>';

    function selectThis(){
      matchMsg.textContent="";
      isFreeMatch=!!opt.free;
      myStake=opt.stake;
      myGoal=opt.goal;
      myPrize=opt.prize;

      prizeTxt.innerHTML = opt.free
        ? '<span style="font-size:24px">🎁</span><span><b style="color:#f7c46b">'+t("UI_FREE_MATCH")+'</b></span>'
        : '<span style="font-size:23px">🏆</span><span>'+t("UI_WINNER_RECEIVES")+' <b style="color:#34d399">' + opt.prize.toFixed(2) + ' USDT</b></span>';

      goalBtns.forEach(function(x){
        x.style.background="linear-gradient(180deg,#0f2561 0%,#081230 100%)";
        x.style.color="#ecbd6b";
        x.style.borderColor="#d9aa5a";
        x.style.boxShadow="inset 0 1px 0 rgba(255,235,165,.10),0 7px 18px rgba(0,0,0,.35)";
      });

      b.style.background="linear-gradient(180deg,#ffdea4 0%,#edb554 56%,#bb8b37 100%)";
      b.style.color="#112769";
      b.style.borderColor="#ffe5b8";
      b.style.boxShadow="0 0 0 3px rgba(255,232,138,.18),0 0 20px rgba(244,193,60,.32),inset 0 1px 0 rgba(255,255,255,.85)";
    }

    b.onclick=selectThis;
    goalBtns.push(b);
    goalBtnMeta.push({btn:b, free:!!opt.free});
    goalRow.appendChild(b);
    if(opt.free) setTimeout(selectThis,0);
  });

  gcard.appendChild(goalRow);

  var matchMsg = el("div","font-size:13px;color:#ffe4b8;min-height:18px;margin:0 0 10px","");
  gcard.appendChild(matchMsg);

  var playBtn = el("button","width:100%;border:0;border-radius:17px;padding:18px 0;font-size:22px;font-weight:900;font-family:Arial,sans-serif;cursor:pointer;background:linear-gradient(180deg,#ffdca0 0%,#f4bd5d 52%,#cd993f 100%);color:#132f7c;box-shadow:0 8px 22px rgba(202,151,24,.30),inset 0 1px 0 rgba(255,255,255,.82);margin-top:2px",t("UI_PLAY_ONLINE"));

  var gback = el("button","width:100%;background:linear-gradient(180deg,#0e225a,#081230);border:1.7px solid #d7a95a;color:#f4cb83;border-radius:17px;padding:15px 0;font-size:19px;font-weight:700;font-family:Arial,sans-serif;cursor:pointer;margin-top:14px;box-shadow:inset 0 1px 0 rgba(255,225,140,.10)",t("UI_BACK"));

  gcard.appendChild(playBtn);
  gcard.appendChild(gback);
  gov.appendChild(gcard);

  function openGoal(){ gov.style.display="flex"; }
  function closeGoal(){ gov.style.display="none"; }
  gback.onclick = closeGoal;
  bigPlay.onclick = function(){
    if (!socket || !socket.connected){
      msg.textContent=t("UI_NOT_CONNECTED_YET_WAIT");
      // The gray footer text alone is easy to miss, especially on a slow
      // connection where players are likely to tap Play more than once
      // while waiting -- a quick shake on the button itself makes it
      // obvious the tap registered but isn't ready yet, instead of
      // looking like the button is simply broken.
      try {
        bigPlay.style.transition = "transform 0.08s";
        bigPlay.style.transform = "translateX(-6px)";
        setTimeout(function(){ bigPlay.style.transform = "translateX(6px)"; }, 80);
        setTimeout(function(){ bigPlay.style.transform = "translateX(0)"; }, 160);
      } catch(e){}
      return;
    }
    openGoal();
  };

  /* ================= PROFILE ================= */
  var pov = el("div","position:fixed;inset:0;z-index:100001;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.90);font-family:Arial,sans-serif;color:#fff;padding:14px;box-sizing:border-box");
  var pcard = el("div","position:relative;width:min(92vw,430px);max-height:92vh;overflow:auto;box-sizing:border-box;padding:24px 20px 20px;border:2px solid #e8b55e;border-radius:26px;background:radial-gradient(circle at 50% 16%,rgba(170,105,15,.20),transparent 24%),linear-gradient(180deg,#0e2056 0%,#081230 100%);box-shadow:0 0 26px rgba(231,172,45,.24),inset 0 0 22px rgba(255,191,48,.05)");
  pcard.appendChild(el("div","font-family:Georgia,serif;font-size:34px;font-weight:bold;color:#fad594;text-align:center;margin:0 0 16px;text-shadow:0 2px 12px rgba(255,190,42,.25)",t("UI_MY_PROFILE")));

  var avatarWrap=el("div","position:relative;width:126px;height:126px;margin:0 auto 14px;border:4px solid #f5c778;border-radius:50%;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle,#165649 0%,#0f2561 65%,#050505 100%);box-shadow:0 0 22px rgba(242,190,47,.35);overflow:hidden");
  var bigAvatar = el("div","font-size:76px;text-align:center;line-height:1;width:100%;height:100%;border-radius:50%;display:flex;align-items:center;justify-content:center;background-size:cover;background-position:center","👨🏻");
  avatarWrap.appendChild(bigAvatar);
  var editBadge=el("div","position:absolute;right:-2px;bottom:4px;width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:linear-gradient(#ffdea4,#dea84b);border:2px solid #ffe0ab;color:#0f2561;font-size:20px;box-shadow:0 4px 10px #000;cursor:pointer","✎");
  avatarWrap.appendChild(editBadge); pcard.appendChild(avatarWrap);
  var photoInput = document.createElement("input");
  photoInput.type = "file"; photoInput.accept = "image/*"; photoInput.style.display = "none";
  pcard.appendChild(photoInput);
  var pendingPhotoDataUrl = null; // set when a new photo is picked, sent on Save
  editBadge.onclick = function(){ photoInput.click(); };
  photoInput.onchange = function(){
    var f = photoInput.files && photoInput.files[0];
    if (!f) return;
    pmsg.textContent = t("UI_PROCESSING_PHOTO");
    fileToAvatarDataUrl(f, function(dataUrl){
      if (!dataUrl){ pmsg.textContent = t("UI_PHOTO_READ_FAIL"); return; }
      pendingPhotoDataUrl = dataUrl;
      bigAvatar.textContent = "";
      bigAvatar.style.backgroundImage = "url('"+dataUrl+"')";
      bigAvatar.style.backgroundSize = "cover";
      bigAvatar.style.backgroundPosition = "center";
      pmsg.textContent = t("UI_PHOTO_READY_SAVE");
    });
  };

  var stats = el("div","display:grid;grid-template-columns:repeat(2,1fr);margin:10px 0 18px;border:1px solid #258874;border-radius:16px;background:rgba(0,0,0,.35);overflow:hidden");
  var winsBox = el("div","padding:12px 4px;text-align:center;color:#fff;border-right:1px solid #206c5d"), lossBox = el("div","padding:12px 4px;text-align:center;color:#fff");
  stats.appendChild(winsBox); stats.appendChild(lossBox); pcard.appendChild(stats);

  pcard.appendChild(el("div","font-size:14px;color:#f5d295;margin:0 0 7px",t("UI_USERNAME_LABEL")));
  var nameWrap=el("div","position:relative;margin-bottom:15px");
  var nameInput = el("input"); nameInput.type="text"; nameInput.maxLength=20; nameInput.placeholder=t("UI_YOUR_NAME");
  nameInput.style.cssText="width:100%;box-sizing:border-box;padding:13px 48px 13px 48px;border-radius:14px;border:2px solid #cc9f51;background:#080808;color:#fff;font-size:17px;font-family:Arial,sans-serif;outline:none";
  nameWrap.appendChild(nameInput);
  nameWrap.appendChild(el("div","position:absolute;left:15px;top:50%;transform:translateY(-50%);font-size:23px;color:#ecbc68","👤"));
  nameWrap.appendChild(el("div","position:absolute;right:15px;top:50%;transform:translateY(-50%);font-size:22px;color:#ecbc68","✎"));
  pcard.appendChild(nameWrap);

  pcard.appendChild(el("div","font-size:14px;color:#f5d295;margin:0 0 8px",t("UI_CHOOSE_AVATAR")));
  var avGrid = el("div","display:grid;grid-template-columns:repeat(6,1fr);gap:7px;margin-bottom:18px");
  var chosenAvatar=null, avCells=[];
  AVATARS.forEach(function(a){
    var c=el("button","aspect-ratio:1/1;font-size:27px;padding:3px;border-radius:12px;border:2px solid #257a69;background:linear-gradient(180deg,#16368e,#081230);cursor:pointer;box-shadow:inset 0 0 8px rgba(255,193,58,.06)",a);
    c.onclick=function(){ chosenAvatar=a; pendingPhotoDataUrl="__clear__"; bigAvatar.style.backgroundImage="none"; bigAvatar.textContent=a; avCells.forEach(function(x){x.style.borderColor="#257a69";x.style.boxShadow="inset 0 0 8px rgba(255,193,58,.06)";}); c.style.borderColor="#ffda9b"; c.style.boxShadow="0 0 13px rgba(255,205,62,.45)"; };
    avCells.push(c); avGrid.appendChild(c);
  });
  pcard.appendChild(avGrid);
  var pmsg = el("div","font-size:13px;color:#ffd894;text-align:center;min-height:16px;margin-bottom:8px","");
  var saveBtn = el("button","width:100%;border:2px solid #ffdfa8;background:linear-gradient(180deg,#ffdca0 0%,#edb659 55%,#cc983e 100%);color:#0f2561;border-radius:14px;padding:14px 0;font-size:20px;font-weight:800;font-family:Georgia,serif;cursor:pointer;box-shadow:0 7px 18px rgba(213,145,13,.18)",t("UI_SAVE"));
  var pback = el("button","width:100%;background:#080808;border:2px solid #bb9046;color:#f5cc85;border-radius:14px;padding:13px 0;font-size:18px;font-family:Georgia,serif;cursor:pointer;margin-top:10px",t("UI_BACK_BTN"));
  pcard.appendChild(pmsg); pcard.appendChild(saveBtn); pcard.appendChild(pback); pov.appendChild(pcard);

  function fillProfile(u){
    nameInput.value=nameOf(u); chosenAvatar=avatarOf(u);
    pendingPhotoDataUrl = null;
    paintAvatar(bigAvatar, u);
    winsBox.innerHTML="<div style='font-size:23px'>🏆</div><div style='font-size:19px;font-weight:700'>"+(u.wins||0)+"</div><div style='font-size:12px;color:#ccc'>"+t("UI_WINS")+"</div>";
    lossBox.innerHTML="<div style='font-size:23px'>❌</div><div style='font-size:19px;font-weight:700'>"+(u.losses||0)+"</div><div style='font-size:12px;color:#ccc'>"+t("UI_LOSSES")+"</div>";
    avCells.forEach(function(c){ var on=c.textContent===u.avatar; c.style.borderColor=on?"#ffda9b":"#257a69"; c.style.boxShadow=on?"0 0 13px rgba(255,205,62,.45)":"inset 0 0 8px rgba(255,193,58,.06)"; });
  }
  function openProfile(){
    pmsg.textContent="";
    if (window.DOMINO_USER) fillProfile(window.DOMINO_USER);
    pov.style.display="flex";
    if (window.DOMINO_TOKEN){
      fetch(SERVER+"/api/profile",{headers:{Authorization:"Bearer "+window.DOMINO_TOKEN}})
        .then(function(r){return r.ok?r.json():Promise.reject();})
        .then(function(d){ window.DOMINO_USER=d.user; fillProfile(d.user); renderUser(d.user); })
        .catch(function(){});
    }
  }
  function closeProfile(){ pov.style.display="none"; }
  pback.onclick=closeProfile;
  profileTile.onclick=openProfile;
  saveBtn.onclick=function(){
    var uname=(nameInput.value||"").trim();
    if(uname.length<2||uname.length>20){ pmsg.textContent=t("UI_NAME_LENGTH_ERROR"); return; }
    if(!window.DOMINO_TOKEN){ pmsg.textContent=t("UI_NOT_SIGNED_IN"); return; }
    saveBtn.disabled=true; pmsg.textContent=t("UI_SAVING");
    var body = {username:uname, avatar:chosenAvatar||""};
    if (pendingPhotoDataUrl === "__clear__") body.photo_url = "";
    else if (pendingPhotoDataUrl) body.photo_url = pendingPhotoDataUrl;
    fetch(SERVER+"/api/profile",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+window.DOMINO_TOKEN},body:JSON.stringify(body)})
      .then(function(r){return r.json().then(function(d){return {ok:r.ok,d:d};});})
      .then(function(res){ saveBtn.disabled=false; if(!res.ok){pmsg.textContent=res.d&&res.d.error==="photo_too_large"?t("UI_PHOTO_TOO_LARGE"):t("UI_COULD_NOT_SAVE");return;} window.DOMINO_USER=res.d.user; renderUser(res.d.user); pendingPhotoDataUrl=null; pmsg.textContent=t("UI_SAVED"); setTimeout(closeProfile,600); })
      .catch(function(){ saveBtn.disabled=false; pmsg.textContent=t("UI_NETWORK_ERROR"); });
  };

  /* ================= TOURNAMENT LEADERBOARD ================= */
  var lov = el("div","position:fixed;inset:0;z-index:100004;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.90);font-family:Arial,sans-serif;color:#fff;padding:14px;box-sizing:border-box");
  var lcard = el("div","position:relative;width:min(92vw,440px);max-height:92vh;overflow:auto;box-sizing:border-box;padding:0 0 20px;border:1px solid #236558;border-radius:24px;background:#091538;box-shadow:0 24px 70px rgba(0,0,0,.85),0 0 0 1px rgba(255,255,255,.02)");

  // ---- Hero header ----
  var lHero = el("div","position:relative;padding:30px 22px 24px;text-align:center;overflow:hidden;background:radial-gradient(circle at 50% -10%,rgba(63,217,114,.30) 0%,transparent 60%),linear-gradient(165deg,#153387 0%,#0d1f52 55%,#081230 100%);border-bottom:1px solid #236558");
  var lHeroPattern = el("div","position:absolute;inset:0;opacity:.06;background-image:repeating-linear-gradient(135deg,#fff 0,#fff 1px,transparent 1px,transparent 22px);pointer-events:none");
  lHero.appendChild(lHeroPattern);

  var lbadge = el("div","position:relative;width:64px;height:64px;margin:0 auto 12px;border-radius:18px;display:flex;align-items:center;justify-content:center;font-size:32px;background:linear-gradient(160deg,#e6cbff 0%,#b17ef0 55%,#7a3fc9 100%);box-shadow:0 8px 20px rgba(0,0,0,.4),inset 0 1px 0 rgba(255,255,255,.35);transform:rotate(-3deg)","🏆");
  lHero.appendChild(lbadge);

  lHero.appendChild(el("div","position:relative;font-size:21px;font-weight:900;color:#fffbf2;letter-spacing:.01em;margin-bottom:6px",t("UI_TOUR_TITLE")));
  var lPeriodTxt = el("div","position:relative;display:inline-block;font-size:11px;font-weight:700;color:#153387;background:#ddb268;border-radius:20px;padding:4px 14px;letter-spacing:.03em","—");
  lHero.appendChild(lPeriodTxt);

  var lCountdown = el("div","position:relative;margin-top:10px;font-family:Georgia,serif;font-size:15px;font-weight:800;color:#f8f0de;letter-spacing:.02em","—");
  lHero.appendChild(lCountdown);

  var lPrizeHero = el("div","position:relative;margin-top:18px");
  var lPrizeAmount = el("div","font-family:Georgia,serif;font-size:40px;font-weight:900;color:#34d399;line-height:1;text-shadow:0 2px 18px rgba(63,217,114,.35)","$—");
  var lPrizeCaption = el("div","font-size:12px;color:#baad8e;margin-top:6px",t("UI_TOUR_SHARE"));
  lPrizeHero.appendChild(lPrizeAmount); lPrizeHero.appendChild(lPrizeCaption);
  lHero.appendChild(lPrizeHero);

  lcard.appendChild(lHero);

  // ---- Body ----
  var lBody = el("div","padding:18px 20px 0");

  var lRuleTxt = el("div","font-size:11.5px;color:#a4997e;text-align:center;margin-bottom:16px;line-height:1.6;padding:0 4px",t("UI_TOUR_RULES"));
  lBody.appendChild(lRuleTxt);

  var lBreakHead = el("div","display:flex;align-items:center;gap:8px;margin-bottom:8px;padding:0 2px");
  lBreakHead.appendChild(el("div","font-size:12px;font-weight:800;color:#f7c46b;text-transform:uppercase;letter-spacing:.05em","🎁 "+t("UI_PRIZE_BREAKDOWN")));
  var lBreakHeadLine = el("div","flex:1;height:1px;background:#1e4ac3");
  lBreakHead.appendChild(lBreakHeadLine);
  lBody.appendChild(lBreakHead);

  var lBreakWrap = el("div","border:1px solid #183a9a;border-radius:16px;overflow:hidden;background:#0b1943;margin-bottom:18px");
  lBody.appendChild(lBreakWrap);

  function breakdownRow(rankLabel, amount, podiumIdx){
    var row = el("div","display:flex;align-items:center;justify-content:space-between;padding:9px 14px;border-bottom:1px solid #122a70");
    var left = el("div","font-size:13px;color:#eeeadf;font-weight:600;display:flex;align-items:center;gap:8px");
    if (podiumIdx != null) left.appendChild(el("span","font-size:15px",MEDALS[podiumIdx]));
    left.appendChild(document.createTextNode(rankLabel));
    var right = el("div","font-size:13px;font-weight:800;color:#34d399","$"+amount.toFixed(2));
    row.appendChild(left); row.appendChild(right);
    return row;
  }

  var lListHead = el("div","display:flex;align-items:center;gap:8px;margin-bottom:8px;padding:0 2px");
  lListHead.appendChild(el("div","font-size:12px;font-weight:800;color:#f7c46b;text-transform:uppercase;letter-spacing:.05em","🏆 "+t("UI_TOUR_TITLE")));
  var lListHeadLine = el("div","flex:1;height:1px;background:#1e4ac3");
  lListHead.appendChild(lListHeadLine);
  lBody.appendChild(lListHead);

  var lListWrap = el("div","border:1px solid #183a9a;border-radius:16px;overflow:hidden;background:#0b1943");
  lBody.appendChild(lListWrap);

  var lEmptyMsg = el("div","font-size:13px;color:#a4997e;text-align:center;padding:26px 10px;display:none",t("UI_TOUR_EMPTY"));
  lBody.appendChild(lEmptyMsg);

  var lback = el("button","width:100%;background:linear-gradient(180deg,#112769,#0b1943);border:1px solid #25554b;color:#e8d0a6;border-radius:14px;padding:13px 0;font-size:16px;font-weight:700;font-family:Arial,sans-serif;cursor:pointer;margin-top:18px","←  "+t("UI_BACK"));
  lBody.appendChild(lback);

  lcard.appendChild(lBody);
  lov.appendChild(lcard);

  var MEDALS = ["🥇","🥈","🥉"];
  var MEDAL_BG = ["linear-gradient(160deg,#ffeaab,#d8aa54)","linear-gradient(160deg,#e8e8e8,#9aa0a6)","linear-gradient(160deg,#e8a978,#a85f2e)"];
  function rankRow(rank, name, wins, isMe, prize){
    var isPodium = rank <= 3;
    var bg = isMe ? "linear-gradient(90deg,rgba(63,217,114,.16),rgba(63,217,114,.03))" : (rank % 2 === 0 ? "rgba(255,255,255,.015)" : "transparent");
    var row = el("div","display:flex;align-items:center;gap:12px;padding:11px 14px;border-bottom:1px solid #122a70;background:"+bg);

    var rankBadge;
    if (isPodium){
      rankBadge = el("div","width:30px;height:30px;flex:0 0 auto;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:15px;background:"+MEDAL_BG[rank-1]+";box-shadow:0 2px 6px rgba(0,0,0,.4)", MEDALS[rank-1]);
    } else {
      rankBadge = el("div","width:30px;height:30px;flex:0 0 auto;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#b09e7f;background:#122a70;border:1px solid #1e48bf", String(rank));
    }

    var nameWrap = el("div","flex:1;min-width:0");
    var nameEl = el("div","font-size:14.5px;font-weight:"+(isMe?"800":"600")+";color:"+(isMe?"#f8dbaa":"#eeeadf")+";white-space:nowrap;overflow:hidden;text-overflow:ellipsis", name + (isMe?t("UI_YOU_SUFFIX"):""));
    nameWrap.appendChild(nameEl);

    var winsEl = el("div","flex:0 0 auto;text-align:right");
    winsEl.appendChild(el("div","font-family:Georgia,serif;font-size:16px;font-weight:800;color:"+(isPodium?"#f2d898":"#f9cf86"), String(wins)));
    winsEl.appendChild(el("div","font-size:9px;color:#b09e7f;text-transform:uppercase;letter-spacing:.03em;text-align:right", t("UI_TOUR_WINS_SUFFIX")));

    row.appendChild(rankBadge); row.appendChild(nameWrap); row.appendChild(winsEl);
    return row;
  }

  // Mirrors the server's Monday-to-Monday ISO week bounds, so the countdown
  // matches exactly when the server will actually pay out and reset.
  function weekBoundsFromPeriod(periodStr){
    if (!periodStr || periodStr.indexOf("-W") === -1) return null;
    var parts = periodStr.split("-W");
    var y = Number(parts[0]), w = Number(parts[1]);
    var jan4 = new Date(Date.UTC(y, 0, 4));
    var jan4Day = (jan4.getUTCDay() + 6) % 7; // Monday=0
    var week1Monday = new Date(jan4.getTime() - jan4Day * 86400000);
    var start = new Date(week1Monday.getTime() + (w - 1) * 7 * 86400000);
    var end = new Date(start.getTime() + 7 * 86400000);
    return { start: start, end: end };
  }

  function weekEndFromPeriod(periodStr){
    var b = weekBoundsFromPeriod(periodStr);
    return b ? b.end : null;
  }

  // Shows the real calendar date range (Mon–Sun) instead of a raw "W34"
  // week number, so it reads naturally in any language.
  function weekLabel(period){
    var b = weekBoundsFromPeriod(period);
    if (!b) return "—";
    var months = t("MONTHS");
    var lastDay = new Date(b.end.getTime() - 86400000); // Sunday (end is exclusive)
    var startStr = b.start.getUTCDate() + " " + months[b.start.getUTCMonth()];
    if (b.start.getUTCFullYear() !== lastDay.getUTCFullYear()) {
      startStr += " " + b.start.getUTCFullYear();
    }
    var endStr = lastDay.getUTCDate() + " " + months[lastDay.getUTCMonth()] + " " + lastDay.getUTCFullYear();
    return startStr + " – " + endStr;
  }

  // Today's date, shown in the pill above the countdown — recalculated every
  // tick so it updates itself automatically if the day rolls over while the
  // tournament modal is left open.
  function todayLabel(){
    var months = t("MONTHS");
    var now = new Date();
    return now.getUTCDate() + " " + months[now.getUTCMonth()] + " " + now.getUTCFullYear();
  }

  var countdownTimer = null;
  var lastShownDay = null;
  function pad2(n){ return n < 10 ? "0"+n : String(n); }
  function startCountdown(periodStr){
    stopCountdown();
    var end = weekEndFromPeriod(periodStr);
    lastShownDay = null;
    function tick(){
      var todayKey = new Date().getUTCDate();
      if (todayKey !== lastShownDay){
        lastShownDay = todayKey;
        lPeriodTxt.textContent = todayLabel();
      }
      if (!end) { lCountdown.textContent = "—"; return; }
      var ms = end.getTime() - Date.now();
      if (ms <= 0){ lCountdown.textContent = t("UI_ENDED"); stopCountdown(); return; }
      var totalSec = Math.floor(ms / 1000);
      var days = Math.floor(totalSec / 86400);
      var hours = Math.floor((totalSec % 86400) / 3600);
      var mins = Math.floor((totalSec % 3600) / 60);
      var secs = totalSec % 60;
      var dayPart = days > 0 ? (days + t("UI_DAY_SHORT") + " ") : "";
      lCountdown.textContent = t("UI_RESETS_IN") + ": " + dayPart + pad2(hours) + ":" + pad2(mins) + ":" + pad2(secs);
    }
    tick();
    countdownTimer = setInterval(tick, 1000);
  }
  function stopCountdown(){
    if (countdownTimer){ clearInterval(countdownTimer); countdownTimer = null; }
  }

  function loadTournamentPreview(){
    fetch(SERVER + "/api/tournament/leaderboard?_="+Date.now(), {cache:"no-store"})
      .then(function(r){ return r.ok ? r.json() : null; })
      .then(function(d){
        if(!d) return;
        var pool = Number(d.total_pool||0).toFixed(2);
        var top = (d.leaderboard && d.leaderboard[0]) || null;
        if(top){
          var leaderName = top.fake ? top.display_name : (top.username || (top.email ? top.email.split("@")[0] : (t("UI_USER_PREFIX")+top.user_id)));
          tourSub.textContent = "🥇 " + leaderName + " — " + top.wins + " " + t("UI_TOUR_WINS_SUFFIX");
          tourFootLeft.textContent = "🥇 " + leaderName;
        } else {
          tourSub.textContent = t("UI_TOUR_TAKE_LEAD");
          tourFootLeft.textContent = "🥇 " + t("UI_TOUR_TITLE");
        }
        tourFootRight.textContent = t("UI_TOUR_SHARE") + " $" + pool;
      })
      .catch(function(){});
  }

  function openTournament(){
    lov.style.display="flex";
    lListWrap.innerHTML="";
    lBreakWrap.innerHTML="";
    lEmptyMsg.style.display="none";
    lPeriodTxt.textContent=t("UI_LOADING");
    fetch(SERVER + "/api/tournament/leaderboard?_="+Date.now(), {cache:"no-store"})
      .then(function(r){ return r.ok ? r.json() : Promise.reject(); })
      .then(function(d){
        startCountdown(d.period);
        var pool = Number(d.total_pool||0).toFixed(2);
        lPrizeAmount.textContent = "$"+pool;

        var tiers = d.tiers || [];
        tiers.forEach(function(tier){
          var rf = tier.rank_from, rt = tier.rank_to, amt = Number(tier.amount||0);
          var podiumIdx = (rf===rt && rf<=3) ? rf-1 : null;
          var label = (rf===rt) ? (t("UI_PRIZE_RANK")+" "+rf) : (t("UI_PRIZE_RANK")+" "+rf+"–"+rt+" ("+t("UI_PRIZE_EACH")+")");
          lBreakWrap.appendChild(breakdownRow(label, amt, podiumIdx));
        });

        var list = d.leaderboard || [];
        var myId = window.DOMINO_USER && window.DOMINO_USER.id;
        if(!list.length){ lEmptyMsg.style.display="block"; return; }
        list.forEach(function(row){
          var name = row.fake ? row.display_name : (row.username || (row.email ? row.email.split("@")[0] : (t("UI_USER_PREFIX")+row.user_id)));
          lListWrap.appendChild(rankRow(row.rank, name, row.wins, !row.fake && myId && row.user_id===myId, Number(row.prize_amount||0)));
        });
      })
      .catch(function(){ lPeriodTxt.textContent=t("UI_LEADERBOARD_ERROR"); });
  }
  function closeTournament(){ lov.style.display="none"; stopCountdown(); }
  tourCard.onclick = openTournament;
  lback.onclick = closeTournament;
  loadTournamentPreview();

  /* ================= LIVE ONLINE COUNT ================= */
  function loadOnlineCount(){
    fetch(SERVER + "/api/online-count")
      .then(function(r){ return r.ok ? r.json() : null; })
      .then(function(d){
        if (d && d.online != null) onlineCountNum.textContent = String(d.online);
      })
      .catch(function(){});
  }
  loadOnlineCount();
  setInterval(loadOnlineCount, 25000);

  // Safety net for the in-game HUD avatar: re-fetch the freshest profile
  // right as a match starts and push the photo into the canvas avatar,
  // in case window.DOMINO_USER.photo_url wasn't populated yet the moment
  // the match's HUD was first built.
  function refreshInGameAvatarSoon(){
    // Opponent avatar: their photo already arrived with the 'matched'
    // payload, but the HUD may have been built before we stored it (the VS
    // intro runs in between), so push it in as soon as the board exists.
    (function(){
      var oppTries = 0;
      var oppIv = setInterval(function(){
        oppTries++;
        if (typeof s_oGame !== "undefined" && s_oGame && s_oGame.refreshOpponentAvatar) {
          s_oGame.refreshOpponentAvatar(
            window.DOMINO_P1_PHOTO || null,
            window.DOMINO_P1_AVATAR || null
          );
          clearInterval(oppIv);
        } else if (oppTries > 20) {
          clearInterval(oppIv);
        }
      }, 200);
    })();

    if (!window.DOMINO_TOKEN) return;
    fetch(SERVER + "/api/me", { headers: { Authorization: "Bearer " + window.DOMINO_TOKEN } })
      .then(function(r){ return r.ok ? r.json() : null; })
      .then(function(d){
        if (!d || !d.user) return;
        window.DOMINO_USER = d.user;
        var tries = 0;
        var iv = setInterval(function(){
          tries++;
          if (typeof s_oGame !== "undefined" && s_oGame && s_oGame.refreshMyAvatar) {
            s_oGame.refreshMyAvatar(d.user.photo_url || null, d.user.avatar || null);
            clearInterval(iv);
          } else if (tries > 20) {
            clearInterval(iv);
          }
        }, 200);
      })
      .catch(function(){});
  }

  /* ================= PAID FEATURES KILL-SWITCH ================= */
  var paidOffBanner = el("div","display:none;margin-top:12px;padding:10px 14px;border-radius:12px;border:1px solid #258874;background:rgba(20,40,25,.55);color:#ffe5b6;font-size:13px;text-align:center;font-family:Arial,sans-serif",t("UI_PAID_OFF_BANNER"));
  walletTopRow.parentNode.insertBefore(paidOffBanner, walletTopRow.nextSibling);

  function applyPaidEnabled(enabled, scheduleInfo){
    window.PAID_ENABLED = !!enabled;
    topDepositBtn.style.display = enabled ? "" : "none";
    walletTopRow.style.gridTemplateColumns = enabled ? "1fr 1fr" : "1fr";
    paidOffBanner.style.display = enabled ? "none" : "block";
    if (!enabled) {
      // If an admin schedule is driving the closure (rather than the
      // manual kill-switch), tell players exactly when it reopens instead
      // of a generic "temporarily disabled" message they can't act on.
      if (scheduleInfo && scheduleInfo.paid_schedule_enabled) {
        paidOffBanner.textContent = t("UI_PAID_OFF_SCHEDULE_BANNER")
          .replace("{open}", scheduleInfo.paid_open_time || "")
          .replace("{close}", scheduleInfo.paid_close_time || "");
      } else {
        paidOffBanner.textContent = t("UI_PAID_OFF_BANNER");
      }
    }
    goalBtnMeta.forEach(function(m){
      if (!m.free){ m.btn.style.display = enabled ? "" : "none"; }
    });
  }
  applyPaidEnabled(true); // safe default while loading
  function refreshPaidEnabled(){
    fetch(SERVER + "/api/app-config")
      .then(function(r){ return r.ok ? r.json() : null; })
      .then(function(d){ if (d) { applyPaidEnabled(d.paid_live_now !== false, d); window.YD_BOT_ENABLED=!!d.bot_enabled; window.YD_BOT_DIFFICULTY=(d.bot_difficulty||'hard'); } })
      .catch(function(){});
  }
  refreshPaidEnabled();
  // Re-check periodically so a player sitting in the lobby right when a
  // scheduled open/close time hits sees the change live, instead of only
  // finding out on their next page load.
  setInterval(refreshPaidEnabled, 60000);

  /* ================= MATCH RESULT (WIN / LOSE) ================= */
  var rov = el("div","position:fixed;inset:0;z-index:100005;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.92);font-family:Arial,sans-serif;color:#fff;padding:16px;box-sizing:border-box");
  var rcard = el("div","position:relative;width:min(92vw,460px);max-height:92vh;overflow:auto;box-sizing:border-box;padding:62px 20px 22px;border-radius:28px;box-shadow:0 26px 80px rgba(0,0,0,.88),inset 0 0 26px rgba(255,191,48,.05)");

  var rCrownWrap = el("div","position:absolute;left:50%;top:-46px;transform:translateX(-50%);width:100px;height:100px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:52px");
  rcard.appendChild(rCrownWrap);

  var rBanner = el("div","font-family:Georgia,serif;font-size:34px;font-weight:900;text-align:center;margin:4px 0 18px;letter-spacing:.5px");
  rcard.appendChild(rBanner);

  var rRankWrap = el("div","display:flex;flex-direction:column;gap:10px;margin-bottom:22px");
  rcard.appendChild(rRankWrap);

  var rPrizeBox = el("div","display:none;align-items:center;justify-content:center;gap:10px;padding:13px 16px;border-radius:14px;border:1px solid #227a68;background:linear-gradient(180deg,#11296c,#091538);margin-bottom:20px;box-shadow:inset 0 1px 0 rgba(255,225,140,.12)");
  rcard.appendChild(rPrizeBox);

  var rBtnRow = el("div","display:flex;gap:12px");
  var rBackBtn = el("button","flex:1;background:#0c0c0c;border:2px solid #5c6a63;color:#e9e1ce;border-radius:14px;padding:14px 0;font-size:17px;font-weight:800;font-family:Georgia,serif;cursor:pointer",t("UI_BACK"));
  var rAgainBtn = el("button","flex:1;background:linear-gradient(180deg,#e6cbff,#b17ef0);border:2px solid #f0e0ff;color:#22093f;border-radius:14px;padding:14px 0;font-size:17px;font-weight:900;font-family:Georgia,serif;cursor:pointer;box-shadow:0 6px 16px rgba(122,63,201,.35)",t("UI_PLAY_AGAIN"));
  rBtnRow.appendChild(rBackBtn); rBtnRow.appendChild(rAgainBtn);
  rcard.appendChild(rBtnRow);
  rov.appendChild(rcard);

  function rankRowResult(rank, name, avatar, score, isYou, isWinner, photoUrl){
    var bg = isWinner
      ? "linear-gradient(90deg,rgba(240,194,63,.28),rgba(240,194,63,.08))"
      : "rgba(255,255,255,.04)";
    var border = isWinner ? "1px solid #ddae5c" : "1px solid #193da1";
    var row = el("div","display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:14px;background:"+bg+";border:"+border);
    var rankEl = el("div","width:32px;flex:0 0 auto;text-align:center;font-size:20px","" + (rank===1 ? "🥇" : "🥈"));
    var avEl = el("div","width:42px;height:42px;flex:0 0 auto;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;background:#141010;border:2px solid "+(isWinner?"#f4c97f":"#3a3a3a")+";overflow:hidden;background-size:cover;background-position:center");
    if (photoUrl){ avEl.style.backgroundImage = "url('"+photoUrl+"')"; } else { avEl.textContent = avatar||"🙂"; }
    var nameWrap = el("div","flex:1;min-width:0");
    var nameEl = el("div","font-size:15px;font-weight:"+(isYou?"800":"600")+";color:"+(isWinner?"#fad594":"#e8e8e8")+";white-space:nowrap;overflow:hidden;text-overflow:ellipsis", name + (isYou?t("UI_YOU_SUFFIX"):""));
    nameWrap.appendChild(nameEl);
    var scoreEl = el("div","flex:0 0 auto;font-size:16px;font-weight:900;color:#f4c97f", String(score));
    row.appendChild(rankEl); row.appendChild(avEl); row.appendChild(nameWrap); row.appendChild(scoreEl);
    return row;
  }

  window.dominoShowMatchResult = function(result){
    var won = !!result.youWin;
    var me = window.DOMINO_USER || {};
    var myName = nameOf(me), myAv = avatarOf(me), myPhoto = me.photo_url || null;
    var oppName = window.DOMINO_P1_NAME || t("UI_OPPONENT");
    var oppAv = (window.DOMINO_OPP && window.DOMINO_OPP.avatar) || "🧑";

    rcard.style.border = won ? "2px solid #e8b55e" : "2px solid #5c5c5c";
    rcard.style.background = won
      ? "radial-gradient(circle at 50% 0%,rgba(170,105,15,.28),transparent 32%),linear-gradient(180deg,#0f2561 0%,#081230 100%)"
      : "radial-gradient(circle at 50% 0%,rgba(90,90,90,.18),transparent 32%),linear-gradient(180deg,#141414 0%,#070707 100%)";
    rCrownWrap.style.background = won
      ? "radial-gradient(circle,#165649 0%,#0f2561 65%,#050505 100%)"
      : "radial-gradient(circle,#2c2c2c 0%,#161616 65%,#050505 100%)";
    rCrownWrap.style.border = won ? "4px solid #f5c778" : "4px solid #7a7a7a";
    rCrownWrap.style.boxShadow = won
      ? "0 0 0 6px rgba(37,23,6,.92),0 0 26px rgba(238,190,67,.45)"
      : "0 0 0 6px rgba(20,20,20,.92)";
    rCrownWrap.textContent = won ? "👑" : "🙁";
    rBanner.textContent = won ? t("UI_YOU_WIN") : t("UI_YOU_LOSE");
    rBanner.style.color = won ? "#fad594" : "#c9c9c9";
    rBanner.style.textShadow = won ? "0 2px 14px rgba(255,190,42,.30)" : "none";

    rRankWrap.innerHTML = "";
    if (won){
      rRankWrap.appendChild(rankRowResult(1, myName, myAv, result.yourScore, true, true, myPhoto));
      rRankWrap.appendChild(rankRowResult(2, oppName, oppAv, result.oppScore, false, false));
    } else {
      rRankWrap.appendChild(rankRowResult(1, oppName, oppAv, result.oppScore, false, true));
      rRankWrap.appendChild(rankRowResult(2, myName, myAv, result.yourScore, true, false, myPhoto));
    }

    if (won && myStake > 0){
      rPrizeBox.style.display = "flex";
      rPrizeBox.innerHTML = '<span style="font-size:24px">🎁</span><span style="font-size:15px;color:#f1eee8">'+t("UI_YOU_WON")+' <b style="color:#34d399;font-size:17px">'+Number(myPrize||0).toFixed(2)+' USDT</b></span>';
    } else {
      rPrizeBox.style.display = "none";
    }

    rBackBtn.onclick = function(){ rov.style.display="none"; if (result.onExit) result.onExit(); };
    rAgainBtn.onclick = function(){
      rov.style.display="none";
      if (window.s_oOnlineDeal && window.DOMINO_OPP){
        // This was a real match against a human opponent; that room is
        // already closed server-side, so find a fresh opponent instead of
        // trying to resume the finished game.
        if (result.onExit) result.onExit();
        openGoal();
      } else if (result.onPlayAgain) {
        // vs Computer: just start a new local round right away.
        result.onPlayAgain();
      }
    };

    rov.style.display = "flex";
  };


  /* ================= USDT WALLET =================
   * Front-end wallet screen. Real funds MUST be handled by the server.
   * Expected authenticated endpoints:
   *   GET  /api/wallet
   *   POST /api/nowpayments/deposit  {amount, network}
   *   GET  /api/nowpayments/payment/:id
   *   POST /api/nowpayments/withdraw {address, amount, network}
   * NOWPayments handles payment addresses and blockchain confirmation.
   */
  var wlov = el("div","position:fixed;inset:0;z-index:100003;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.88);font-family:Arial,sans-serif;color:#f5f5f5;padding:16px;overflow:auto");
  var wlcard = el("div","position:relative;background:linear-gradient(155deg,#0f2561 0%,#050505 58%,#0c1c4a 100%);border:2px solid #dbab57;border-radius:30px;padding:132px 20px 22px;max-width:430px;width:94%;max-height:92vh;overflow:auto;box-shadow:0 0 32px rgba(215,157,39,.18),inset 0 0 35px rgba(255,190,55,.04)");
  var wlIcon = el("div","position:absolute;left:50%;top:22px;transform:translate(-50%,0);width:92px;height:92px;border-radius:50%;border:4px solid #e6b767;background:radial-gradient(circle at 40% 35%,#caa159,#168a73 70%);box-shadow:0 0 0 10px #090909,0 0 0 13px #cb9d4d,0 0 24px rgba(255,193,54,.55);display:flex;align-items:center;justify-content:center;font:bold 50px Arial;color:white","₮");
  wlcard.appendChild(wlIcon);
  wlcard.appendChild(el("div","font-size:30px;font-weight:800;color:#f7d395;text-align:center;margin-bottom:7px;font-family:Georgia,serif;text-shadow:0 2px 10px rgba(255,184,40,.2)",t("UI_WALLET_TITLE")));
  wlcard.appendChild(el("div","font-size:14px;color:#ddd;text-align:center;margin-bottom:18px",t("UI_WALLET_SUB")));

  var wlBalance = el("div","text-align:left;background:linear-gradient(135deg,#0f235d,#070707);border:1.5px solid #c1954a;border-radius:20px;padding:18px 20px;margin-bottom:14px;box-shadow:inset 0 0 22px rgba(221,157,32,.06)");
  wlBalance.appendChild(el("div","font-size:13px;color:#e8cb98;margin-bottom:5px",t("UI_AVAILABLE_BALANCE")));
  var wlBalTxt = el("div","font-size:34px;font-weight:800;color:#34d399;margin-top:3px","0.00 USDT");
  wlBalance.appendChild(wlBalTxt);
  wlcard.appendChild(wlBalance);

  var wlTabs = el("div","display:flex;gap:8px;margin-bottom:14px");
  var wlDepTab = el("button","flex:1;background:linear-gradient(180deg,#e6cbff,#b17ef0);border:1px solid #e6cbff;color:#22093f;border-radius:14px;padding:13px;font-family:Arial,sans-serif;font-size:16px;font-weight:800;cursor:pointer",t("UI_DEPOSIT").replace(/^⇩\s*/,""));
  var wlWdTab = el("button","flex:1;background:#090909;border:1.5px solid #ba9046;color:#f4d193;border-radius:14px;padding:13px;font-family:Arial,sans-serif;font-size:16px;font-weight:800;cursor:pointer",t("UI_WITHDRAW").replace(/^⇧\s*/,""));
  wlTabs.appendChild(wlDepTab); wlTabs.appendChild(wlWdTab); wlcard.appendChild(wlTabs);

  var wlDep = el("div");
  wlDep.appendChild(el("div","font-size:13px;opacity:.8;margin-bottom:6px",t("UI_NETWORK")));
  var wlDepNetwork = el("select","width:100%;box-sizing:border-box;margin-bottom:14px;padding:14px;border-radius:14px;border:1.5px solid #ba9046;background:#090909;color:#f4f4f4;font-size:16px;font-family:Arial,sans-serif");
  ["BEP20","ERC20"].forEach(function(n){ var o=document.createElement("option"); o.value=n; o.textContent="USDT • "+n; wlDepNetwork.appendChild(o); });
  wlDep.appendChild(wlDepNetwork);

  wlDep.appendChild(el("div","font-size:13px;opacity:.8;margin-bottom:6px",t("UI_AMOUNT")));
  wlDep.appendChild(el("div","font-size:13px;color:#ffe5b6;margin-bottom:6px",t("UI_MIN_DEPOSIT")));
  var wlDepAmount = el("input","width:100%;box-sizing:border-box;margin-bottom:12px;padding:14px;border-radius:14px;border:1.5px solid #ba9046;background:#090909;color:#f4f4f4;font-size:16px;font-family:Arial,sans-serif");
  wlDepAmount.type="number"; wlDepAmount.min="1"; wlDepAmount.step="0.01"; wlDepAmount.placeholder=t("UI_AMOUNT_LABEL");
  wlDep.appendChild(wlDepAmount);

  var wlCreateDep = el("button","width:100%;background:linear-gradient(180deg,#e6cbff,#b17ef0);border:1px solid #f0e0ff;color:#22093f;border-radius:15px;padding:15px;font-size:18px;font-weight:800;font-family:Arial,sans-serif;cursor:pointer;margin-bottom:12px;box-shadow:0 7px 18px rgba(122,63,201,.25)",t("UI_CREATE_PAYMENT"));
  wlDep.appendChild(wlCreateDep);

  var wlAddressBox = el("div","display:none;background:#1a3ea5;border:2px solid #cdaa6d;border-radius:12px;padding:12px;margin-bottom:10px;word-break:break-all");
  var wlAddressLabel = el("div","font-size:12px;opacity:.7;margin-bottom:5px",t("UI_DEPOSIT_ADDR_LABEL"));
  var wlAddress = el("div","font-size:13px;color:#ffe5b6","");
  var wlQrWrap = el("div","display:none;justify-content:center;padding:12px 0 4px");
  var wlQr = document.createElement("img");
  wlQr.style.cssText = "width:180px;height:180px;border-radius:10px;background:#fff;padding:8px";
  wlQr.alt = t("UI_PAYMENT_QR_ALT");
  wlQrWrap.appendChild(wlQr);
  var wlPayAmount = el("div","font-size:28px;font-weight:800;color:#ffe5b8;margin-top:9px;text-align:center","");
  var wlPayStatus = el("div","font-size:12px;opacity:.75;margin-top:7px","");
  wlAddressBox.appendChild(wlAddressLabel); wlAddressBox.appendChild(wlAddress); wlAddressBox.appendChild(wlQrWrap); wlAddressBox.appendChild(wlPayAmount); wlAddressBox.appendChild(wlPayStatus);
  wlDep.appendChild(wlAddressBox);

  var copyAddr = el("button","display:none;width:100%;background:transparent;border:2px solid #ddb268;color:#f8deb3;border-radius:10px;padding:10px;font-family:Georgia,serif;cursor:pointer;margin-bottom:10px",t("UI_COPY_ADDRESS"));
  wlDep.appendChild(copyAddr);

  var wlCheckDep = el("button","display:none;width:100%;background:transparent;border:2px solid #ddb268;color:#f8deb3;border-radius:10px;padding:10px;font-family:Georgia,serif;cursor:pointer;margin-bottom:4px",t("UI_CHECK_PAYMENT"));
  wlDep.appendChild(wlCheckDep);

  var wlWd = el("div"); wlWd.style.display="none";
  wlWd.appendChild(el("div","font-size:13px;opacity:.8;margin-bottom:6px",t("UI_NETWORK")));
  var wlWdNetwork = wlDepNetwork.cloneNode(true);
  wlWd.appendChild(wlWdNetwork);
  wlWd.appendChild(el("div","font-size:13px;opacity:.8;margin:6px 0",t("UI_DEPOSIT_ADDRESS")));
  var wlWdAddr = el("input","width:100%;box-sizing:border-box;margin-bottom:10px;padding:12px;border-radius:10px;border:2px solid #cdaa6d;background:#1a3ea5;color:#fff5df;font-size:14px;font-family:Georgia,serif");
  wlWdAddr.placeholder=t("UI_DEPOSIT_ADDRESS");
  wlWd.appendChild(wlWdAddr);
  wlWd.appendChild(el("div","font-size:13px;opacity:.8;margin:6px 0",t("UI_AMOUNT")));
  var wlWdAmount = el("input","width:100%;box-sizing:border-box;margin-bottom:12px;padding:14px;border-radius:14px;border:1.5px solid #ba9046;background:#090909;color:#f4f4f4;font-size:16px;font-family:Arial,sans-serif");
  wlWdAmount.type="number"; wlWdAmount.min="0"; wlWdAmount.step="0.01"; wlWdAmount.placeholder="0.00";
  wlWd.appendChild(wlWdAmount);
  var wlWdMinHint = el("div","font-size:12px;opacity:.65;margin-bottom:6px","");
  wlWd.appendChild(wlWdMinHint);
  var wlFee = el("div","font-size:12px;opacity:.65;margin-bottom:10px",t("UI_NETWORK_FEE"));
  wlWd.appendChild(wlFee);
  var wlConfirmWd = el("button","width:100%;"+GOLD+"border-radius:11px;padding:12px;font-size:16px;font-weight:bold;font-family:Georgia,serif;cursor:pointer",t("UI_REQUEST_WITHDRAWAL"));
  wlWd.appendChild(wlConfirmWd);

  var wlMsg = el("div","font-size:13px;color:#ffe4b8;text-align:center;min-height:18px;margin:12px 0 4px","");
  var wlBack = el("button","width:100%;background:#080808;border:1.5px solid #ba9046;color:#f2cd8c;border-radius:15px;padding:13px;font-size:16px;font-weight:700;font-family:Arial,sans-serif;cursor:pointer;margin-top:8px",t("UI_BACK"));
  wlcard.appendChild(wlDep); wlcard.appendChild(wlWd); wlcard.appendChild(wlMsg); wlcard.appendChild(wlBack);
  wlov.appendChild(wlcard);

  function walletHeaders(){
    return { "Content-Type":"application/json", Authorization:"Bearer "+(window.DOMINO_TOKEN||"") };
  }
  function setWalletMsg(t){ wlMsg.textContent=t||""; }
  var currentMinWithdraw = null;
  function renderWallet(data){
    if(!data) return;
    var bal = data.balance != null ? data.balance : (data.usdt_balance != null ? data.usdt_balance : 0);
    wlBalTxt.textContent = Number(bal||0).toFixed(2) + " USDT";
    topBalanceTxt.textContent = Number(bal||0).toFixed(2) + " USDT";
    if (data.min_withdraw != null) {
      currentMinWithdraw = Number(data.min_withdraw);
      wlWdMinHint.textContent = t("UI_MIN_WITHDRAW_HINT").replace("{min}", currentMinWithdraw.toFixed(2));
    }
    // NOWPayments creates a fresh payment address for each deposit.
    // No static deposit address is expected from /api/wallet.
  }
  function loadWallet(){
    if(!window.DOMINO_TOKEN){ setWalletMsg(t("UI_PLEASE_SIGN_IN_DOT")); return; }
    setWalletMsg(t("UI_LOADING_WALLET"));
    fetch(SERVER+"/api/wallet",{headers:walletHeaders()})
      .then(function(r){ return r.json().then(function(x){return {ok:r.ok,d:x};}); })
      .then(function(res){
        if(!res.ok){ setWalletMsg(t("UI_WALLET_NOT_CONNECTED")); return; }
        renderWallet(res.d); setWalletMsg("");
      }).catch(function(){ setWalletMsg(t("UI_WALLET_NOT_CONNECTED")); });
  }
  function openWallet(){ wlov.style.display="flex"; setWalletMsg(""); loadWallet(); }
  function closeWallet(){ wlov.style.display="none"; }
  function showDep(){ wlDep.style.display="block"; wlWd.style.display="none"; wlDepTab.style.cssText=GOLD+"flex:1;border-radius:11px;padding:10px;font-family:Georgia,serif;font-weight:bold;cursor:pointer"; wlWdTab.style.cssText="flex:1;background:#090909;border:1.5px solid #ba9046;color:#f4d193;border-radius:14px;padding:13px;font-family:Arial,sans-serif;font-size:16px;font-weight:800;cursor:pointer"; }
  function showWd(){ wlDep.style.display="none"; wlWd.style.display="block"; wlWdTab.style.cssText=GOLD+"flex:1;border-radius:11px;padding:10px;font-family:Georgia,serif;font-weight:bold;cursor:pointer"; wlDepTab.style.cssText="flex:1;background:#090909;border:1.5px solid #ba9046;color:#f4d193;border-radius:14px;padding:13px;font-family:Arial,sans-serif;font-size:16px;font-weight:800;cursor:pointer"; }
  topDepositBtn.onclick=function(){ openWallet(); showDep(); };
  topWithdrawBtn.onclick=function(){ openWallet(); showWd(); };
  topBalance.onclick=openWallet;
  wlBack.onclick=closeWallet; wlDepTab.onclick=showDep; wlWdTab.onclick=showWd;
  var currentNowPaymentId = null;
  var depositPollTimer = null;

  function clearDepositPayment(){
    currentNowPaymentId = null;
    wlAddress.dataset.address = "";
    wlAddress.textContent = "";
    wlPayAmount.textContent = "";
    wlPayStatus.textContent = "";
    wlAddressBox.style.display = "none";
    wlQr.src = "";
    wlQrWrap.style.display = "none";
    copyAddr.style.display = "none";
    wlCheckDep.style.display = "none";
    if(depositPollTimer){ clearInterval(depositPollTimer); depositPollTimer = null; }
  }

  wlDepNetwork.onchange=function(){ clearDepositPayment(); };
  copyAddr.onclick=function(){
    var a=wlAddress.dataset.address||"";
    if(!a){ setWalletMsg(t("UI_CREATE_PAYMENT_FIRST")); return; }
    if(navigator.clipboard) navigator.clipboard.writeText(a).then(function(){setWalletMsg(t("UI_ADDRESS_COPIED"));});
    else setWalletMsg(t("UI_COPY_NOT_SUPPORTED"));
  };

  function checkNowPaymentStatus(silent){
    if(!currentNowPaymentId || !window.DOMINO_TOKEN) return;
    fetch(SERVER+"/api/nowpayments/payment/"+encodeURIComponent(currentNowPaymentId),{headers:walletHeaders()})
      .then(function(r){return r.json().then(function(x){return {ok:r.ok,d:x};});})
      .then(function(res){
        if(!res.ok){ if(!silent) setWalletMsg(t("UI_CHECK_PAYMENT_FAIL")); return; }
        var p=res.d&&res.d.payment?res.d.payment:{};
        var st=String(p.payment_status||"").toLowerCase();
        wlPayStatus.textContent = st ? (t("UI_STATUS_LABEL")+st) : t("UI_WAITING_PAYMENT");
        if(st==="finished"){
          if(depositPollTimer){ clearInterval(depositPollTimer); depositPollTimer=null; }
          setWalletMsg(t("UI_PAYMENT_CONFIRMED"));
          loadWallet();
        } else if(st==="failed" || st==="expired" || st==="refunded"){
          if(depositPollTimer){ clearInterval(depositPollTimer); depositPollTimer=null; }
          setWalletMsg(t("UI_PAYMENT_LABEL")+st+".");
        } else if(!silent){
          setWalletMsg(t("UI_PAYMENT_STATUS_LABEL")+(st||"waiting"));
        }
      })
      .catch(function(){ if(!silent) setWalletMsg(t("UI_NETWORK_ERROR_DOT")); });
  }

  wlCheckDep.onclick=function(){ checkNowPaymentStatus(false); };

  wlCreateDep.onclick=function(){
    var amount=Number(wlDepAmount.value), network=wlDepNetwork.value;
    if(!amount || amount<=0){setWalletMsg(t("UI_ENTER_VALID_DEPOSIT"));return;}
    if(!window.DOMINO_TOKEN){setWalletMsg(t("UI_PLEASE_SIGN_IN_DOT"));return;}
    wlCreateDep.disabled=true; setWalletMsg(t("UI_CREATING_PAYMENT"));
    clearDepositPayment();
    fetch(SERVER+"/api/nowpayments/deposit",{method:"POST",headers:walletHeaders(),body:JSON.stringify({amount:amount,network:network})})
      .then(function(r){return r.json().then(function(x){return {ok:r.ok,d:x};});})
      .then(function(res){
        wlCreateDep.disabled=false;
        if(!res.ok){
          var errMsg;
          if(res.d && res.d.error === "insufficient_balance"){
            errMsg = t("UI_NOT_ENOUGH_USDT");
          } else if(res.d && typeof res.d.min !== "undefined" && /^minimum_deposit_for_network_is_/.test(res.d.error||"")){
            errMsg = t("UI_MIN_DEPOSIT_ERROR_PREFIX") + res.d.min + t("UI_MIN_DEPOSIT_ERROR_SUFFIX");
          } else {
            errMsg = t("UI_COULD_NOT_CREATE_PAYMENT");
          }
          setWalletMsg(errMsg);
          return;
        }
        var d=res.d||{};
        currentNowPaymentId=d.payment_id||null;
        wlAddress.dataset.address=d.pay_address||"";
        wlAddress.textContent=d.pay_address||t("UI_NO_ADDRESS");
        var wlPayAmountNum=(d.pay_amount!=null?Number(d.pay_amount).toFixed(6):amount);
        wlPayAmount.innerHTML="";
        var wlPayAmountNumEl=document.createElement("span");
        wlPayAmountNumEl.style.color="#3ddc84";
        wlPayAmountNumEl.textContent=wlPayAmountNum;
        wlPayAmount.appendChild(wlPayAmountNumEl);
        wlPayAmount.appendChild(document.createTextNode(" "+formatPayCurrency(d.pay_currency)));
        wlPayStatus.textContent=t("UI_STATUS_LABEL")+(d.status||"waiting");
        wlAddressBox.style.display="block";
        if(d.pay_address){
          wlQr.src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data="+encodeURIComponent(d.pay_address);
          wlQrWrap.style.display="flex";
        } else {
          wlQr.src="";
          wlQrWrap.style.display="none";
        }
        copyAddr.style.display=d.pay_address?"block":"none";
        wlCheckDep.style.display=currentNowPaymentId?"block":"none";
        setWalletMsg(t("UI_SEND_EXACT_AMOUNT"));
        if(currentNowPaymentId){
          depositPollTimer=setInterval(function(){checkNowPaymentStatus(true);},10000);
        }
      })
      .catch(function(){wlCreateDep.disabled=false;setWalletMsg(t("UI_NETWORK_ERROR_DOT"));});
  };
  wlConfirmWd.onclick=function(){
    var address=(wlWdAddr.value||"").trim(), amount=Number(wlWdAmount.value), network=wlWdNetwork.value;
    if(!address){setWalletMsg(t("UI_ENTER_USDT_ADDRESS"));return;}
    if(!amount || amount<=0){setWalletMsg(t("UI_ENTER_VALID_AMOUNT"));return;}
    if(!window.DOMINO_TOKEN){setWalletMsg(t("UI_PLEASE_SIGN_IN_DOT"));return;}
    if(!/^0x[a-fA-F0-9]{40}$/.test(address) && network!=="TRC20"){setWalletMsg(t("UI_ENTER_VALID_PREFIX")+network+t("UI_ADDRESS_SUFFIX"));return;}
    if(network==="TRC20" && !/^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(address)){setWalletMsg(t("UI_ENTER_VALID_TRC20"));return;}
    wlConfirmWd.disabled=true; setWalletMsg(t("UI_SUBMITTING_WITHDRAWAL"));
    fetch(SERVER+"/api/nowpayments/withdraw",{method:"POST",headers:walletHeaders(),body:JSON.stringify({address:address,amount:amount,network:network})})
      .then(function(r){return r.json().then(function(x){return {ok:r.ok,d:x};});})
      .then(function(res){wlConfirmWd.disabled=false;if(!res.ok){
        if(res.d && res.d.error==="insufficient_balance"){ setWalletMsg(t("UI_NOT_ENOUGH_USDT")); return; }
        if(res.d && res.d.error==="invalid_amount"){
          var mn = res.d.min!=null ? Number(res.d.min) : currentMinWithdraw;
          setWalletMsg(mn!=null ? t("UI_WITHDRAW_BELOW_MIN").replace("{min}", mn.toFixed(2)) : t("UI_WITHDRAWAL_FAILED"));
          return;
        }
        setWalletMsg(t("UI_WITHDRAWAL_FAILED"));return;}wlWdAddr.value="";wlWdAmount.value="";setWalletMsg(t("UI_WITHDRAWAL_SUBMITTED"));loadWallet();})
      .catch(function(){wlConfirmWd.disabled=false;setWalletMsg(t("UI_NETWORK_ERROR_DOT"));});
  };

  /* ================= SETTINGS (simple) ================= */
  var sov = el("div","position:fixed;inset:0;z-index:100001;display:none;align-items:center;justify-content:center;background:rgba(20,10,4,.92);font-family:Georgia,serif;color:#f8deb3;padding:18px;box-sizing:border-box");
  var scard = el("div",PANEL+"padding:22px 20px;max-width:360px;width:92%;max-height:88vh;overflow:auto;text-align:center;box-sizing:border-box");
  scard.appendChild(el("div","font-size:22px;color:#ffe5b6;margin-bottom:14px",t("UI_SETTINGS")));
  var accLine = el("div","font-size:13px;opacity:.85;margin-bottom:18px;word-break:break-all","");
  scard.appendChild(accLine);

  function settingsSectionLabel(txt){ return el("div","font-size:12px;color:#cdaa6d;text-align:left;margin:16px 0 8px;text-transform:uppercase;letter-spacing:.04em",txt); }

  // ---- Language switcher ----
  scard.appendChild(settingsSectionLabel(t("UI_LANGUAGE")));
  var langRow = el("div","display:flex;gap:8px;margin-bottom:6px");
  var langBtns = [];
  (window.YALLA_I18N ? window.YALLA_I18N.languages : [{code:"ku",label:"کوردی"},{code:"en",label:"English"},{code:"ar",label:"العربية"}]).forEach(function(lang){
    var lb = el("button","flex:1;border-radius:12px;padding:11px 4px;font-size:14px;font-weight:800;font-family:Arial,sans-serif;cursor:pointer;border:1px solid #258874;background:rgba(0,0,0,.28);color:#ffe5b6",lang.label);
    lb.onclick = function(){
      if (window.YALLA_I18N) window.YALLA_I18N.setLang(lang.code);
      location.reload();
    };
    langBtns.push({btn:lb, code:lang.code});
    langRow.appendChild(lb);
  });
  scard.appendChild(langRow);
  (function paintLangButtons(){
    var current = window.YALLA_I18N ? window.YALLA_I18N.getLang() : "ku";
    langBtns.forEach(function(m){
      var on = m.code === current;
      m.btn.style.background = on ? "linear-gradient(180deg,#e6cbff,#b17ef0)" : "rgba(0,0,0,.28)";
      m.btn.style.color = on ? "#22093f" : "#ffe5b6";
      m.btn.style.borderColor = on ? "#e6cbff" : "#258874";
    });
  })();

  // ---- Sound toggle ----
  scard.appendChild(settingsSectionLabel(t("UI_AUDIO")));
  var soundRow = el("div","display:flex;align-items:center;justify-content:space-between;background:rgba(0,0,0,.28);border:1px solid #258874;border-radius:12px;padding:12px 14px");
  soundRow.appendChild(el("div","font-size:15px;color:#f1eee8;font-family:Arial,sans-serif",t("UI_SOUND_FX")));
  var soundToggle = el("button","width:52px;height:30px;border-radius:16px;border:2px solid #258874;background:#0c0c0c;position:relative;cursor:pointer;flex:0 0 auto");
  var soundKnob = el("div","position:absolute;top:2px;width:22px;height:22px;border-radius:50%;background:#ddb268;transition:left .15s");
  soundToggle.appendChild(soundKnob);
  soundRow.appendChild(soundToggle);
  scard.appendChild(soundRow);
  function paintSoundToggle(){
    var on = !window.DOMINO_MUTED;
    soundKnob.style.left = on ? "26px" : "2px";
    soundKnob.style.background = on ? "#ddb268" : "#555";
    soundToggle.style.borderColor = on ? "#258874" : "#444";
  }
  soundToggle.onclick = function(){
    window.DOMINO_MUTED = !window.DOMINO_MUTED;
    try { localStorage.setItem("yd_muted", window.DOMINO_MUTED ? "1" : "0"); } catch(e){}
    paintSoundToggle();
  };
  paintSoundToggle();

  // ---- Change password ----
  scard.appendChild(settingsSectionLabel(t("UI_SECURITY")));
  var pwToggleBtn = el("button","width:100%;background:rgba(0,0,0,.28);border:1px solid #258874;color:#ffe5b6;border-radius:12px;padding:12px 14px;font-size:15px;font-family:Arial,sans-serif;cursor:pointer;text-align:left",t("UI_CHANGE_PASSWORD"));
  scard.appendChild(pwToggleBtn);
  var pwForm = el("div","display:none;margin-top:10px;text-align:left");
  var curPwInput = document.createElement("input");
  curPwInput.type="password"; curPwInput.placeholder=t("UI_CURRENT_PASSWORD");
  curPwInput.style.cssText="width:100%;box-sizing:border-box;padding:11px 13px;border-radius:10px;border:2px solid #cc9f51;background:#080808;color:#fff;font-size:15px;font-family:Arial,sans-serif;outline:none;margin-bottom:8px";
  var newPwInput = document.createElement("input");
  newPwInput.type="password"; newPwInput.placeholder=t("UI_NEW_PASSWORD");
  newPwInput.style.cssText = curPwInput.style.cssText;
  var pwMsg = el("div","font-size:13px;color:#ffd894;margin:6px 0;min-height:16px","");
  var pwSaveBtn = el("button","width:100%;"+GOLD+"border-radius:10px;padding:11px 0;font-size:15px;font-weight:bold;font-family:Georgia,serif;cursor:pointer;margin-top:2px",t("UI_UPDATE_PASSWORD_LONG"));
  pwForm.appendChild(curPwInput); pwForm.appendChild(newPwInput); pwForm.appendChild(pwMsg); pwForm.appendChild(pwSaveBtn);
  scard.appendChild(pwForm);
  pwToggleBtn.onclick = function(){
    pwForm.style.display = pwForm.style.display === "none" ? "block" : "none";
    pwMsg.textContent = ""; curPwInput.value=""; newPwInput.value="";
  };
  pwSaveBtn.onclick = function(){
    var cur = curPwInput.value, nw = newPwInput.value;
    if (!cur || !nw){ pwMsg.textContent = t("UI_FILL_BOTH_FIELDS"); return; }
    if (nw.length < 6){ pwMsg.textContent = t("UI_PW_TOO_SHORT"); return; }
    if (!window.DOMINO_TOKEN){ pwMsg.textContent = t("UI_NOT_SIGNED_IN"); return; }
    pwSaveBtn.disabled = true; pwMsg.textContent = t("UI_UPDATING");
    fetch(SERVER+"/api/change-password",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+window.DOMINO_TOKEN},body:JSON.stringify({currentPassword:cur,newPassword:nw})})
      .then(function(r){return r.json().then(function(d){return {ok:r.ok,d:d};});})
      .then(function(res){
        pwSaveBtn.disabled = false;
        if(!res.ok){
          pwMsg.textContent = res.d && res.d.error==="incorrect_current_password" ? t("UI_WRONG_CURRENT_PW") : t("UI_PW_UPDATE_FAILED");
          return;
        }
        pwMsg.textContent = t("UI_PW_UPDATED");
        curPwInput.value=""; newPwInput.value="";
        setTimeout(function(){ pwForm.style.display="none"; pwMsg.textContent=""; }, 1200);
      })
      .catch(function(){ pwSaveBtn.disabled=false; pwMsg.textContent=t("UI_NETWORK_ERROR"); });
  };

  // ---- Support ----
  scard.appendChild(settingsSectionLabel(t("UI_SUPPORT")));
  var supportLink = document.createElement("a");
  supportLink.href = "mailto:support@yalladomino.app";
  supportLink.style.cssText = "display:block;background:rgba(0,0,0,.28);border:1px solid #258874;color:#ffe5b6;border-radius:12px;padding:12px 14px;font-size:15px;font-family:Arial,sans-serif;text-decoration:none;text-align:left;margin-bottom:18px";
  supportLink.textContent = t("UI_CONTACT_SUPPORT");
  scard.appendChild(supportLink);

  var versionLine = el("div","font-size:11px;color:#666;margin-bottom:14px","Yalla Domino · v1.0");
  scard.appendChild(versionLine);

  var sLogout = el("button","width:100%;"+GOLD+"border-radius:12px;padding:12px 0;font-size:16px;font-weight:bold;font-family:Georgia,serif;cursor:pointer",t("UI_LOGOUT_LONG"));
  var sback = el("button","width:100%;background:transparent;border:2px solid #ddb268;color:#f8deb3;border-radius:12px;padding:11px 0;font-size:15px;font-family:Georgia,serif;cursor:pointer;margin-top:10px",t("UI_BACK"));
  scard.appendChild(sLogout); scard.appendChild(sback);
  sov.appendChild(scard);
  settingsTile.onclick=function(){ accLine.textContent = (window.DOMINO_USER? window.DOMINO_USER.email : ""); pwForm.style.display="none"; sov.style.display="flex"; };
  sback.onclick=function(){ sov.style.display="none"; };
  sLogout.onclick=function(){ if(window.dominoLogout) window.dominoLogout(); };

  /* ================= SEARCHING (matchmaking) ================= */
  // Premium black/gold matchmaking screen
  (function(){
    var st = document.createElement("style");
    st.textContent = "@keyframes dmPulse{0%,100%{opacity:.45}50%{opacity:1}}@keyframes dmSweep{from{transform:rotate(0)}to{transform:rotate(360deg)}}";
    document.head.appendChild(st);
  })();
  var wov = el("div","position:fixed;inset:0;z-index:100002;display:none;flex-direction:column;align-items:center;justify-content:flex-start;overflow-y:auto;box-sizing:border-box;background:radial-gradient(circle at 50% 38%,#122a70 0,#0a163b 45%,#020202 82%);font-family:Arial,Helvetica,sans-serif;color:#f7ddb2;padding:clamp(24px,5vh,62px) 18px 28px");

  var wLogoRing = el("div","width:94px;height:94px;border-radius:50%;border:3px solid #e8b761;box-shadow:0 0 22px rgba(235,173,42,.5),inset 0 0 18px rgba(235,173,42,.18);display:flex;align-items:center;justify-content:center;margin-bottom:18px;background:rgba(15,11,5,.92)");
  var wLogo = document.createElement("img"); wLogo.src="icon-192.png?v=fix-20260911l"; wLogo.alt="Yalla Domino"; wLogo.style.cssText="width:76px;height:76px;border-radius:22px;object-fit:cover"; wLogoRing.appendChild(wLogo);
  var wTitle = el("div","font-family:Georgia,serif;font-size:clamp(32px,7vw,44px);line-height:1.05;color:#f8ca7b;font-weight:bold;text-align:center;text-shadow:0 2px 14px rgba(224,159,27,.22);margin-bottom:12px",t("UI_FINDING_MATCH"));
  var wSub = el("div","font-size:clamp(15px,4vw,19px);color:#c9c6bd;text-align:center;margin-bottom:22px",t("UI_LOOKING_BEST_OPPONENT"));

  var wEntry = el("div","display:flex;align-items:center;gap:10px;background:linear-gradient(180deg,#0f2561,#091538);border:2px solid #bc9044;border-radius:30px;padding:10px 22px;box-shadow:0 5px 18px rgba(0,0,0,.4);margin-bottom:12px");
  wEntry.appendChild(el("span","font-size:22px","🪙"));
  var wEntryTxt = el("span","font-family:Georgia,serif;font-size:17px;color:#f6d59b;font-weight:bold",t("UI_ENTRY_FREE")); wEntry.appendChild(wEntryTxt);
  var wPrize = el("div","display:flex;align-items:center;gap:9px;background:rgba(12,9,5,.65);border:1px solid rgba(181,119,22,.22);border-radius:28px;padding:9px 22px;color:#f3ca83;font-family:Georgia,serif;font-size:17px;font-weight:bold;margin-bottom:34px");
  wPrize.appendChild(el("span","font-size:20px","🏆")); var wPrizeTxt=el("span","",t("UI_FREE_PLAY_LABEL")); wPrize.appendChild(wPrizeTxt);

  var wRow = el("div","display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr);align-items:center;gap:12px;width:min(100%,620px);margin:0 auto 26px");
  var wMe = el("div","min-width:0;display:flex;flex-direction:column;align-items:center;gap:10px");
  var wMeAv = el("div","width:clamp(100px,28vw,140px);height:clamp(100px,28vw,140px);border-radius:50%;background:#081230;border:5px solid #e6b35c;box-shadow:0 0 24px rgba(226,169,38,.42);display:flex;align-items:center;justify-content:center;font-size:clamp(54px,15vw,76px)","👤");
  var wMeName = el("div","max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border:2px solid #a27d3c;border-radius:22px;padding:8px 13px;box-sizing:border-box;font-family:Georgia,serif;font-size:clamp(12px,3.5vw,16px);color:#f3d39b;font-weight:bold;text-align:center",t("UI_PLAYER_LABEL"));
  wMe.appendChild(wMeAv); wMe.appendChild(wMeName);
  var wMid = el("div","font-family:Georgia,serif;font-size:clamp(34px,10vw,52px);font-weight:bold;color:#f3c371;text-shadow:0 0 15px rgba(235,173,42,.3)","VS");
  var wOpp = el("div","min-width:0;display:flex;flex-direction:column;align-items:center;gap:10px");
  var wSpinWrap = el("div","width:clamp(100px,28vw,140px);height:clamp(100px,28vw,140px);border-radius:50%;background:#081230;border:5px solid #e1af58;box-shadow:0 0 24px rgba(226,169,38,.32);display:flex;align-items:center;justify-content:center;position:relative");
  var wSpin = el("div","position:absolute;inset:-5px;border-radius:50%;border:5px solid transparent;border-right-color:#237766;animation:dmSweep 1.25s linear infinite");
  var wQ = el("div","font-size:clamp(56px,16vw,82px);font-family:Georgia,serif;color:#f3c679;font-weight:bold","?"); wSpinWrap.appendChild(wSpin); wSpinWrap.appendChild(wQ);
  var wOppName = el("div","width:100%;box-sizing:border-box;border:2px solid #a27d3c;border-radius:22px;padding:8px 10px;font-family:Georgia,serif;font-size:clamp(13px,3.5vw,16px);color:#f3d39b;font-weight:bold;text-align:center",t("UI_SEARCHING")); wOppName.style.animation="dmPulse 1.2s ease-in-out infinite";
  wOpp.appendChild(wSpinWrap); wOpp.appendChild(wOppName); wRow.appendChild(wMe); wRow.appendChild(wMid); wRow.appendChild(wOpp);

  var wStatus = el("div","width:min(100%,560px);box-sizing:border-box;display:flex;align-items:center;gap:18px;border:1px solid #165649;border-radius:22px;background:linear-gradient(120deg,#0e225a,#091334);padding:18px 20px;margin-top:6px");
  var radar=el("div","width:72px;height:72px;flex:0 0 72px;border-radius:50%;border:1px solid #1e6a5b;background:repeating-radial-gradient(circle,#2355e1 0 1px,transparent 2px 15px);position:relative");
  var sweep=el("div","position:absolute;left:50%;top:50%;width:32px;height:2px;transform-origin:left center;background:#ecbc6a;box-shadow:0 0 8px #ecbc6a;animation:dmSweep 1.6s linear infinite"); radar.appendChild(sweep);
  var statusText=el("div","min-width:0;flex:1"); var wMsg=el("div","font-size:clamp(16px,4.2vw,20px);font-weight:bold;color:#f3cb85;margin-bottom:7px",t("UI_LOOKING_FOR_OPPONENT")); statusText.appendChild(wMsg); statusText.appendChild(el("div","font-size:14px;color:#aaa59a;margin-bottom:10px",t("UI_PLEASE_WAIT_MOMENT")));
  var dots=el("div","display:flex;gap:8px"); for(var di=0;di<9;di++){var d=el("span","width:9px;height:9px;border-radius:50%;background:"+(di<5?"#eebe6c":"#183a9a"));dots.appendChild(d);} statusText.appendChild(dots); wStatus.appendChild(radar);wStatus.appendChild(statusText);
  var wCancel=el("button","margin-top:24px;min-width:210px;background:linear-gradient(180deg,#0f2561,#091538);border:2px solid #ad853f;color:#edc683;border-radius:18px;padding:13px 30px;font-size:18px;font-weight:bold;cursor:pointer;box-shadow:0 5px 18px rgba(0,0,0,.35)","✕  "+t("UI_CANCEL"));
  var wFoot=el("div","display:flex;align-items:center;gap:18px;margin-top:28px;color:#8f8c84;font-size:14px"); wFoot.appendChild(el("span","",t("UI_CONNECTED"))); wFoot.appendChild(el("span","color:#28584e","│")); wFoot.appendChild(el("span","",t("UI_SECURE")));
  [wLogoRing,wTitle,wSub,wEntry,wPrize,wRow,wStatus,wCancel,wFoot].forEach(function(x){wov.appendChild(x);});

  function openSearching(){
    var me=window.DOMINO_USER||{}; paintAvatar(wMeAv, me); wMeName.textContent=nameOf(me);
    wEntryTxt.textContent=isFreeMatch?t("UI_ENTRY_FREE"):t("UI_ENTRY_PREFIX")+myStake.toFixed(2);
    wPrizeTxt.textContent=isFreeMatch?t("UI_FREE_MATCH"):t("UI_WINNER_GETS")+" $"+myPrize.toFixed(2);
    closeGoal(); wov.style.display="flex";
  }
  function closeSearching(){wov.style.display="none";}
  wCancel.onclick=function(){clearMatchTimer();try{if(socket&&socket.connected)socket.emit("cancel_find");}catch(e){}closeSearching();showOverlay();};

  /* ================= VS SCREEN ================= */
  var vov = el("div","position:fixed;inset:0;z-index:100002;display:none;flex-direction:column;align-items:center;justify-content:center;background:radial-gradient(90% 55% at 50% 12%,rgba(111,67,13,.25),transparent 62%),linear-gradient(180deg,#081230 0%,#091334 52%,#081230 100%);font-family:Arial,sans-serif;color:#f8deb3;padding:22px;box-sizing:border-box;overflow:hidden");
  var vsGlow = el("div","position:absolute;top:9%;left:50%;transform:translateX(-50%);width:170px;height:170px;border-radius:50%;background:radial-gradient(circle,rgba(239,180,46,.18),transparent 68%);filter:blur(4px);pointer-events:none"); vov.appendChild(vsGlow);
  var vsLogoRing = el("div","position:relative;width:94px;height:94px;border-radius:50%;border:3px solid #eab75e;box-shadow:0 0 25px rgba(235,173,42,.48),inset 0 0 18px rgba(235,173,42,.15);display:flex;align-items:center;justify-content:center;background:#091538;margin-bottom:20px");
  var vsLogo=document.createElement("img"); vsLogo.src="icon-192.png?v=fix-20260911l"; vsLogo.alt="Yalla Domino"; vsLogo.style.cssText="width:76px;height:76px;border-radius:22px;object-fit:cover"; vsLogoRing.appendChild(vsLogo);
  var vsTitle = el("div","font-family:Georgia,serif;font-size:clamp(34px,8vw,48px);font-weight:bold;color:#f5c572;text-align:center;text-shadow:0 2px 15px rgba(235,173,42,.28);margin-bottom:8px",t("UI_GET_READY"));
  var vsSub = el("div","font-size:clamp(14px,3.8vw,18px);color:#bdb9ae;text-align:center;margin-bottom:20px",t("UI_MATCH_READY"));
  var vsEntry = el("div","display:flex;align-items:center;gap:9px;background:linear-gradient(180deg,#0f2561,#091538);border:2px solid #ae8643;border-radius:28px;padding:10px 20px;margin-bottom:10px;box-shadow:0 5px 18px rgba(0,0,0,.38)");
  vsEntry.appendChild(el("span","font-size:20px","🪙"));
  var vsEntryTxt = el("span","font-family:Georgia,serif;font-size:17px;color:#f6d59b;font-weight:bold",t("UI_ENTRY_FREE")); vsEntry.appendChild(vsEntryTxt);
  var vsPrize = el("div","display:flex;align-items:center;gap:8px;color:#f3ca83;font-family:Georgia,serif;font-size:17px;font-weight:bold;margin-bottom:36px");
  vsPrize.appendChild(el("span","font-size:20px","🏆")); var vsPrizeTxt = el("span","",t("UI_FREE_PLAY_LABEL")); vsPrize.appendChild(vsPrizeTxt);
  var vsRow = el("div","display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr);align-items:center;gap:12px;width:min(100%,620px);margin:0 auto 30px;position:relative");
  function vsSide(){
    var w=el("div","min-width:0;display:flex;flex-direction:column;align-items:center;gap:11px");
    var a=el("div","width:clamp(104px,28vw,142px);height:clamp(104px,28vw,142px);border-radius:50%;background:#081230;border:5px solid #e6b35c;box-shadow:0 0 26px rgba(226,169,38,.38),inset 0 0 18px rgba(226,169,38,.08);display:flex;align-items:center;justify-content:center;font-size:clamp(54px,15vw,78px)","👤");
    var n=el("div","width:100%;box-sizing:border-box;border:2px solid #218d77;border-radius:22px;padding:8px 10px;font-family:Georgia,serif;font-size:clamp(12px,3.4vw,16px);color:#f3d39b;font-weight:bold;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:center",t("UI_PLAYER_LABEL"));
    w.appendChild(a); w.appendChild(n); return {wrap:w,av:a,name:n};
  }
  var vsLeft=vsSide(), vsRight=vsSide();
  var vsMid=el("div","width:clamp(68px,18vw,92px);height:clamp(68px,18vw,92px);border-radius:50%;border:1px solid rgba(181,119,22,.28);display:flex;align-items:center;justify-content:center;font-family:Georgia,serif;font-size:clamp(34px,9vw,50px);font-weight:bold;color:#f3c371;text-shadow:0 0 16px rgba(235,173,42,.32);box-shadow:inset 0 0 28px rgba(226,169,38,.06)","VS");
  vsRow.appendChild(vsLeft.wrap); vsRow.appendChild(vsMid); vsRow.appendChild(vsRight.wrap);
  var vsStatus = el("div","width:min(100%,520px);box-sizing:border-box;border:1px solid #165649;border-radius:20px;background:linear-gradient(120deg,#0e225a,#091334);padding:16px 20px;text-align:center;box-shadow:0 8px 24px rgba(0,0,0,.32)");
  var vsMsg=el("div","font-size:clamp(17px,4.2vw,20px);font-weight:bold;color:#f3cb85;margin-bottom:6px",t("UI_STARTING_GAME"));
  var vsMsg2=el("div","font-size:14px;color:#aaa59a",t("UI_PREPARE_DOMINOES")); vsStatus.appendChild(vsMsg);vsStatus.appendChild(vsMsg2);
  var vsDots=el("div","display:flex;justify-content:center;gap:8px;margin-top:12px"); for(var vi=0;vi<5;vi++){var vd=el("span","width:8px;height:8px;border-radius:50%;background:#eebe6c;animation:dmPulse 1s ease-in-out infinite;animation-delay:"+(vi*.12)+"s");vsDots.appendChild(vd);} vsStatus.appendChild(vsDots);
  var vsFoot=el("div","display:flex;align-items:center;gap:18px;margin-top:25px;color:#8f8c84;font-size:14px"); vsFoot.appendChild(el("span","",t("UI_CONNECTED")));vsFoot.appendChild(el("span","color:#28584e","│"));vsFoot.appendChild(el("span","",t("UI_SECURE")));
  [vsLogoRing,vsTitle,vsSub,vsEntry,vsPrize,vsRow,vsStatus,vsFoot].forEach(function(x){vov.appendChild(x);});

  function showVsThenStart(oppName, oppAvatar, startFn){
    var me=window.DOMINO_USER||{};
    paintAvatar(vsLeft.av, me); vsLeft.name.textContent=nameOf(me);
    vsRight.av.textContent=oppAvatar||"🧑"; vsRight.name.textContent=oppName||t("UI_OPPONENT");
    vsEntryTxt.textContent=isFreeMatch?t("UI_ENTRY_FREE"):t("UI_ENTRY_PREFIX")+myStake.toFixed(2);
    vsPrizeTxt.textContent=isFreeMatch?t("UI_FREE_MATCH"):t("UI_WINNER_GETS")+" $"+myPrize.toFixed(2);
    closeGoal();closeSearching();vov.style.display="flex";
    setTimeout(function(){vov.style.display="none";startFn();},2600);
  }

  /* ================= IN-GAME PLAYER CHIPS ================= */
  function buildChip(isOpp){
    var c = el("div","position:fixed;z-index:60;display:none;align-items:center;gap:10px;pointer-events:none;"
      + "background:linear-gradient(180deg,#15584b,#2458e9);border:3px solid #ddb268;border-radius:44px;"
      + "box-shadow:0 6px 16px rgba(0,0,0,.5);font-family:Georgia,serif;");
    var av = el("div","width:48px;height:48px;border-radius:50%;flex:0 0 auto;"
      + "background:radial-gradient(circle at 50% 35%,#2254de,#16368e);border:3px solid #f4c677;"
      + "display:flex;align-items:center;justify-content:center;font-size:26px;box-shadow:0 0 0 2px #237464;","👤");
    var info = el("div","display:flex;flex-direction:column;gap:2px;");
    var nm = el("div","color:#ffe5b6;font-size:13px;font-weight:bold;line-height:1;max-width:72px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;",t("UI_PLAYER_LABEL"));
    var pts = el("div","display:inline-block;background:#1a3ea5;border:2px solid #cdaa6d;border-radius:12px;color:#ffcf7d;font-size:11px;font-weight:bold;padding:1px 8px;","0 "+t("UI_PTS"));
    info.appendChild(nm); info.appendChild(pts);
    if (isOpp){
      c.style.flexDirection="row-reverse"; c.style.padding="5px 5px 5px 14px"; c.style.textAlign="right";
      c.style.right="10px"; c.style.top="46px";
      info.style.alignItems="flex-end";
    } else {
      c.style.padding="5px 14px 5px 5px";
      c.style.left="10px"; c.style.bottom="60px";
      info.style.alignItems="flex-start";
    }
    c.appendChild(av); c.appendChild(info);
    return {root:c, av:av, name:nm, pts:pts};
  }
  var meChip = buildChip(false);
  var oppChip = buildChip(true);
  var chipsOn = false;

  // debug removed (issue fixed)
  window.dominoDebug = function(){};

  function setTurnRing(chip, on){
    if (on){ chip.av.style.borderColor="#ffdb9d"; chip.av.style.boxShadow="0 0 14px rgba(124,252,122,.85),0 0 0 2px #2d675b"; }
    else { chip.av.style.borderColor="#f4c677"; chip.av.style.boxShadow="0 0 0 2px #237464"; }
  }
  function showChips(meName, meAv, oppName, oppAv){
    chipsOn = false;
    meChip.root.style.display = "none";
    oppChip.root.style.display = "none";
  }
  function hideChips(){ chipsOn=false; meChip.root.style.display="none"; oppChip.root.style.display="none"; }

  // live update of scores + whose-turn ring
  setInterval(function(){
    if (!chipsOn) return;
    if (typeof s_oGame === "undefined" || !s_oGame || typeof s_oGame.getScoreOf !== "function") return;
    try {
      meChip.pts.textContent  = s_oGame.getScoreOf(0) + " " + t("UI_PTS");
      oppChip.pts.textContent = s_oGame.getScoreOf(1) + " " + t("UI_PTS");
      var t = s_oGame.getTurn();
      setTurnRing(meChip, t === 0);
      setTurnRing(oppChip, t === 1);
    } catch(e){}
  }, 350);

  /* ============ RETURN TO OUR LOBBY WHEN A GAME ENDS ============ */
  var _menuPatched = false;
  function dominoReturnToLobby(forceDisconnect){
    try { matchFriendBtn.style.display="none"; } catch(e){}
    // MONEY-SAFETY: UI navigation/rebuild is never proof of a voluntary forfeit.
    // If we're bailing out of a match that's still ACTIVE (never reached a
    // normal win/loss/forfeit conclusion), the opponent deserves credit
    // for our departure — same as if we'd lost connection. Tell the server
    // explicitly via a dedicated event (handled with the exact same
    // forfeit logic as a real disconnect) instead of previously just
    // hiding the UI locally while the socket stayed silently connected —
    // that left the server with no idea we'd left, so the opponent never
    // got credited.
    //
    // forceDisconnect defaults to true (a deliberate exit via the menu/back
    // button). Pass false from the t("UI_OPPONENT_NOT_RESPONDING_SHORT") watchdog —
    // there, WE are not the one abandoning the match, so reporting
    // ourselves as leaving would wrongly hand the win to the unresponsive
    // opponent.
    if (forceDisconnect === true && window.s_bOnline && !matchEndedNormally && socket && socket.connected){
      try { console.log("[leave] emitting leave_match (forceDisconnect=" + forceDisconnect + " matchEndedNormally=" + matchEndedNormally + ")"); } catch(e){}
      try { socket.emit("leave_match", { confirmed: true }); } catch(e){}
    } else {
      try { console.log("[leave] NOT emitting leave_match (forceDisconnect=" + forceDisconnect + " online=" + window.s_bOnline + " matchEndedNormally=" + matchEndedNormally + " connected=" + (socket&&socket.connected) + ")"); } catch(e){}
    }

    started = false;
    window.s_bOnline = false;
    stopGameStateHeartbeat();
    hideChips();

    // Wipe the engine's *global* carry-over state. s_aPlayersScoreN lives on
    // window and is normally only cleared by the game's own menu screens —
    // which we deliberately bypass (patchGotoMenu redirects them all to this
    // lobby). Without this, the previous match's score followed the player
    // into their next match: you'd start a brand new game and immediately
    // see the opponent sitting on the old score.
    try {
      window.s_aPlayersScore2 = [0,0];
      window.s_aPlayersScore3 = [0,0,0];
      window.s_aPlayersScore4 = [0,0,0,0];
      if (typeof s_oGame !== "undefined" && s_oGame && typeof s_oGame.resetScore === "function") {
        s_oGame.resetScore(2);
      }
    } catch(e){}

    showOverlay();   // our lobby on top of the game's menu
    oppWatchStart = null;
    oppStuckShown = false;
    if (oppStuckBox) oppStuckBox.style.display = "none";
    // refresh coins / wins / losses from the server
    if (window.DOMINO_TOKEN){
      fetch(SERVER + "/api/me", { headers:{ Authorization:"Bearer "+window.DOMINO_TOKEN } })
        .then(function(r){ return r.ok ? r.json() : null; })
        .then(function(d){ if(d && d.user){ window.DOMINO_USER = d.user; renderUser(d.user); } })
        .catch(function(){});
    }
  }
  function patchGotoMenu(){
    if (_menuPatched) return;
    if (typeof s_oMain === "undefined" || !s_oMain) return;
    // redirect ALL of the game's internal menus (Menu / Select Players / Select Goal)
    // to OUR lobby, so the game never shows its own menu screens.
    if (typeof s_oMain.gotoMenu === "function") {
      s_oMain.gotoMenu = function(){ dominoReturnToLobby(false); };
    }
    if (typeof s_oMain.gotoSelectPlayers === "function") {
      s_oMain.gotoSelectPlayers = function(){ dominoReturnToLobby(false); };
    }
    if (typeof s_oMain.gotoSelectGoal === "function") {
      s_oMain.gotoSelectGoal = function(){ dominoReturnToLobby(false); };
    }
    _menuPatched = true;
  }
  // keep trying to patch until the game engine is ready
  var _patchPoll = setInterval(function(){
    patchGotoMenu();
    if (_menuPatched) { clearInterval(_patchPoll); }
  }, 500);

  /* ============ OPPONENT UNRESPONSIVE WATCHDOG ============ */
  // If the server's disconnect detection is slow (or misses it entirely),
  // this stops the board from waiting forever on an opponent who is gone.
  var oppWatchStart = null;
  var oppStuckShown = false;
  var OPP_STUCK_MS = 45000;
  var oppStuckBox = null;

  var desyncBox = null;
  function showBoardDesyncNotice(){
    if (desyncBox && document.body.contains(desyncBox)) { desyncBox.style.display = "block"; return; }
    desyncBox = el("div","position:fixed;left:50%;bottom:26px;transform:translateX(-50%);z-index:100006;max-width:92vw;box-sizing:border-box;padding:14px 18px;border-radius:16px;border:2px solid #e8b55e;background:#0c0c0c;color:#f1eee8;font-family:Arial,sans-serif;font-size:14px;text-align:center;box-shadow:0 12px 30px rgba(0,0,0,.6)");
    var txt = el("div","margin-bottom:10px",t("UI_BOARD_DESYNC_NOTICE"));
    var btn = el("button","background:linear-gradient(180deg,#ffdc9f,#d9a955);border:none;color:#1a3ea5;border-radius:10px;padding:9px 18px;font-weight:800;font-size:14px;cursor:pointer",t("UI_REFRESH_NOW"));
    btn.onclick = function(){ try { localStorage.setItem("yd_pending_resume", "1"); } catch(e){} location.reload(); };
    desyncBox.appendChild(txt); desyncBox.appendChild(btn);
    document.body.appendChild(desyncBox);
  }
  window.showBoardDesyncNotice = showBoardDesyncNotice;

  function getOppStuckBox(){
    if (oppStuckBox && document.body.contains(oppStuckBox)) return oppStuckBox;
    oppStuckBox = el("div","position:fixed;left:50%;bottom:26px;transform:translateX(-50%);z-index:100006;display:none;max-width:92vw;box-sizing:border-box;padding:14px 18px;border-radius:16px;border:2px solid #e8b55e;background:#0c0c0c;color:#f1eee8;font-family:Arial,sans-serif;font-size:14px;text-align:center;box-shadow:0 12px 30px rgba(0,0,0,.6)");
    var txt = el("div","margin-bottom:10px",t("UI_OPPONENT_NOT_RESPONDING_LONG"));
    var btn = el("button","background:linear-gradient(180deg,#ffdc9f,#d9a955);border:none;color:#1a3ea5;border-radius:10px;padding:9px 18px;font-weight:800;font-size:14px;cursor:pointer",t("UI_LEAVE_MATCH"));
    btn.onclick = function(){
      oppStuckBox.style.display = "none";
      oppWatchStart = null; oppStuckShown = false;
      try { dominoReturnToLobby(false); } catch(e){}
    };
    oppStuckBox.appendChild(txt); oppStuckBox.appendChild(btn);
    document.body.appendChild(oppStuckBox);
    return oppStuckBox;
  }

  function watchOpponentTurn(){
    try {
      var active = window.s_bOnline && typeof s_oGame !== "undefined" && s_oGame && typeof s_oGame.getTurn === "function";
      var oppTurn = active && s_oGame.getTurn() === 1;
      if (!oppTurn){
        oppWatchStart = null;
        if (oppStuckShown){ oppStuckShown = false; getOppStuckBox().style.display = "none"; }
        return;
      }
      var now = Date.now();
      if (!oppWatchStart){ oppWatchStart = now; return; }
      if (!oppStuckShown && (now - oppWatchStart) > OPP_STUCK_MS){
        oppStuckShown = true;
        getOppStuckBox().style.display = "block";
        reportStuckMatch("opponent_turn_timeout");
      }
    } catch(e){}
  }
  setInterval(watchOpponentTurn, 1000);

  /* ================= SOCKET / GAME ================= */
  var _uiMounted = false;
  function mountDominoUI(){
    if(_uiMounted || !document.body) return;
    _uiMounted = true;
    document.body.appendChild(ov);
    document.body.appendChild(gov);
    document.body.appendChild(pov);
    document.body.appendChild(sov);
    document.body.appendChild(wov);
    // Wallet modal must be mounted too; without this, Deposit/Withdraw clicks
    // change its display state but nothing can appear on screen.
    document.body.appendChild(wlov);
    document.body.appendChild(vov);
    // Tournament leaderboard modal must be mounted too; without this, the
    // Weekly Tournament card click changes its display state but nothing shows.
    document.body.appendChild(lov);
    document.body.appendChild(rov);
    document.body.appendChild(meChip.root);
    document.body.appendChild(oppChip.root);
    // The lobby must be clickable immediately; game canvas stays underneath it.
    ov.style.display = "flex";
    mountChatUI();
    connect();
  }
  if(document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mountDominoUI);
  } else {
    // With this script now loaded via <script defer>, readyState can
    // already be past "loading" the instant this line runs -- but we're
    // still partway through THIS script's own top-level execution (e.g.
    // REACTION_EMOJIS below hasn't been assigned yet even though it's
    // declared later in the same file). A 0ms timeout pushes the call to
    // the next tick, after this script has fully finished running, same
    // as the DOMContentLoaded branch above always guaranteed.
    setTimeout(mountDominoUI, 0);
  }

  /* ================= IN-MATCH CHAT (real opponent only) ================= */
  // All DOM creation for this lives in mountChatUI(), called from
  // mountDominoUI() below — never at top-level, since this script loads in
  // <head> before <body> exists yet (document.body would still be null).
  var chatOpen = false;
  var chatUnread = 0;
  var chatBadge, chatBtn, chatPanel, chatHeader, chatClose, chatList,
      chatInputRow, chatInput, chatSend, reactBtn, reactTray;
  var REACTION_EMOJIS = ["👍","😂","😮","😢","😡","❤️","🔥","👏","🎉","🤝"];

  function mountChatUI(){
    chatBadge = el("div","position:absolute;top:-4px;right:-4px;min-width:18px;height:18px;padding:0 4px;border-radius:9px;background:#ef5a5a;color:#fff;font:bold 11px Arial;display:none;align-items:center;justify-content:center","");
    chatBtn = el("div","position:fixed;right:18px;bottom:170px;z-index:2147483000;width:60px;height:60px;border-radius:50%;background:#0f2561;border:3px solid #d8ac51;display:none;align-items:center;justify-content:center;font-size:24px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.5)","💬");
    chatBtn.appendChild(chatBadge);
    document.body.appendChild(chatBtn);

    chatPanel = el("div","position:fixed;left:50%;bottom:0;transform:translateX(-50%);width:min(94vw,420px);max-height:52vh;z-index:2147483001;background:rgba(6,26,19,.98);border:2px solid #f4c97f;border-radius:20px 20px 0 0;display:none;flex-direction:column;box-shadow:0 -8px 30px rgba(0,0,0,.6)");
    chatHeader = el("div","display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-bottom:1px solid rgba(244,195,81,.25)");
    chatHeader.appendChild(el("div","color:#f4c97f;font:bold 16px Arial",t("UI_MATCH_CHAT_TITLE")));
    chatClose = el("div","cursor:pointer;color:#f4c97f;font:bold 18px Arial;padding:0 6px","✕");
    chatHeader.appendChild(chatClose);
    chatList = el("div","flex:1;overflow-y:auto;padding:10px 14px;display:flex;flex-direction:column;gap:8px;max-height:32vh");
    chatInputRow = el("div","display:flex;gap:8px;padding:10px 14px;border-top:1px solid rgba(244,195,81,.2)");
    chatInput = document.createElement("input");
    chatInput.type = "text"; chatInput.maxLength = 300; chatInput.placeholder = t("UI_MATCH_CHAT_PLACEHOLDER");
    chatInput.style.cssText = "flex:1;min-width:0;padding:10px 12px;border-radius:12px;border:1px solid rgba(244,195,81,.4);background:rgba(255,255,255,.06);color:#fff;font:14px Arial";
    chatSend = el("div","padding:10px 16px;border-radius:12px;background:#f4c97f;color:#1d45b8;font:bold 14px Arial;cursor:pointer;display:flex;align-items:center",t("UI_MATCH_CHAT_SEND"));
    chatInputRow.appendChild(chatInput); chatInputRow.appendChild(chatSend);
    chatPanel.appendChild(chatHeader); chatPanel.appendChild(chatList); chatPanel.appendChild(chatInputRow);
    document.body.appendChild(chatPanel);

    // Quick emoji reactions — separate from typed chat. Tapping the 😊
    // button opens a row of common reactions; picking one sends it
    // instantly (no typing) and shows a big floating animation on both
    // screens.
    reactBtn = el("div","position:fixed;right:18px;bottom:190px;z-index:2147483000;width:60px;height:60px;border-radius:50%;background:#0f2561;border:3px solid #d8ac51;display:none;align-items:center;justify-content:center;font-size:24px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.5)","😊");
    document.body.appendChild(reactBtn);

    reactTray = el("div","position:fixed;right:18px;bottom:350px;z-index:2147483000;display:none;flex-direction:column;gap:8px;background:rgba(6,26,19,.98);border:2px solid #f4c97f;border-radius:16px;padding:10px;box-shadow:0 8px 24px rgba(0,0,0,.5)");
    var reactRow1 = el("div","display:flex;gap:8px");
    var reactRow2 = el("div","display:flex;gap:8px");
    REACTION_EMOJIS.forEach(function(em, i){
      var b = el("div","width:36px;height:36px;border-radius:10px;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;font-size:20px;cursor:pointer", em);
      b.onclick = function(){ sendReaction(em); reactTray.style.display = "none"; };
      (i < 5 ? reactRow1 : reactRow2).appendChild(b);
    });
    reactTray.appendChild(reactRow1); reactTray.appendChild(reactRow2);
    document.body.appendChild(reactTray);

    reactBtn.onclick = function(){
      reactTray.style.display = (reactTray.style.display === "none") ? "flex" : "none";
    };
    chatClose.onclick = closeChat;
    chatBtn.onclick = function(){ if (chatOpen) closeChat(); else openChat(); };
    chatSend.onclick = sendChat;
    chatInput.addEventListener("keydown", function(e){ if (e.key === "Enter") sendChat(); });

    // Show the chat/react buttons in any active match — real opponent or
    // the built-in CPU. Against the CPU, sendChat/sendReaction below fall
    // back to a simulated reply instead of a socket emit.
    setInterval(function(){
      var shouldShow = !!started;
      chatBtn.style.display = shouldShow ? "flex" : "none";
      // Emoji button removed from the UI on request. Left in the DOM
      // but never shown, so the tray/handlers below stay valid.
      reactBtn.style.display = "none";
      if (!shouldShow){
        if (chatOpen) closeChat();
        reactTray.style.display = "none";
      }
    }, 500);
  }

  function floatReaction(emoji, mine){
    var pop = el("div","position:fixed;left:50%;bottom:"+(mine?"190px":"260px")+";transform:translateX(-50%);z-index:2147483002;font-size:48px;pointer-events:none;transition:transform 1.4s ease-out,opacity 1.4s ease-out;opacity:1", emoji);
    document.body.appendChild(pop);
    requestAnimationFrame(function(){
      pop.style.transform = "translateX(-50%) translateY(-90px) scale(1.3)";
      pop.style.opacity = "0";
    });
    setTimeout(function(){ if (pop.parentNode) pop.parentNode.removeChild(pop); }, 1500);
  }

  // Canned CPU replies — used only when there's no real opponent (offline
  // vs Computer), so the chat/react buttons still feel alive instead of
  // just doing nothing.
  var CPU_CHAT_REPLIES = [t("UI_QUICK_GOOD_LUCK"),t("UI_QUICK_NICE_MOVE"),t("UI_QUICK_LETS_GO"),t("UI_QUICK_THINKING"),"😄",t("UI_QUICK_YOUR_TURN"),t("UI_QUICK_GG"),t("UI_QUICK_FOCUSED")];
  var CPU_EMOJI_REPLIES = ["👍","😂","🔥","😮","🤝","🎉"];

  function maybeCpuReply(){
    if (window.s_bOnline) return; // real opponent — server handles replies
    var delay = 700 + Math.random()*1600;
    setTimeout(function(){
      if (!started || window.s_bOnline) return;
      var isEmoji = Math.random() < 0.4;
      var text = isEmoji
        ? CPU_EMOJI_REPLIES[Math.floor(Math.random()*CPU_EMOJI_REPLIES.length)]
        : CPU_CHAT_REPLIES[Math.floor(Math.random()*CPU_CHAT_REPLIES.length)];
      window.dominoReceiveChat(text, isEmoji ? "emoji" : "text");
    }, delay);
  }

  function sendReaction(emoji){
    if (!started) return;
    if (window.s_bOnline){
      if (!socket || !socket.connected) return;
      socket.emit("chat_message", { text: emoji, type: "emoji" });
    }
    addChatBubble(emoji, true);
    floatReaction(emoji, true);
    maybeCpuReply();
  }

  function addChatBubble(text, mine){
    var row = el("div","display:flex;justify-content:"+(mine?"flex-end":"flex-start"));
    var bub = el("div","max-width:78%;padding:8px 12px;border-radius:14px;font:14px Arial;line-height:1.35;word-break:break-word;background:"+(mine?"#f4c97f":"rgba(255,255,255,.08)")+";color:"+(mine?"#1d45b8":"#f2f2f2"), text);
    row.appendChild(bub);
    chatList.appendChild(row);
    chatList.scrollTop = chatList.scrollHeight;
  }
  function clearChat(){ if (chatList) chatList.innerHTML = ""; chatUnread = 0; if (chatBadge) chatBadge.style.display = "none"; }
  function openChat(){ chatOpen = true; chatPanel.style.display = "flex"; chatUnread = 0; chatBadge.style.display = "none"; reactTray.style.display = "none"; chatInput.focus(); }
  function closeChat(){ chatOpen = false; chatPanel.style.display = "none"; }

  function sendChat(){
    var text = chatInput.value.trim();
    if (!text || !started) return;
    if (window.s_bOnline){
      if (!socket || !socket.connected) return;
      socket.emit("chat_message", { text: text });
    }
    addChatBubble(text, true);
    chatInput.value = "";
    maybeCpuReply();
  }

  window.dominoReceiveChat = function(text, type){
    addChatBubble(text, false);
    if (type === "emoji") floatReaction(text, false);
    if (!chatOpen){
      chatUnread++;
      chatBadge.textContent = String(chatUnread);
      chatBadge.style.display = "flex";
    }
  };

  function connect(){
    if (typeof io === "undefined"){ msg.textContent=t("UI_SOCKET_MISSING"); return; }
    // Tuned for weak/unstable mobile networks (patchy 3G/4G), which is the
    // common case for our players:
    //  - polling FIRST: long-polling survives flaky links far better than a
    //    raw WebSocket upgrade, which often fails outright on bad signal.
    //    socket.io still upgrades to WebSocket automatically once the
    //    connection proves stable, so good networks lose nothing.
    //  - unlimited reconnection attempts with a capped backoff, so a phone
    //    that loses signal in a lift/tunnel keeps retrying instead of giving
    //    up after the default 5 tries and stranding the player mid-match.
    //  - longer timeout: a slow handshake is not the same as a dead link.
    socket = io(SERVER,{
      // Websocket FIRST, polling only as a fallback.
      //
      // With polling first, every connection begins as HTTP long-polling
      // and only upgrades afterwards. On mobile that is the most fragile
      // way to hold a connection, and a dropped socket is what ends a
      // match. Trying websocket first removes that phase. Polling stays in
      // the list so a network that blocks websockets still connects.
      transports:["websocket","polling"],
      reconnection:true,
      reconnectionAttempts:Infinity,
      // Come back fast: every second away is a second of the match stalled.
      reconnectionDelay:400,
      reconnectionDelayMax:2000,
      randomizationFactor:0.5,
      timeout:20000
    });
    socket.on("connect", function(){
      msg.textContent=t("UI_CONNECTED_TICK");
      // Restore the Play button to its normal, tappable look now that we
      // actually have a connection (see the dimmed "connecting..." state
      // it starts in above).
      try { bigPlay.style.opacity = "1"; playNow.textContent = t("UI_PLAY_NOW"); } catch(e){}
      // A reconnect after a real drop used to ask the server for
      // resume_match to reclaim the seat. The server now forfeits the
      // match the instant a real disconnect happens (see
      // /areas/yalla-domino.md) -- by the time this phone is back, the
      // match is already over and the opponent already notified. There is
      // nothing left to resume, so show the same end-of-match screen
      // instead of asking a server that will never answer.
      if (started && window.s_bOnline) {
        endMatchAfterDrop();
      } else {
        var pendingResume = false;
        try { pendingResume = localStorage.getItem("yd_pending_resume") === "1"; } catch(e6){}
        if (pendingResume) {
          try { localStorage.removeItem("yd_pending_resume"); } catch(e7){}
          endMatchAfterDrop();
        }
      }
    });
    socket.on("disconnect", function(){
      // Signal groups can drop the socket mid-lobby too, not just mid-match
      // -- go back to the dimmed "connecting..." look so a tap here gives
      // the same clear feedback instead of silently doing nothing again.
      try { bigPlay.style.opacity = "0.55"; playNow.textContent = t("UI_CONNECTING_ELLIPSIS"); } catch(e){}
      if (started && window.reportGlitch) window.reportGlitch("socket disconnected mid-match");
    });

    // Server confirmed (or refused) our seat reclaim.
    socket.on("resume_result", function(d){
      if (d && d.ok) {
        resumeRetryCount = 0;
        msg.textContent = t("UI_CONNECTED_TICK");
        if (d.seat != null) mySeat = d.seat;

        if (d.needsFullRebuild) {
          // FULL RESUME SAFETY: build a clean round from the server's original
          // deal, WAIT until the deal animation is completely finished, then
          // restore the authoritative action log in order. Previously the log
          // was replayed while CBoxAnimation was still distributing tiles;
          // both paths mutated the same hands at once and produced
          // "no tile at destination index" + broken boards.
          // Claim the shared resync lock for the whole manual replay below.
          // The game_state handler's own rebuildFromState checks this same
          // flag (see CGame.js) and defers instead of tearing the board down
          // mid-way through this loop -- that double-mutation of the same
          // hands is what produced the myHand/oppHand/boardTiles mismatches
          // and the "skipped stale destination" warnings.
          window.YD_RESYNC_IN_PROGRESS = true;
          try {
            myGoal = d.goal || myGoal;
            if (d.stake != null) myStake = Number(d.stake) || 0;
            if (d.prize != null) myPrize = Number(d.prize) || 0;
            isFreeMatch = !(myStake > 0);
            var oppInfo = d.opponent || {};
            window.DOMINO_OPP = { name: oppInfo.name, avatar: oppInfo.avatar, photo_url: oppInfo.photo_url };
            var resync2 = d.resync || {};
            var initialMine = resync2.initialYourHand || resync2.yourHand || [];
            var initialOpp = resync2.initialOppHand || [0,0,0,0,0,0,0];
            var syntheticDeal = {
              seat: d.seat, match_id: d.match_id, goal: d.goal, stake: d.stake, prize: d.prize,
              yourHand: initialMine, oppHand: initialOpp,
              starterSeat: (resync2.starterSeat != null ? resync2.starterSeat : 0),
              boneyardCount: (resync2.initialBoneyardCount != null ? resync2.initialBoneyardCount : (resync2.boneyardCount || 0))
            };
            handleOnlineStart(syntheticDeal);
            var fullLog = (resync2.actions || resync2.missed || []).slice();

            (function waitForCleanDeal(tries){
              if (tries > 180) {
                window.YD_RESYNC_IN_PROGRESS = false;
                if (window.reportGlitch) window.reportGlitch("resume restore timed out waiting for clean deal");
                return;
              }
              if (typeof s_oGame === "undefined" || !s_oGame || !s_oGame.applyReplayMove || !s_oGame.getDebugCounts) {
                setTimeout(function(){ waitForCleanDeal(tries + 1); }, 100); return;
              }
              var c = s_oGame.getDebugCounts();
              // A clean initial deal must have zero board tiles and exactly the
              // original hand sizes. Waiting for this is the key race fix.
              if (!c || c.boardTiles !== 0 || c.myHand !== initialMine.length || c.oppHand !== initialOpp.length) {
                setTimeout(function(){ waitForCleanDeal(tries + 1); }, 100); return;
              }

              var k = 0;
              function applyNext(){
                if (k >= fullLog.length) {
                  try { sessionStorage.removeItem("yd_resync_reload_attempted"); } catch(e){}
                  try { sessionStorage.removeItem("yd_force_full_resume"); } catch(e){}
                  // The replay above rebuilt the board by alternating turns
                  // from starterSeat. That only lands on the right player if
                  // every logged action arrived and applied cleanly. Take the
                  // turn straight from the server instead of trusting the
                  // replay -- otherwise the local turn can end up one step
                  // out, the player taps a tile, the server rejects it as
                  // not_your_turn, and the client reloads into another
                  // resume (what the freeze/kick actually looks like).
                  try {
                    if (resync2.turnSeat != null && s_oGame.applyServerTurn) {
                      s_oGame.applyServerTurn(Number(resync2.turnSeat) === Number(d.seat) ? 0 : 1);
                    }
                  } catch(e){}
                  // Release the lock before the final count check so that, if
                  // we're still wrong, the game_state path below is free to
                  // run a real rebuildFromState instead of being permanently
                  // blocked by a lock nothing will ever clear.
                  window.YD_RESYNC_IN_PROGRESS = false;
                  // Final count check: if anything still differs, request a new
                  // canonical sync rather than continuing from corrupt state.
                  try {
                    var fin = s_oGame.getDebugCounts();
                    if (resync2.totalBoardMoves != null && fin && fin.boardTiles !== resync2.totalBoardMoves) {
                      if (window.reportGlitch) window.reportGlitch("resume restore count mismatch local=" + fin.boardTiles + " server=" + resync2.totalBoardMoves);
                      if (window.requestBoardSyncDiagnostic) window.requestBoardSyncDiagnostic("resume_restore_mismatch");
                    }
                  } catch(e){}
                  return;
                }
                var mm = fullLog[k++];
                try {
                  if (mm && mm.type) {
                    var relSeat = (Number(mm.seat) === Number(d.seat)) ? 0 : 1;
                    if (mm.type === "move") s_oGame.applyReplayMove(relSeat, mm.value, mm.side, mm.rotation);
                    else if (mm.type === "pass" && s_oGame.applyReplayPass) s_oGame.applyReplayPass(relSeat);
                    else if (mm.type === "draw" && s_oGame.applyReplayDraw) s_oGame.applyReplayDraw(relSeat, mm.value, Number(mm.boneyard_left || 0));
                  }
                } catch(e) {
                  window.YD_RESYNC_IN_PROGRESS = false;
                  if (window.reportGlitch) window.reportGlitch("resume restore action failed: " + e.message);
                  return;
                }
                // moveToBoard uses CreateJS tweens. Serialize restore actions so
                // two board mutations can never race each other.
                setTimeout(applyNext, mm && mm.type === "move" ? 180 : 40);
              }
              applyNext();
            })(0);
          } catch(e){ window.YD_RESYNC_IN_PROGRESS = false; try { console.error(e); } catch(e2){} }
          return;
        }

        // Catch the board back up on anything the opponent did while our
        // socket was down. The server can only tell us *that* we missed
        // moves, not show them to us — this replays each one through the
        // exact same handlers a live move would use, so the board ends up
        // exactly where it should be instead of sitting frozen on
        // whatever it last showed before the drop.
        try {
          var resync = d.resync;
          if (resync && window.s_bOnline && typeof s_oGame !== "undefined" && s_oGame) {
            var missed = resync.missed || [];
            if (missed.length && window.reportGlitch) window.reportGlitch("reconnected, caught up on " + missed.length + " missed move(s)");
            for (var i = 0; i < missed.length; i++) {
              var m = missed[i];
              if (!m || !m.type) continue;
              // During a soft disconnect only opponent actions can have happened
              // without already being reflected locally. Never replay our own
              // logged actions as opponent actions.
              if (m.seat != null && Number(m.seat) === Number(d.seat)) continue;
              if (m.type === "move") {
                s_oGame.applyRemoteMove(m.value, m.side, m.rotation);
              } else if (m.type === "pass") {
                s_oGame.applyRemotePass();
              } else if (m.type === "draw") {
                s_oGame.applyRemoteDraw(m.value, Number(m.boneyard_left || 0));
              }
            }
            // Catching up individual missed moves onto whatever state we
            // already had assumes that prior state was itself correct --
            // if it wasn't (the exact class of bug we've chased before),
            // replaying more moves on top just compounds it. Checking
            // against the server's own counts right now catches that
            // immediately and reloads (a guaranteed-correct fresh start)
            // instead of leaving the player to hit a confusing crash deep
            // into the round with no idea why.
            if (resync.totalBoardMoves != null && typeof s_oGame.getDebugCounts === "function") {
              var counts = s_oGame.getDebugCounts();
              if (counts && counts.boardTiles != null && counts.boardTiles !== resync.totalBoardMoves) {
                if (window.reportGlitch) window.reportGlitch("post-resume mismatch: local=" + counts.boardTiles + " server=" + resync.totalBoardMoves + " -- rebuilding from server state");
                // The server sends the authoritative state right after a
                // resume, so the fix is already in flight: accept it and
                // rebuild in place. Reloading here restarted the whole
                // connection dance that had only just succeeded.
                lastStateSerial = null;
                stateMismatchStreak = 99;
              }
            }
            // Same reason as the full-rebuild path: after catching up on
            // missed actions, take the turn from the server rather than
            // from however the local replay happened to leave it.
            try {
              if (resync.turnSeat != null && s_oGame && s_oGame.applyServerTurn) {
                s_oGame.applyServerTurn(Number(resync.turnSeat) === Number(d.seat) ? 0 : 1);
              }
            } catch(e6){}
          }
        } catch(e){}
        return;
      }
      // Couldn't resume — the grace window expired or the match already
      // ended. Fall back to the lobby so the player isn't stuck staring at
      // a board that will never advance.
      if (d && d.error === "account_banned") {
        try { window.dominoReceiveChat(t("UI_ACCOUNT_BANNED"), "system"); } catch(e){}
      }
      if (started) {
        // MONEY-SAFETY: a transient resume race/error must never eject the
        // player or become a forfeit. Keep the board open and retry.
        //
        // But retrying forever is its own trap: if the server really has
        // no room for us, this loop just runs silently until the server's
        // grace window expires and the match is lost anyway -- the player
        // sits on "Connecting..." for a minute with no idea they are about
        // to lose. Bound the retries to a little under the grace window,
        // then say plainly what happened.
        try {
          resumeRetryCount++;
          // How long it's worth retrying depends on what the server said.
          //
          // no_match_to_resume is an ANSWER, not a hiccup: the server has
          // looked and has no room for us. The only reason to retry at all
          // is the brief window where a reload beats the old socket's
          // disconnect being processed -- a couple of seconds, not a
          // minute. Retrying for 45s here just spams the server hundreds of
          // times and keeps the player staring at "Connecting..." long
          // after the match is provably gone.
          var isDefinitive = d && d.error === "no_match_to_resume";
          var maxRetries = isDefinitive ? RESUME_MAX_RETRIES_DEFINITIVE : RESUME_MAX_RETRIES;
          msg.textContent = t("UI_CONNECTING_ELLIPSIS");
          if (window.reportGlitch) window.reportGlitch("resume refused: " + ((d&&d.error)||"unknown") + " -- attempt " + resumeRetryCount + "/" + maxRetries);
          if (resumeRetryCount >= maxRetries) {
            resumeRetryCount = 0;
            started = false;
            window.s_bOnline = false;
            stopGameStateHeartbeat();
            clearAutoTurnTimer();
            hideChips();
            msg.textContent = t("UI_OPPONENT_LEFT");
            showOverlay();
            try { loadWallet(); } catch(e2){}
            return;
          }
          setTimeout(function(){
            try {
              if (started && socket && socket.connected && window.DOMINO_TOKEN) {
                socket.emit("resume_match", { token: window.DOMINO_TOKEN, hasExistingGame: true });
              } else if (started && socket && !socket.connected) {
                socket.connect();
              }
            } catch(e2){}
          }, 1500);
        } catch(e){}
      }
    });

    // An admin banned this account while it was actively connected --
    // don't just let the socket drop silently (which would look like a
    // normal disconnect/reconnect-retry loop). Tell the player plainly
    // and send them back to the login screen so they can't keep tapping
    // around a half-alive session.
    socket.on("force_disconnect", function(d){
      var reason = d && d.reason;
      // A reconnect can replace the stale socket with a new one. That is a
      // session handoff, NOT a logout/forfeit. Never bounce the player to
      // login/lobby for this reason (also protects against an older server).
      if (reason === "session_resumed_elsewhere") {
        try { console.log("[reconnect] stale socket retired; keeping match UI"); } catch(e){}
        return;
      }
      try {
        alert(reason === "account_banned" ? t("UI_ACCOUNT_BANNED") : t("UI_FORCE_DISCONNECTED"));
      } catch(e){}
      try { if (window.dominoLogout) { window.dominoLogout(); } else { location.reload(); } } catch(e){ try{location.reload();}catch(e2){} }
    });

    // Opponent dropped but may come back — surface it instead of leaving the
    // player wondering why nothing is happening.
    socket.on("opponent_reconnecting", function(){
      try { console.error("[match-event] opponent_reconnecting"); } catch(e){}
      try { window.dominoReceiveChat(t("UI_OPP_RECONNECTING"), "system"); } catch(e){}
    });
    socket.on("opponent_resumed", function(){
      try { window.dominoReceiveChat(t("UI_OPP_RESUMED"), "system"); } catch(e){}
    });

    // Mobile browsers freeze background tabs, which kills the socket without
    // the page always seeing a clean "disconnect" in time — socket.io's
    // backoff can then sit idle for seconds after the player returns.
    // Nudging it the moment the page becomes visible makes reconnection
    // immediate instead of leaving the game looking frozen.
    document.addEventListener("visibilitychange", function(){
      if (document.visibilityState === "visible" && socket && !socket.connected) {
        try { socket.connect(); } catch(e){}
      }
    });
    // Same idea for the OS-level "network came back" signal.
    window.addEventListener("online", function(){
      if (socket && !socket.connected) { try { socket.connect(); } catch(e){} }
    });
    socket.on("chat_message", function(d){
      if (d && typeof d.text === "string" && d.text.trim()) window.dominoReceiveChat(d.text, d.type);
    });
    socket.on("connect_error", function(e){ msg.textContent=t("UI_CONNECTION_ERROR_PREFIX")+(e&&e.message); });
    socket.on("match_error", function(d){
      try { console.error("[match-event] match_error"); } catch(e){}
      clearMatchTimer();
      closeSearching();
      showOverlay();
      var code=(d&&d.error)||"match_error";
      if(code==="insufficient_balance") msg.textContent=t("UI_NOT_ENOUGH_USDT");
      else if(code==="login_required") msg.textContent=t("UI_SIGN_IN_PAID");
      else if(code==="same_account_not_allowed") msg.textContent=t("UI_SAME_ACCOUNT_ERROR");
      else if(code==="paid_features_disabled") msg.textContent=t("UI_PAID_UNAVAILABLE");
      else if(code==="account_banned") msg.textContent=t("UI_ACCOUNT_BANNED");
      else msg.textContent=t("UI_MATCH_ERROR_PREFIX")+code;
    });
    socket.on("match_settled", function(d, ack){
      try { console.error("[match-event] match_settled"); } catch(e){}
      if (typeof ack === "function") ack({ ok: true });
      currentMatchId=null;
      loadWallet();
      msg.textContent = d&&d.won
        ? t("UI_YOU_WON_PREFIX")+Number(d.prize||0).toFixed(2)+t("UI_USDT_CHECK_SUFFIX")
        : t("UI_MATCH_SETTLED");
    });
    socket.on("match_forfeit_win", function(d){
      try { console.error("[match-event] match_forfeit_win"); } catch(e){}
      try { console.log("[event] match_forfeit_win received, prize=" + (d&&d.prize)); } catch(e){}
      // The opponent disconnected mid-match — they forfeit, we win. The
      // server already credited the prize; just show the Win screen and
      // refresh the wallet instead of leaving the board frozen.
      matchEndedNormally = true;
      oppWatchStart = null;
      oppStuckShown = false;
      if (oppStuckBox) oppStuckBox.style.display = "none";
      if (d && d.prize != null) myPrize = Number(d.prize) || myPrize;
      currentMatchId = null;
      window.s_bOnline = false;
      stopGameStateHeartbeat();
      loadWallet();
      var myScore = 0, oppScore = 0;
      try {
        if (typeof s_oGame !== "undefined" && s_oGame && s_oGame.getScore){
          myScore = s_oGame.getScore(0) || 0;
          oppScore = s_oGame.getScore(1) || 0;
        }
      } catch(e){}
      if (window.dominoShowMatchResult){
        window.dominoShowMatchResult({
          youWin: true,
          yourScore: myScore,
          oppScore: oppScore,
          onExit: function(){ try{ dominoReturnToLobby(false); }catch(e){} },
          onPlayAgain: function(){ try{ dominoReturnToLobby(false); }catch(e){} openGoal(); }
        });
      } else {
        msg.textContent = t("UI_OPPONENT_LEFT_WON_PREFIX")+Number(myPrize||0).toFixed(2)+t("UI_USDT_CHECK_SUFFIX");
        showOverlay();
      }
    });
    socket.on("match_disputed", function(d){
      try { console.error("[match-event] match_disputed"); } catch(e){}
      if (d && d.auto_refunded) {
        matchEndedNormally = true;
        currentMatchId = null;
        window.s_bOnline = false;
        stopGameStateHeartbeat();
        clearAutoTurnTimer();
        try { loadWallet(); } catch(e){}
        msg.textContent = t("UI_MATCH_NEEDS_REVIEW");
        showOverlay();
        return;
      }
      msg.textContent=t("UI_MATCH_NEEDS_REVIEW");
    });
    socket.on("waiting", function(){ msg.textContent=t("UI_WAITING_OPPONENT_DOTS"); });
    socket.on("matched", function(d){
      clearMatchTimer();
      matchEndedNormally = false;
      // A new match restarts the server's state counter, so clear ours too
      // or the first states of the new game would look "older" and be
      // ignored.
      lastStateSerial = null;
      stateMismatchStreak = 0;
      resumeRetryCount = 0;
      // The Win/Lose card is a single reusable overlay that is only ever
      // hidden by its own two buttons. If the previous match's card was
      // still up for any reason, it stayed on screen over the new match --
      // the player sees the PREVIOUS game's result panel and has no way to
      // reach the board, which looks exactly like being thrown out of the
      // match. Always clear it as a new match begins.
      try { rov.style.display = "none"; } catch(e){}
      oppWatchStart = null;
      oppStuckShown = false;
      if (oppStuckBox) oppStuckBox.style.display = "none";
      mySeat=d.seat;
      myGoal=d.goal||myGoal;
      if (d.stake != null) myStake=Number(d.stake)||0;
      if (d.prize != null) myPrize=Number(d.prize)||0;
      currentMatchId=d.match_id||null;
      window.DOMINO_OPP=d.opp||null;
      setTimeout(function(){try{setMatchFriendState();}catch(e){}},100);
    });
    function handleOnlineStart(deal){
      if(deal && deal.match_id) currentMatchId=deal.match_id;
      clearMatchTimer();
      // Same reason as in the 'matched' handler: a leftover Win/Lose card
      // from an earlier match would otherwise sit on top of the new board.
      // handleOnlineStart also runs on the resume path, which never goes
      // through 'matched', so it needs its own clear.
      try { rov.style.display = "none"; } catch(e){}
      window.s_oOnlineDeal=deal; window.s_bOnline=true;
      setTimeout(function(){try{setMatchFriendState();}catch(e){}},100);
      // A new deal is inbound. Block state application until CGame says the
      // deal is finished and visible (checkFirstTile clears this).
      try { window.YD_DEAL_PENDING = true; } catch(e){}
      window.YD_SERVER_TURN_IS_MINE = null;
      window.YD_SERVER_TURN_AT = 0;
      currentRoundSerial = (deal && deal.roundSerial != null) ? Number(deal.roundSerial) : null;
      try { console.log("[round] online_start roundSerial=" + currentRoundSerial + " started=" + started); } catch(e){}
      lastStateSerial = null;
      stateMismatchStreak = 0;
      startGameStateHeartbeat();
      window.s_oNetSend=function(m, onResult){
        var moveNonce = Date.now() + '-' + Math.random().toString(36).slice(2);
        var payload = Object.assign({}, m, { nonce: moveNonce });
        var attempts = 0;
        var maxAttempts = 4;
        // The game engine is now WAITING on this answer before it puts the
        // tile down, so it must arrive exactly once -- never twice, and
        // never not at all, or the player is left with their input frozen.
        var resolved = false;
        function resolve(bOk, sError){
          if (resolved) return;
          resolved = true;
          if (typeof onResult === "function") {
            try { onResult(bOk, sError); } catch(e){
              try { console.error(e); } catch(e2){}
            }
          }
        }
        function sendMove(){
          attempts++;
          var acked = false;
          socket.emit("game_move", payload, function(resp){
            acked = true;
            // An ack that arrived without an explicit rejection means the
            // server took the move. An ack with no payload at all counts as
            // accepted too -- the ack itself is the confirmation.
            if (!resp || resp.ok !== false) { resolve(true, null); }
            if (resp && resp.ok === false) {
              resolve(false, resp.error || "server_rejected");
              var err = resp.error || "server_rejected";
              if (window.reportGlitch) window.reportGlitch("server rejected move: " + err);
              // A rejected move means this phone's picture of the game was
              // wrong. The server pushes the authoritative state after
              // every change, so the correct state is already on its way --
              // ask for it and rebuild in place. Reloading here (what used
              // to happen) threw away the socket on the connections least
              // able to re-establish it.
              lastStateSerial = null;      // accept the next state whatever its serial
              stateMismatchStreak = 99;    // rebuild on it immediately
              try { if (window.requestBoardSyncDiagnostic) window.requestBoardSyncDiagnostic("move_rejected:" + err); } catch(e){}
              // NOT resume_match here. This socket never actually dropped --
              // the server just rejected one move -- but resume_match's
              // needsFullRebuild is hardcoded true on the server, so calling
              // it tore the whole deal down and replayed the entire round
              // from scratch on every single rejection. On a match with a
              // few dozen rejections that is a visible re-deal each time:
              // exactly what looks like "getting kicked out and coming
              // back." request_game_state gets the same authoritative
              // correction and repairs in place via the guarded
              // rebuildFromState/reconcileHand path above -- no re-deal.
              try {
                if (socket && socket.connected) { socket.emit("request_game_state"); }
              } catch(e){}
            }
          });
          // If the server never acks (request or the ack itself lost on a
          // shaky connection), the opponent may never have received the
          // move either -- resend rather than leaving both sides frozen
          // waiting on a move that never truly landed. Reusing the same
          // nonce means a resend that DID land the first time is safely
          // ignored server-side instead of being applied twice.
          setTimeout(function(){
            if (acked) return;
            if (attempts < maxAttempts) {
              if (window.reportGlitch) window.reportGlitch("game_move retry, attempt " + (attempts + 1));
              sendMove();
            } else {
              try { console.error(new Error("game_move ack never arrived after " + attempts + " attempts")); } catch(e){}
              if (window.reportGlitch) window.reportGlitch("game_move ack timeout after " + attempts + " attempts");
              // An ack can be lost while the move itself was accepted. Do not
              // automatically dispute/refund a paid match on that alone; force
              // a canonical sync/reconnect path instead.
              try { if (window.requestBoardSyncDiagnostic) window.requestBoardSyncDiagnostic("game_move_ack_timeout"); } catch(e){}
              // Unblock the player. The move may or may not have landed; the
              // board is untouched either way, which is the whole point of
              // waiting -- there is nothing to undo.
              resolve(false, "timeout");
            }
          }, 5000);
        }
        sendMove();
      };

      // Round-end scoring needs the true pip total of both hands. The
      // server already tracks both (that's what move/draw legality checks
      // use) -- ask it rather than each side guessing the other's hidden
      // tiles, which was producing two different point counts for the
      // same round on the two screens even though both sides still agreed
      // on who won. cb always fires exactly once, either with the
      // server's answer or {ok:false} if we're offline/disconnected/it
      // errors -- CGame.js falls back to its own local estimate on ok:false.
      window.s_oNetGetHandTotals = function(cb){
        var done = false, attempts = 0, maxAttempts = 4;
        function finish(resp){ if (done) return; done = true; cb(resp); }
        function ask(){
          attempts++;
          try {
            if (!socket || !socket.connected) {
              if (attempts < maxAttempts) return setTimeout(ask, 1200);
              return finish({ok:false});
            }
            var answered = false;
            socket.emit("get_hand_totals", {}, function(resp){
              if (done || answered) return;
              answered = true;
              if (resp && resp.ok) return finish(resp);
              if (attempts < maxAttempts) return setTimeout(ask, 500);
              finish({ok:false});
            });
            setTimeout(function(){
              if (done || answered) return;
              answered = true;
              if (attempts < maxAttempts) ask();
              else finish({ok:false});
            }, 1800);
          } catch(e) {
            if (attempts < maxAttempts) setTimeout(ask, 800);
            else finish({ok:false});
          }
        }
        ask();
      };

      var drawRetryTimer = null;
      var drawRetryCount = 0;
      window.s_oNetDraw=function(){
        drawRetryCount = 0;
        var drawNonce = Date.now() + '-' + Math.random().toString(36).slice(2);
        function sendDraw(){
          drawRetryCount++;
          socket.emit("draw_tile", { nonce: drawNonce });
          // If draw_tile_result never comes back (request or response lost
          // on a shaky connection), the player used to be stuck frozen
          // forever with zero indication anything went wrong. Retry a few
          // times before giving up -- draw_tile_result's handler clears
          // this timer as soon as a real response arrives, so a normal,
          // successful draw never triggers a resend. Reusing the same
          // nonce on every retry lets the server recognize a resend of
          // the SAME request and reply with the cached result instead of
          // drawing an extra tile.
          drawRetryTimer = setTimeout(function(){
            if (drawRetryCount < 4) {
              reportGlitch("draw_tile retry, attempt " + (drawRetryCount + 1));
              sendDraw();
            } else {
              try { console.error(new Error("draw_tile_result never arrived after " + drawRetryCount + " attempts")); } catch(e){}
              reportGlitch("draw_tile_result timeout after " + drawRetryCount + " attempts");
              try { if (window.requestBoardSyncDiagnostic) window.requestBoardSyncDiagnostic("draw_tile_result_timeout"); } catch(e){}
            }
          }, 6000);
        }
        sendDraw();
      };
      window.s_clearNetDrawRetry = function(){
        if (drawRetryTimer) { clearTimeout(drawRetryTimer); drawRetryTimer = null; }
      };

      if (started){
        // Round 2+ of the SAME match: the deal above is already refreshed —
        // just reload the board with the server's fresh hands. No VS splash,
        // no goal picker, no re-navigating — this is what was missing before,
        // so round 2 silently kept showing the finished round 1 board.
        try { s_oGame.restart(); } catch(e){}
        return;
      }

      var run = function(){
        // player labels: chips (HTML) replace the canvas labels
        var me = window.DOMINO_USER || {};
        var opp = window.DOMINO_OPP || {};
        window.DOMINO_P0_NAME = nameOf(me);
        window.DOMINO_P1_NAME = (opp.name || t("UI_OPPONENT"));
        window.DOMINO_P1_PHOTO = opp.photo_url || opp.photo || null;
        window.DOMINO_P1_AVATAR = opp.avatar || null;
        clearChat();
        closeGoal(); hideOverlay();
        showChips(nameOf(me), avatarOf(me), (opp.name||t("UI_OPPONENT")), (opp.avatar||"🧑"));
        if(!started){ started=true; try{ window.s_aPlayersScore2=[0,0]; }catch(e){} try{ s_oMain.gotoGame(2, deal.goal||myGoal); patchGotoMenu(); refreshInGameAvatarSoon(); }catch(e){ msg.textContent="start error: "+e.message; showOverlay(); } }
      };
      var opp = window.DOMINO_OPP || {};
      showVsThenStart(opp.name || t("UI_OPPONENT"), opp.avatar || "🧑", run);
    }
    socket.on("online_start", function(deal, ack){
      if (typeof ack === "function") ack({ ok: true });
      handleOnlineStart(deal);
    });
    // The room's authoritative cumulative score, pushed after every round it
    // commits. Both seats get it whether or not they asked, which is what
    // stops the two phones showing different totals after a blocked round.
    socket.on("round_score", function(d){
      if (!d || !d.scores || d.scores.length < 2) return;
      try { console.log("[score] round_score round=" + d.roundSerial + " " + d.scores[0] + "-" + d.scores[1]); } catch(e){}
      try {
        if (typeof s_oGame !== "undefined" && s_oGame && s_oGame.applyAuthoritativeScores) {
          s_oGame.applyAuthoritativeScores(d.scores);
        }
      } catch(e){}
    });

    socket.on("game_state", function(state){
      // The server's authoritative position, sent after every change. This
      // is what makes a person-vs-person match as reliable as a match
      // against the bot: instead of this phone running its own copy of the
      // game and hoping it stays in step, the server tells it the whole
      // truth and this phone checks itself against it.
      if (!state || !window.s_bOnline || typeof s_oGame === "undefined" || !s_oGame) return;

      // Ignore anything older than what we've already applied, so a
      // late-arriving message can never rewind the board.
      if (state.stateSerial != null) {
        if (lastStateSerial != null && state.stateSerial <= lastStateSerial) return;
        lastStateSerial = state.stateSerial;
      }
      if (state.seat != null) mySeat = state.seat;

      // Don't reconcile against a board that another writer is still
      // rebuilding: the manual resume replay walks the log one action at a
      // time, and the deal animation is still handing tiles out. Comparing
      // mid-flight looks like a real divergence and used to trigger a
      // rebuild on top of the in-progress one -- two writers on the same
      // hands. Skipping is safe: the server sends the full position after
      // every change, so the next one reconciles us once we're idle.
      // Record the server's turn BEFORE any guard can drop the state. Even
      // a state we decline to apply to the board still tells us the truth
      // about whose turn it is, and that is what stops the player from
      // tapping a tile the server is going to refuse.
      noteServerTurn(state.turnSeat, state.seat);

      try {
        if (window.YD_RESYNC_IN_PROGRESS) { logStateDrop("resync_in_progress"); return; }
        if (s_oGame.isDealing && s_oGame.isDealing()) { logStateDrop("still_dealing"); return; }
        // The deal for this round has not finished landing yet.
        if (window.YD_DEAL_PENDING) { logStateDrop("deal_pending"); return; }
        // The engine is not accepting play yet (between rounds, mid-restart,
        // or still on the VS splash with the PREVIOUS round's instance).
        if (!s_oGame.gameReady || s_oGame.gameReady() !== true) { logStateDrop("game_not_ready"); return; }
        // Belt and braces: never apply a state from a different round than
        // the one on screen.
        if (state.roundSerial != null && currentRoundSerial != null &&
            Number(state.roundSerial) !== currentRoundSerial) {
          logStateDrop("round_mismatch", "state=" + state.roundSerial + " local=" + currentRoundSerial);
          return;
        }
        // Our own move is out with the server and the board is deliberately
        // untouched until it answers. Reconciling against a state that
        // predates that answer would "correct" the tile back into our hand.
        if (s_oGame.isAwaitingServerMove && s_oGame.isAwaitingServerMove()) { logStateDrop("awaiting_our_move"); return; }
      } catch(e){}

      // The turn always comes from the server. Working it out locally is
      // what let a player tap a tile when it wasn't their turn, get
      // rejected, and reload into a resume loop.
      try {
        if (state.turnSeat != null && s_oGame.applyServerTurn) {
          s_oGame.applyServerTurn(Number(state.turnSeat) === Number(state.seat) ? 0 : 1);
        }
      } catch(e){}

      // Correct our own hand from the server before anything else. This is
      // cheap, safe, and removes the single most confusing failure the
      // players hit: tapping a tile that is visibly in their hand and being
      // told it isn't.
      try {
        if (state.yourHand && s_oGame.reconcileHand) {
          var handFix = s_oGame.reconcileHand(state.yourHand);
          if (handFix && window.reportGlitch) window.reportGlitch(handFix);
        }
      } catch(e){}

      // Now check the board itself. A mismatch here used to be invisible
      // until it broke the match; catching it means we can recover from a
      // known-good position instead of playing on from a corrupt one.
      try {
        if (!s_oGame.diffAgainstServer) return;
        var diff = s_oGame.diffAgainstServer(state);
        if (!diff) { stateMismatchStreak = 0; return; }

        // One disagreement is usually just an animation still in flight --
        // the tile is mid-tween and hasn't landed yet. Only act if it
        // persists across several updates.
        stateMismatchStreak++;
        if (stateMismatchStreak < 3) return;

        stateMismatchStreak = 0;
        if (window.reportGlitch) window.reportGlitch("board out of step with server (" + diff + ") -- rebuilding");

        // Rebuild from this very state, in place. Reloading the page here
        // was worse than the problem on a weak connection: it dropped the
        // socket, forced a reconnect, and could bounce straight into
        // another mismatch.
        var rebuilt = false;
        try { rebuilt = s_oGame.rebuildFromState(state); } catch(e7){}

        if (!rebuilt) {
          // Only if the in-place rebuild genuinely failed do we fall back
          // to a reload, and never more than once every 20 seconds.
          var key = "yd_state_resync_at";
          var last = 0;
          try { last = Number(sessionStorage.getItem(key) || 0); } catch(e2){}
          if (Date.now() - last < 20000) return;
          try { sessionStorage.setItem(key, String(Date.now())); } catch(e3){}
          try { localStorage.setItem("yd_pending_resume", "1"); } catch(e4){}
          try { sessionStorage.setItem("yd_force_full_resume", "1"); } catch(e5){}
          setTimeout(function(){ try { location.reload(); } catch(e6){} }, 200);
        }
      } catch(e){}
    });

    socket.on("draw_tile_result", function(d){
      try { if (window.s_clearNetDrawRetry) window.s_clearNetDrawRetry(); } catch(e){}
      if(!window.s_bOnline || typeof s_oGame==="undefined" || !s_oGame) return;
      try {
        if(d && d.ok){
          s_oGame.applyLocalDraw(d.value, Number(d.boneyard_left||0));
        } else if(d && d.empty){
          s_oGame.applyOnlineBoneyardEmpty();
        }
      } catch(e){}
    });
    socket.on("opponent_drew", function(d){
      if(!window.s_bOnline || typeof s_oGame==="undefined" || !s_oGame) return;
      try {
        s_oGame.applyRemoteDraw(d.value, Number(d.boneyard_left||0));
      } catch(e){}
    });
    var appliedMoveNonces = new Set();
    var appliedMoveNonceOrder = [];
    socket.on("server_auto_actions", function(d){
      if (!window.s_bOnline || typeof s_oGame === "undefined" || !s_oGame || !d) return;
      try {
        var relSeat = (Number(d.seat) === Number(mySeat)) ? 0 : 1;
        var acts = d.actions || [];
        for (var ai=0; ai<acts.length; ai++) {
          var a = acts[ai];
          if (!a || !a.type) continue;
          if (a.type === "draw" && s_oGame.applyReplayDraw) s_oGame.applyReplayDraw(relSeat, a.value, Number(a.boneyard_left || 0));
          else if (a.type === "move" && s_oGame.applyReplayMove) s_oGame.applyReplayMove(relSeat, a.value, a.side, a.rotation);
          else if (a.type === "pass" && s_oGame.applyReplayPass) s_oGame.applyReplayPass(relSeat);
        }
      } catch(e) { if (window.reportGlitch) window.reportGlitch("server auto action apply failed: " + e.message); }
    });
    socket.on("force_auto_turn", function(d){
      // Legacy compatibility only. New servers execute the action authoritatively.
      try { if (window.requestBoardSyncDiagnostic) window.requestBoardSyncDiagnostic("legacy_force_auto_turn"); } catch(e){}
    });
    socket.on("game_move", function(m, ack){
      if (typeof ack === "function") ack({ ok: true });
      if(!window.s_bOnline || typeof s_oGame==="undefined" || !s_oGame) return;
      // A retried delivery (our earlier ack got lost even though we did
      // receive and apply the move) must not be applied a second time --
      // that would duplicate the tile on the board.
      if (m && m.nonce && appliedMoveNonces.has(m.nonce)) return;
      if (m && m.nonce) {
        appliedMoveNonces.add(m.nonce); appliedMoveNonceOrder.push(m.nonce);
        if (appliedMoveNonceOrder.length > 100) appliedMoveNonces.delete(appliedMoveNonceOrder.shift());
      }
      try{ if(m.type==="move"){ s_oGame.applyRemoteMove(m.value,m.side,m.rotation); } else if(m.type==="pass"){ s_oGame.applyRemotePass(); } }catch(e){}
    });
    socket.on("opponent_left", function(){
      try { console.error("[match-event] opponent_left"); } catch(e){}
      try { console.log("[event] opponent_left received, matchEndedNormally=" + matchEndedNormally); } catch(e){}
      endMatchAfterDrop();
    });
  }

  if(!autoTurnWatch){
    autoTurnWatch=setInterval(armAutoTurnIfNeeded,250);
  }

  // start an OFFLINE game vs the built-in CPU, shown to the player as a
  // regular-looking opponent (random name + avatar) rather than "Computer".
  function startVsComputer(){
    clearMatchTimer();
    try { if(socket && socket.connected) socket.emit("cancel_find"); } catch(e){}
    var cpu = randomCpuIdentity();
    showVsThenStart(cpu.name, cpu.avatar, function(){
      window.s_bOnline = false;          // offline mode -> game's own CPU plays
      stopGameStateHeartbeat();
      window.s_oOnlineDeal = null;
      window.s_oNetSend = null;
      window.s_oNetDraw = null;
      var me = window.DOMINO_USER || {};
      window.DOMINO_P0_NAME = nameOf(me);
      window.DOMINO_P1_NAME = cpu.name;
      window.DOMINO_P1_PHOTO = null;
      window.DOMINO_P1_AVATAR = cpu.avatar;
      clearChat();
      closeGoal(); hideOverlay();
      showChips(nameOf(me), avatarOf(me), cpu.name, cpu.avatar);
      if(!started){
        started = true;
        try { window.s_aPlayersScore2=[0,0]; } catch(e){}
    try { s_oMain.gotoGame(2, myGoal); patchGotoMenu(); refreshInGameAvatarSoon(); }   // 2 players: you vs CPU
        catch(e){ msg.textContent="start error: "+e.message; showOverlay(); started=false; }
      }
    });
  }

  playBtn.onclick = function(){
    if (!socket || !socket.connected){
      matchMsg.textContent = t("UI_NOT_CONNECTED_WAIT_DOT");
      return;
    }

    var me = window.DOMINO_USER || {};

    // FREE PLAY: no balance required, but still needs a signed-in user so
    // the server can track wins/losses and tournament credit properly.
    if (isFreeMatch){
      if (!window.DOMINO_TOKEN){
        matchMsg.textContent = t("UI_PLEASE_SIGN_IN_DOT");
        return;
      }
      matchMsg.textContent = "";
      socket.emit("find_match", {
        goal: myGoal,
        stake: 0,
        token: window.DOMINO_TOKEN || "",
        name: nameOf(me),
        avatar: avatarOf(me),
        photo: me.photo_url || null
      });
      openSearching();
      clearMatchTimer();
      matchTimer = setTimeout(function(){
        if (!started && window.YD_BOT_ENABLED === true) {
          startVsComputer();
        } else if (!started) {
          msg.textContent=t("UI_WAITING_OPPONENT_DOTS");
        }
      }, FREE_WAIT_MS);
      return;
    }

    // PAID PLAY: authenticated wallet balance is required.
    if (!window.DOMINO_TOKEN){
      matchMsg.textContent = t("UI_PLEASE_SIGN_IN_DOT");
      return;
    }

    playBtn.disabled = true;
    matchMsg.textContent = t("UI_CHECKING_BALANCE");

    fetch(SERVER + "/api/wallet", { headers: walletHeaders() })
      .then(function(r){
        return r.json().then(function(d){ return {ok:r.ok, d:d}; });
      })
      .then(function(res){
        playBtn.disabled = false;

        if(!res.ok){
          matchMsg.textContent = t("UI_COULD_NOT_READ_BALANCE");
          return;
        }

        renderWallet(res.d);
        var have = Number(res.d && res.d.balance || 0);

        if (have < myStake){
          matchMsg.textContent =
            t("UI_INSUFFICIENT_BALANCE_PREFIX") + myStake.toFixed(2) +
            t("UI_BALANCE_BUT_HAVE") + have.toFixed(2) + t("UI_USDT_DOT");
          return;
        }

        matchMsg.textContent = "";
        socket.emit("find_match", {
          goal: myGoal,
          stake: myStake,
          token: window.DOMINO_TOKEN || "",
          name: nameOf(me),
          avatar: avatarOf(me),
          photo: me.photo_url || null
        });

        openSearching();
        clearMatchTimer();
        matchTimer = setTimeout(function(){
          try { if(socket&&socket.connected) socket.emit("cancel_find"); } catch(e){}
          closeSearching();
          showOverlay();
          msg.textContent=t("UI_NO_PAID_OPPONENT");
        }, WAIT_MS);
      })
      .catch(function(){
        playBtn.disabled = false;
        matchMsg.textContent = t("UI_WALLET_NETWORK_ERROR");
      });
  };

  // if the goal picker is closed manually, stop searching + timer
  gback.onclick = function(){ clearMatchTimer(); try{ if(socket&&socket.connected) socket.emit("cancel_find"); }catch(e){} closeGoal(); playBtn.disabled=false; playBtn.textContent=t("UI_PLAY_ONLINE"); };
})();
